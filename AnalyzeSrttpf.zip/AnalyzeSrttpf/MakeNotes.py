import time
import sys
import platform
from subprocess import call
from natsort import natsorted
import os
from music21 import *
'''
This file creates the png-files of the notes.

Steps:
- load file
- remove line/page-breaks
- save as *.xml
- remove meta-data
- convert to *.mscx
- convert to *.png with stylesheet 

TODO:
- remove tmp-files?
'''
print('='*76)

folder = 'xml'
numberOfFiles = 0


if platform.system() == 'Linux':
    # appName = "mscore"
    appName = "mscore"
elif platform.system() == 'Windows':
    # appName = "nightly"
    # new for MuseScore3:
    # MuseScore2:
    # appName = "MuseScore.exe"
    # museScore3:
    appName = "MuseScore3.exe"
else:
    print('Illegal action, aborting!')
    raise SystemExit(0)


def load_files(dir):
    "This function loads all MusicXML-files from a directory and returns a stream."
    print('Loading Files...')
    global melodies
    global fileNames
    global numerOfFiles
    # open xml/ and add all .xml-files to melodies and the filenames to
    # melodyNames
    # melodies = stream.Stream()
    # melodyNames = []

    names = []

    for file in os.listdir(dir):
        if file.endswith(".xml") or file.endswith(".musicxml"):
            # print (relative) filepath
            # print(os.path.join("xml", file))
            names.append(file)

    # sort the names with natural sort algorithm
    names = natsorted(names)
    numberOfFiles = len(names)

    for name in names:
        print('Loading:', name)
        # add file to melodies
        # melodies.append(converter.parse(os.path.join(dir, name)))
        # add filename and number of measures to melodyNames
        fileNames.append(name)
        # , len(melodies[-1][1].getElementsByClass(stream.Measure))])

        #        if file == 'Wit0_4-1707-50-1 - KS.xml':
        # converter.parse(os.path.join("xml", file)).show('text')

    print('All Files (', numberOfFiles, ') from "', dir, '" loaded.', sep='')
    # return melodies


def create_png():

    return 1


# create subdir notes/tmp/ if not existing
os.makedirs('notes/tmp/', exist_ok=True)

# list to store the names of the files
fileNames = []

# list to store the names of the files with problems
problemFiles = []

# load all xml-files in folde
load_files(folder)

# convert all files to png
for fileName in fileNames:
    print('===============')
    print('Converting:', fileName)

    # remove fileending
    # print(fileName[-9:])
    if fileName[-9:] == '.musicxml':
        melodyName = fileName[0:-9]
        fileFormat = '.musicxml'
    else:
        melodyName = fileName[0:-4]
        fileFormat = '.xml'

    # remove creatorpost
    outputFileName = melodyName
    toRemove = [' ', '-', 'KS', 'BK', 'GL', 'PK', 'BK2']
    removeIt = True
    while removeIt:
        removeIt = False
        for rem in toRemove:
            if outputFileName[-len(rem):] == rem:
                # print('rem:', rem)
                # print('remove "' + rem + '"')
                outputFileName = outputFileName[: -len(rem)]
                # print('outputFileName:', outputFileName)
                removeIt = True
    # print(outputFileName)
    # print(melodyName)

    # encode filename
    melodyNameEnc = melodyName.replace(' ', '_')

    # # remove movement-title from xml
    # # remove automatic metadata written to xml by music21
    # with open('xml/'+fileName, "r") as f:
    #     lines = f.readlines()

    # # remove that lines
    # for line in lines:
    #     if line.startswith('  <movement-title>'):
    #         lines.pop(lines.index(line))
    # for line in lines:
    #     if line.startswith('    <creator type="composer">'):
    #         lines.pop(lines.index(line))
    # for line in lines:
    #     if line.startswith('    <work-title>'):
    #         lines.pop(lines.index(line))
    # for line in lines:
    #     if line.startswith('</work-title>'):
    #         lines.pop(lines.index(line))
    # for line in lines:
    #     if line.startswith('  <work>'):
    #         lines.pop(lines.index(line))
    # for line in lines:
    #     if line.startswith('    </work>'):
    #         lines.pop(lines.index(line))

    # fileNameNew = melodyNameEnc+'-2.xml'

    # # write back to file
    # with open('notes/tmp/'+fileNameNew, "w") as f:
    #     for line in lines:
    #         f.write(line)

    # load the "music"
    try:
        # melody = converter.parse(os.path.join('notes/tmp', fileNameNew))[1]
        melody = converter.parse(os.path.join(folder, fileName))
    except:
        print('Can not load file. Skip!')
        problemFiles.append(fileName)
        continue

    # workaround for GL-Files: remove metadata
    try:
        tmp = melody[1].notes
    except:
        melody.remove(melody[1])
        try:
            tmp = melody[1].notes
        except:
            melody.remove(melody[1])
    melody = melody[1]

    # get the number of the first measure
    try:
        firstMeasureNumber = melody.getElementsByClass(stream.Measure)[
            0].measureNumber
    except:
        print('Problems with File. Skip!')
        problemFiles.append(fileName)
        continue

    # remove the linebreaks
    lbs = melody.flat.getElementsByClass(layout.SystemLayout)
    for lb in lbs:
        if lb.measureNumber != firstMeasureNumber:
            for m in melody:
                if m.measureNumber == lb.measureNumber:
                    m.remove(lb)
                    break

    # remove pagebreaks
    pbs = melody.flat.getElementsByClass(layout.PageLayout)
    for pb in pbs:
        if pb.measureNumber != firstMeasureNumber:
            for m in melody:
                if m.measureNumber == pb.measureNumber:
                    m.remove(pb)
                    break

    # write the xml-file without linebreaks
    melody.write('xml', 'notes/tmp/'+fileName)

    # remove automatic metadata written to xml by music21
    with open('notes/tmp/'+melodyName+fileFormat, "r") as f:
        lines = f.readlines()

    # remove that lines
    for line in lines:
        if line.startswith('  <movement-title>'):
            lines.pop(lines.index(line))
        elif line.startswith('    <creator type="composer">'):
            lines.pop(lines.index(line))

    # write back to file
    with open('notes/tmp/'+melodyName+fileFormat, "w") as f:
        for line in lines:
            f.write(line)

    # NOTE: final barlines get lost when converting vom xml to mscx

    # convert to mscx-file
    # call([appName, "-o", fname+".mscx", fname+".xml"])
    call([appName, "-o", "notes/tmp/" +
          melodyName+".mscx", "notes/tmp/"+fileName])

    # convert to png-file
    # call([appName, "-o", fname+".png", fname+".mscx", "-S", "style2.mss"])
    call([appName, "-o", "notes/"+outputFileName+".png",
          "notes/tmp/"+melodyName+".mscx", "-S", "style-dev.mss", "-r", "100", "-T", "5"])

    # params:
    # - -S: use stylesheet
    # - -r: set resolution (dpi), default: 300
    # - -T: crop the image with X pixels border


if len(problemFiles) != 0:
    print('=====================')
    print('Had problems with the following files:')
    probs = ''
    for pF in problemFiles:
        print(' ', pF)
        probs += pF + "\n"
    with open('problems-notes.txt', 'a') as f:
        f.write(time.strftime('%Y-%m-%d-%H-%M-%S') + '\n')
        f.write(probs + '\n')


# print('done!')
