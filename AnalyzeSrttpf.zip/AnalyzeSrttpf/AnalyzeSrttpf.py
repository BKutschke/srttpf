import json
import math
import time
import copy
# from openpyxl.utils import coordinate_from_string, column_index_from_string
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl import load_workbook
import math as math
import matplotlib as mpl
import matplotlib.pyplot as plt
from natsort import natsorted
from os import listdir, path
from music21 import *
import configparser
"""
Welcome to the analysis!

Following are some options that you can change to adapt the results.

Options to change after the initial options block are marked with ####.

"""
'''
criteria:
possible criteria:
- criterion_identifier()
  returns the identifier of the variation
- criterion_numberOfBars()
  returns the number of bars of the variation
  Note: Due to technical reasons is the numberOfBars 0 for variations
- criterion_quarterLength()
  returns the quarterLength of the variation
- TODO: delete criterion_metrum()
- criterion_barlines(barlineType)
  returns all occurrences of barlines of a certain type.
  barlineTypes -- type of the barline
    both:  :||:
    left:  :||
    right:  ||:
    double: ||
- criterion_proportion(proportion=50)
  returns the length of PI in percent. If a special barline exists, it will be
  used. Otherwise `proportion` will be used.
- criterion_redOne(minLenPercent=10, rating=[1, 0])
  checks if there are two iTS in PI that have a tatal length of
  `minLenPercent`.
  returns `ratings[0]` if its True, otherwise returns `ratings[1]`.
  minLenPercent -- minimal length of both iTS in percent.
- criterion_cluster(minLenPercent=15, rating=[1, 0]):
  checks if there are two red clusters in PI with a length of at least
  `minLenPercent`.
  returns `ratings[0]` if its True, otherwise returns `ratings[1]`.
  minLenPercent -- min length of each cluster
- criterion_redTwo(thresholdEndPercent=66, minLenPercent=6, rating=[1, 0])
  checks if there is an iTS whichs first appearance is in PI and its last
  appearance is after thresholdEndPercent and if its longer than minLenPercent.
  returns `ratings[0]` if its True, otherwise returns `ratings[1]`.
  thresholdEndPercent -- threshold for the iTSs last appearancees begin
                           (in percent)
  minLenPercent -- minimum lenght of each iTSs apperance (in percent)
- criterion_greenGrey(minLenPercent=10, rating=[1, 0])
  This function checks if there is an section in PII which is not red and has
  a lenght of at least minLenPercent. After this section there is another
  section which is red.
  returns `ratings[0]` if its True, otherwise returns `ratings[1]`.
  minLenPercent -- minimum length of the non-red section (in percent)
- TODO: delete criterion_criteria_check_bool(criteriaKeyList=[])
- criterion_criteria_check(criteriaKeyList=[])
  Adds the results of the previously checked criteria.
  Note: the criteria have to be checked before, otherwise it won't work as
  intended.
  returns the addition of the values.
  criteriaKeyList -- a list of the keys of criteriaToCheck that should be added.
- criterion_longest_iTS_PI(rating=[1, 0])
  Checks?
  TODO!
- criterion_greenGreyLong(rating=[0, 1])
  Checks if the longest green/grey section of pII is longer than the longest
  green/grey section of pI.
  returns `ratings[0]` if its True, otherwise returns `ratings[1]`.
- criterion_ending(maxLenQL=-1, maxLenPercent=-1, rating=[-4, 1])
  TODO!
- criterion_copy_from_zfgTable(col='A', identifierCol='T',
                               sourceFile='England Zsfg-Tabelle - BK.xlsx',
                               table='Tabelle1'):
  TODO! deprecated?
- criterion_greenRed(thresholdRed=66, thresholdRedLenHigh=6, thresholdRedLenLow=3,
                     minLenPercent=6, rating=[1, 0.5, 0])
  Checks if there is a red iTS after a non-red iTS with `minLenPercent` after
  `thresholdRed` and checks the length.
  returns


check_its():
    part -- in which part the iTS should be
        P1, P2
    quantity -- how often the iTS should appear
        1, 2
    color -- the color of the iTS to find
        possible options: red, green, grey, non-red
    graph -- which graph to use
        'E': Einzelgraph
        'Z': Zfg-graph
    positionBegin -- relative to part: where the iTS should begin
        0-100 (%)
        0: ignore
    positionPivot -- relative to part: where the first iTS should end / second
                     iTS should begin; only relevant with quantity == 2
        0-100 (%)
    positionEnd -- relative to part: where the iTS should end
        0-100 (%)
        100: ignore
    positionTolerance -- tolerating "wrong" positions (relative to length of iTS)
        0-100 (%)
        0: "ignore"
    lenghtMin -- min length of the iTS
        0-100 (%)
        0: ignore
    lengthMax -- max length of the iTS
        0-100 (%)
        100: ignore
    atEnd -- (bool) if the iTS should be at the end
        -> positionBegin and positionEnd not necessary
        True: iTS should be at the End
        False: iTS does not have to be at the end
    rating -- list of two, first: true, second: false
    cluster -- (bool) use cluster to check the iTS
        True: use cluster
        False: don't use cluster
        addition: if cluster==0 (default) then cluster will be True for graph==Z
        and False for graph==E.
    lengthRelation -- to what should the iTS' length relate?
        part: relates to the parts length
        total: relates to the total length

'''
weHaveAProblem = False
# read the config:
configFile = 'config.ini'
# https://docs.python.org/3.7/library/configparser.html
# IMPORTANT: careful with data types, imported are all strings
config = configparser.ConfigParser()
# config.read('config.ini', encoding="cp1251")
config.read(configFile)
# print(config.sections())

# choose the config section
# configNumber = 'FIRST'  # all
# configNumber = 'SECOND'  # rhythm
# configNumber = 'THIRD'  # pitch
configNumber = 'FOURTH'  # summarize

thisConfig = config[configNumber]

# threshold for length of rests in find_ts_dpm() to be ignored
# (short rests may be part of the melody, long usually not)
restIgnoreTreshold = 1

# map criteria
criteriaToCheck = {}
for key, value in config[configNumber+' CRITERIA'].items():
    # print(key, value)
    criteriaToCheck[key.upper()] = value

# print('criteriaToCheck:')
# for k, v in criteriaToCheck.items():
#     print(k, v)


# read the criteria pool
# criteriaPoolSourceFile = 'criteria-pool-new.json'
# criteriaPoolSourceFile = 'criteria-pool.json'
criteriaPoolSourceFile = config['GENERAL']['criteriaPoolSourceFile']
try:
    with open(criteriaPoolSourceFile, 'r') as f:
        criteriaPool = json.loads(f.read())
except:
    print('Warning: could not load "', criteriaPoolSourceFile, '"!', sep='')
    weHaveAProblem = True

# print('criteriaPool:')
# for l in criteriaPool:
#     print(l)


# read the criteria rename pool
# criteriaRenamePoolSourceFile = 'criteria-rename-pool.json'
# criteriaRenamePoolSourceFile = 'criteria-pool.json'
criteriaRenamePoolSourceFile = config['GENERAL']['criteriaPoolSourceFile']
if True:
    with open(criteriaRenamePoolSourceFile, 'r') as f:
        criteriaRenamePool = json.loads(f.read())
try:
    pass
except:
    print('Warning: could not load "',
          criteriaRenamePoolSourceFile, '"!', sep='')
    weHaveAProblem = True

# print('criteriaRenamePool:')
# for k, v in criteriaRenamePool.items():
#     print(k+': '+v)


# TODO: separate file
# these are from the old version
criteriaDescriptions = {
    'criterion_identifier': 'Identifier',
    'criterion_identifier_variant': 'Variantidentifier',
    'criterion_numberOfBars': 'Gesamtanzahl der Takte',
    'criterion_proportion': 'Verhältnis von P1 zu P2 (-> Länge von P1 in %)',

    # Positivkriterien für srttpf:
    # creation of A-A in P1
    'criterion_redOne': '2 red in P1 --> A A. Es gibt mind. einen Graphen, deren erste beiden iTS in P I LIEGEN (–> Rotnuancen) und die jeweils mind. $0$ % der Gesamtlänge des Stücks umfassen [Option zum Ändern].',
    'criterion_redInHalfs': '2xRed jeweils in einer Hälfte von P1 --> A A. Es gibt ein iTS-Paar in P1, das so verteilt ist, dass die erste iTS in der ersten und die zweite iTS in der zweiten Hälfte von P1 liegen.',
    # creation of rounding: A-A-(B)-A'
    'criterion_redTwo': 'Red in P1 und P2. Es gibt mind. einen Graphen, deren erste iTS in P I und deren letzte iTS im letzten Drittel $0$ des Stücks [Option zum Ändern] beginnt (Rotnuancen), und deren Länge jeweils mind. $1$ % der Gesamtlänge des Stücks [Option zum Ändern] umfasst.',
    # creation of contrasting middle part B
    'criterion_greenGrey': 'Gr/gr in P2. Es gibt in P II einen Abschnitt, der nicht rot, sondern grün und/oder grau ist. Der Abschnitt umfasst mind. $0$ % der Gesamtlänge. Nach diesem Abschnitt folgt noch einmal ein Abschnitt mit Rotnuance.',

    # Kriterien, die eine Schwächung der srttpf anzeigen:
    # appendix reduces the effect of the rounding (A')
    'criterion_ending': 'Gr/gr am Ende von P2. Falls die letzten Takte in P2 grau/grün sind (d.h. nicht rot, wie es häufig der Fall ist) dann ist dieser Abschnitt nicht länger als $0$.',
    # long Red in the middle of P2 creates a reference to A, while a - nor more than - weak rounding is constituted by means of a Red at the end of P2
    'criterion_greenRed': 'short Red after Gr/gr --> weak rounding at the end of P2 with strong rounding in the middle of P2. There is a short red iTS after a non-red iTS with minLenPercent after thresholdRed. If it is, its length is checked with thresholdRedLenHigh/Low for return values. If it doesnt match 0 is returned.',

    # Negativ-/Ausschlusskriterien:
    # creation of A-A-B-B
    'criterion_green_grey_PII': '2xGr/gr in P2. Zwei längere grün-graue Abschnitte (Mindestlänge $0$ Prozent) in P2',

    # Auswertungstools
    'criterion_criteria_check': '$0$ + $1$ + $2$ = ',
    'criterion_copy_from_zfgTable': 'Spalte $0$ aus Gesamttabelle.',

    # ???
    # -> ist ein dummy, verschwindet bald
    'criterion_dummy': 'DEACTIVATED!',

    # Wird im Moment nicht gebraucht:
    'criterion_metrum': 'DEACTIVATED Metrum (Taktwechsel können vermutlich nicht berücksichigt werden)',
    'criterion_barlines': 'Es gibt einen speziellen Taktstrich: $0$ an der Stelle',
    'criterion_cluster': 'iTS-Cluster in P1. Es gibt mind. zwei iTS-Cluster (Rotnuancen) in P I, die jeweils eine Mindeslänge von $0$ % der Gesamtlänge haben [Option zum Ändern]',
    'criterion_greenGreyLong': 'Gr/gr in P2 länger als in P1. Der längste grün/graue Abschnitt in P2 ist länger als der längste grün/graue Abschnitte in P1.',
    'criterion_longest_iTS_PI': 'Red in P2 länger als 2 Reds in P1. Die längste iTS innerhalb von P1 ist länger als die längste iTS, die in P1 und P2 vorkommt.',
    # ist identisch mit _green_grey_PII:
    'criterion_greenPII': 'Neg: 2xGr/gr in P2. zwei längere grün-graue Abschnitte (Mindestlänge $0$ Prozent) in P2',
    'criterion_last_red': 'das letzte Rot in P2 ist nicht kürzer als $0$ % (Option zum Ändern)) und liegt nicht  weiter vom Ende fort als $1$ % (Option zum Ändern) –> 1 (sonst 0)',
    'criterion_short_red': 'es gibt ein kürzeres Rot(nicht kürzer als $0$ % (Option zum Ändern)), das nicht weiter vom Ende entfernt liegt als $1$ % (Option zum Ändern) und durch einen längeren Rotabschnitt an anderer Stelle in P2, jedoch nicht früher beginnend als nach dem ersten Drittel von P2 [$2$ %] (Option zum Ändern) ergänzt wird - -> 0, 5 (sonst 0) ',


    # 'check_iTS': 'part $0$, quantity $1$, color $2$, positionBegin $3$, positionEnd $4$, lengthTolerance $5$, atEnd $6$, lenghtMin $7$, lengthMax $8$, lengthRelation $9$, rating $10$, cluster $11$',
    'check_iTS': '$0$',
    'check_proportion': 'Verhältnis P1 zu P2 (-> Länge von P1) hProp: $0$',

    # 'check_number_of_notes': 'Anzahl der Noten',
    'count_number_of_notes': 'Anzahl der Noten',
    # 'criterion_quarterLength': 'Gesamtanzahl der Viertel (oder der jeweils für die Pythonanalyse gewählten Zähleinheiten)',
    'count_number_of_quarterLength': 'Länge in Viertelnoten',

    'check_add_criteria': 'DEPRECATED! $0$',
    'summarize_cellsContent': '$0$',

    # copies content of another column. works only of xlsxReadPreviousResults == True
    'criterion_copy': 'Übertrag aus Spalte $0$.',
    'criterion_print': 'dummytext',
    'criteria_summarize': 'DEPRECATED! summarize',
    'rename_cellContent': 'rename_cellContent $0$',


    'criteria_rename': 'rename',

    'criterion_suffix': 'Wiederholung',
    'criterion_boundary': 'Boundary',

}


# # read results from xlsx-file
# xlsxReadPreviousResults = True

# # in zfg-Tabelle exportieren
# exportToZfgTable = True
# # Dateiname für Quell-Datei
# exportToZfgTableSourceFileName = 'England Zusammenfassungstabelle mit Kriterien, befüllt.xlsx'
# # Dateiname Für Ziel-Datei
# # wenn identisch mit Vorherigem wird diese überschrieben
# exportToZfgTableTargetFileName = 'England Zusammenfassungstabelle mit Kriterien, befüllt.xlsx'
# # Spalte, in der der Identifier steht
# xlsxIdentifierCol = 'A'

# # sort order of analysis and html-output to order of xlsx-file
# # has no effect if exportToZfgTable == False
# sortDataByXlsx = True

# # determine the length of the graphs by quarterLength of the melody
# # False: use "8" for all graphs
# setGraphLengthByQuarterLength = True


# read results from xlsx-file
xlsxReadPreviousResults = config[configNumber].getboolean(
    'xlsxReadPreviousResults')

# in zfg-Tabelle exportieren
exportToZfgTable = config[configNumber].getboolean('exportToZfgTable')
# print(exportToZfgTable, type(exportToZfgTable))
# if exportToZfgTable:
#     print('export True!')

# Dateiname für Quell-Datei
exportToZfgTableSourceFileName = config[configNumber]['exportToZfgTableSourceFileName']
# Dateiname Für Ziel-Datei
# wenn identisch mit Vorherigem wird diese überschrieben
exportToZfgTableTargetFileName = config[configNumber]['exportToZfgTableTargetFileName']
# Spalte, in der der Ursprungsdentifier steht
xlsxIdentifierCol = config['GENERAL']['xlsxIdentifierCol']
# Spalte, in der der Variantidentifier steht
xlsxIdentifierVariantCol = config['GENERAL']['xlsxIdentifierVariantCol']

# sort order of analysis and html-output to order of xlsx-file
# has no effect if exportToZfgTable == False
sortDataByXlsx = config[configNumber].getboolean('sortDataByXlsx')

# determine the length of the graphs by quarterLength of the melody
# False: use "8" for all graphs
setGraphLengthByQuarterLength = config[configNumber].getboolean(
    'setGraphLengthByQuarterLength')

# new options:
# when reading the xlsx, notify if identifier doubled
notifyIfIdentifierExists = False

# do not analyze
doNotAnalyze = config[configNumber].getboolean('doNotAnalyze')

# do not export to HTML
doNotExportHTML = config[configNumber].getboolean('doNotExportHTML')

################################################################################
################################################################################
# Options
################################################################################
################################################################################


# write options and date in filenames of .html and .xlsx
writeOptionsInFilenames = config['GENERAL'].getboolean(
    'writeOptionsInFilenames')

# TODO add to separate config file

# ==============================================================================
# Parts
# ==============================================================================
# for the analysis the melody will be subdivided into parts.
# the iTS will be grouped, the position of the parts and the beginnings of the
# iTS will determine to what group the iTS belongs.

# Position where PI will end
# might be overwritten by the following options
# (in %)
# endPI = 50
endPI = int(config['GENERAL']['endPI'])

# set the special Barline as end PI
# will overwrite endPI
# specialBarlineAsEndPI = True
specialBarlineAsEndPI = config['GENERAL'].getboolean('specialBarlineAsEndPI')

# if the part left of the special barline is repeated, move end of PI to the
# end of the repetition
# (only relevant if specialBarlineAsEndPI == True)
# repetitionLeftEndAsEndPI = True
repetitionLeftEndAsEndPI = config['GENERAL'].getboolean(
    'specialBarlineAsEndPI')

# ==============================================================================
# Repetitions
# ==============================================================================
# repetitions generate varations
# different special barlines can appear:
# :|  (rep-left)  --
# |:  (rep-right) --
# :|: (rep-both)  --
# ||  (doublebar) --
# it is assumed, that there is only one special barline per melody (only the
# first* is used). a special barline marks the repetitionPoint (offset). The
# variations are created using the following options.
# if the noted repetition will be a variation, it will be marked as
# "the variation, that might have been played" (with || none will be marked).
# if no special barline appears, the only variation will be the "original".

# e.g.
# melody (4/4) with 16 bars (-> quarterLength: 64.0), :| at the end of bar #8
# [A :| B]
# (offbeat: 32.0)
# options:
# expandMelodyWithoutRepetitions = True
# expandRepetitionsAsNoted = True
# expandRepetitionsAll = False
# the following variations are created:
# v1: melody without repetitions (qL: 64.0) [A B]
# v2: melody with part left of :| repeated (qL: 96.0) [A A B]
# v2 would be marked as "the variation, that might have been played"

# * if its |: and in the first bar it is ignored as well (-> repetitions
# "ignoring" the upbeat)

# create a variation without repetition (aka ignore repetitions)
# expandMelodyWithoutRepetitions = True
expandMelodyWithoutRepetitions = config['GENERAL'].getboolean(
    'expandMelodyWithoutRepetitions')
# create a variation as it is written in the melody
# (according to our todays understanding of repetition signs)
# expandRepetitionsAsNoted = True
expandRepetitionsAsNoted = config['GENERAL'].getboolean(
    'expandRepetitionsAsNoted')
# create a variaion for every possible repetition
# expandRepetitionsAll = True
expandRepetitionsAll = config['GENERAL'].getboolean('expandRepetitionsAll')
# show only non-rep and rep-left
# warning: overides the previous options
# expandOnlyNonRepAndRepLeft = False
expandOnlyNonRepAndRepLeft = config['GENERAL'].getboolean(
    'expandOnlyNonRepAndRepLeft')


# ==============================================================================
# Criteria
# ========================================
# the length in percent of the smallest ts to find
# (quarterLength)
# tsMinLen = 5
tsMinLen = int(config['GENERAL']['tsMinLen'])

# Factor (1/x) for the length of the gracenotes
# possible: 2, 3, 4
# graceNoteFactor = 2
graceNoteFactor = int(config['GENERAL']['graceNoteFactor'])


# only analyze files and write results to disk
# do not create results.html etc.
# onlyAnalyze = False
onlyAnalyze = config['GENERAL'].getboolean('onlyAnalyze')


# analyse all files in this folder
# folder = 'xml/'
folder = config['GENERAL']['folder']

# write HTML to this file:
# options, time and .html will be appended later
# HTMLfile = 'results'
HTMLfile = config[configNumber]['HTMLfile']

# write XLSX to this file
# options, time and .xlsx will be appended later
# xlsxFileName = 'results'
xlsxFileName = config['GENERAL']['xlsxFileName']

# DEPRECATED
# # what versions of the criteria to export to xlsx
# xlsxOutputVersion1 = True
# xlsxOutputVersion2 = True
# xlsxOutputVersion3 = True

# Output format for the graphs
# either 'png' or'svg'
graphsOutputFormat = 'png'

# set this to True to activate debug-mode
debugMode = False

# print only first bound
# printOnlyFirstBound = False
printOnlyFirstBound = config['GENERAL'].getboolean('printOnlyFirstBound')

# TODO: show notes t/f

# folder to save results
savedResultsFolder = folder + '_result-saves/'

# If exist: load previous results
loadSavedResults = not True

# Save results to file
saveResults = False

# sort results of the analysis
# aka use as comparision parameter
# possible options:
# 0: quarterLength
# 1: numberOfNotes
# sortResultsBy = 0
sortResultsBy = int(config['GENERAL']['sortResultsBy'])

# reverse the order of the results
# True: longest first
# False: shortest first
# sortResultsByReverse = True
sortResultsByReverse = config['GENERAL'].getboolean('sortResultsByReverse')

# Set Font for matplotlib output
# default: 'DejaVu Sans'
# possible choices:
# mplFontName = 'Linux Libertine Mono O'
# mplFontName = 'Linux Biolinum'
# mplFontName = 'Hack'
# mplFontName = 'Open Sans'
# mplFontName = 'Estrangelo Edessa'
mplFontName = 'DejaVu Sans'

# .cache/matplotlib/fontList.json

# draw a line between the TS in the graphs
# drawBlackLineBetweenTSInGraphs = True
drawBlackLineBetweenTSInGraphs = config['GENERAL'].getboolean(
    'drawBlackLineBetweenTSInGraphs')
# DEPRECATED size of the black line
# blackLineBetweenTSInGraphWeight = 0.15
# TODO: adapt to numberOfBars

# draw a colored line in the graphs at the position of the special barline
# correction: this ist the end of PI/beginning of PII
# drawSpecialBarlinesInGraphs = True
drawSpecialBarlinesInGraphs = config['GENERAL'].getboolean(
    'drawSpecialBarlinesInGraphs')
# specialBarlineColor = 'yellow'
specialBarlineColor = config['GENERAL']['specialBarlineColor']

# add the name-label to the graphs
# graphAddLabel = True
graphAddLabel = config['GENERAL'].getboolean('graphAddLabel')

# compare notes by
# notesCompareBy:
# 0: both length and height
# 1: length // rhythm
# 2: height // pitch
# notesCompareBy = 0
notesCompareBy = int(config[configNumber]['notesCompareBy'])
# print(notesCompareBy, type(notesCompareBy))

# we need to sort by numberOfNotes because they have different length
if notesCompareBy == 2:
    sortResultsBy = 1


# remove this creators postfixes
toRemove = [' ', '-', '_', 'KS', 'BK', 'BK2', 'GL', 'PK', 'DK', 'TAKTZAHLEN']


################################################################################
################################################################################
# End of Options
# Do not change anything below, except you
# know what you are doing!
################################################################################
################################################################################

# now the fun begins
print('='*76)
'''

Do no change anything below this line!

DATA STRUCTURE:
data =
[
  [           ## first melody
    [                 ## general info
      fileName,          ## name of the file (with file-ending)
      name,              ## name (without file-ending)
      melOrg             ## original melody as parsed by music21 (stream)
    ],
    [                      ## first version (original)
      0 mel,                 ## the melody as music21-stream (only notes)
      1 numberOfBars         ## the number of bars (musically)
      2 numberOfNotes,       ## the number of the notes (int)
      3 upbeat,              ## if there is no upbeat: 0; else: qL of upbeat
      4 quarterLength,       ## total duration in quarters of mel
      5 barlines,            ## all special barlines
      6 timeSignatures,      ## all time signatures
      7 result,              ## result of analysis
      8 boundsAndColors      ## bounds and colors
      9 criteria             ## the results of the criteria for determination of the form
     10 variationName        ## the abbreviation for the variation
    ],
    [ ... ],                        ## more versions ()
  ],
  [ ... ]     ## the other melodies
]

result =
[
  [                            ## first ts
    # the ids of the first notes of the found ts (list)
    ids,
    numberOfNotes                     ## the number of notes of the ts
    (qL?)                             ## quarterLength of the ts
    [ colorGroup, colorGroupSubID]    ## the colorGroup
  ],
  ...
]

boundsAndColors =
[
  [ bound1, bound2 ],
  [ color1 ]
]

critera =
[                                          ## associated col in xslx-file
  0  identifier,               # string    # A
  1  doublebarposition,        # float     # B
  2  reprightposition,         # float     # C
  3  repleftposition,          # float     # D
  4  repbothposition,          # float     # E
  5  "",                       # string    # F
  6  "",                       # string    # G
  7  criterion1,               # bool      # H
  8  criterion2,               # bool      # I
  9  criterion3,               # bool      # J
  10 result from 7,8,9         # bool      # K
]



- name
- mel (stream)
- clean mel (only notes, stream)
- positions of special bars
- timesignatures
- # of notes
- quarterlength


STEPS:
- DONE load names of files

- DONE load data from files
- DONE save positions of special bars
- DONE analyze (identity analysis) original melody
-- sort results
- DONE create bounds
- DONE make clean melodies (for every possibility (bars) one)
-- DONE repetitions
-- grace notes

- create outputs
-- DONE lilypond-output
-- DONE "bahnstandsanzeige"
-- DONE export to HTML-file
(-- copy data from other xslx-file)
-- exort to xslx-file

- DONE print logs (duration, ...)
- delete all data of this melody (try if this works)

FEATURES:
- debugMode
- choose folder with musicxmls
- chose name of HTML-Output file
- show all ts graphs of only the master graph
- choose name of xslx-output

matplotlib:
- double axes
- unit: qL
- add barlines (not special barlines)


special bars and timeSignatures:
- rep-start can only be found at the beginning of a bar (original)
- rep-end can only be found at the end of a bar
- TODO: rep-both & doublebar ?
- timeSignatures can only be found a the beginning of a bar
- TODO: wiederholungshäuschen

TODO:
- check if folders exist and create if necessary
'''

# save the current time for the LOGS
startTime = time.time()

# add options and date to export filenames
HTMLCurrentTime = time.strftime('%Y-%m-%d-%H-%M-%S')

saveOptions = ''
if writeOptionsInFilenames:
    # values of the options for the filenames
    saveOptions += configNumber
    saveOptions += '-'+str(tsMinLen)
    saveOptions += '-1' if printOnlyFirstBound else '-0'
    saveOptions += '-' + str(sortResultsBy)
    saveOptions += '-1' if sortResultsByReverse else '-0'
    # print(saveOptions)

    HTMLfile += '_' + saveOptions + '_' + HTMLCurrentTime
    xlsxFileName += '_' + saveOptions + '_' + HTMLCurrentTime
# print('saveOptions:', saveOptions)

xlsxFileName += '.xlsx'
HTMLfile += '.html'


# xlsx-output
# make worksheet global, for performance reasons
# this will be the excel-worksheet for the output
outputWorkbook = -1
outputWorksheet = -1


def load_worksheet(fileName):
    """
    This function loads a worksheet for the xlsx-output.
    global for performance reason.
    """
    # print('='*40, 'load_worksheet()')
    global outputWorkbook, outputWorksheet
    global weHaveAProblem

    print('Loading Worksheet from "' + fileName + '"')

    if outputWorkbook == -1:
        # print('loading workbook!')
        try:
            outputWorkbook = load_workbook(filename=fileName)
        except:
            print('Could not load "' + fileName + '".')
            weHaveAProblem = True
            return -1

    # select the sheet
    if outputWorksheet == -1:
        # print('loading worksheet!')
        # select the active worksheet
        try:
            outputWorksheet = outputWorkbook.active
        except:
            print('Could not load worksheet.')
            weHaveAProblem = True
            return -1

    # print('='*40, 'end load_worksheet()')
    return 0


def save_workbook(outputFileName=''):
    """
    This function saves the worksheet to an actual xlsx-file.
    """
    # print('='*40, 'save_workbook()')
    global outputWorkbook, exportToZfgTableTargetFileName

    if outputFileName == '':
        outputFileName = exportToZfgTableTargetFileName
    # print(outputFileName)

    print('Saving Workbook to: "' + outputFileName + '"')
    outputWorkbook.save(outputFileName)

    # print('='*40, 'save_workbook()')
    return 0


def print_data(depth=3):
    """
    This function prints the var data.
    """
    global data
    print('data:')
    if depth == 1:
        print(data)
        return 0

    print('[')
    for d in data:
        if depth == 2:
            print(' ', d)
            continue

        print('  [')
        for e in d:
            if depth == 3:
                print('   ', e)
                continue

            print('    [')
            for i, f in enumerate(e):
                if depth == 4:
                    print('     ', end='')
                    if i < 10:
                        print('', end='')
                    print(i, end=' ')
                    print(f)

            print('    ]')
        print('  ]')
    print(']')


def get_filenames(folder):
    """
    This function loads the names of all xml-files in the folder.
    """
    # print('='*20, 'get_filenames()')

    # expected return:
    # [
    #   [
    #     [ name , '', 0 ]
    #   ],
    #   ...
    # ]
    global numberOfFiles

    names = []
    output = []

    # onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]

    # get a list with all the xml-files in the folder
    # for f in listdir(folder):
    fileEnding = ''
    for f in [f for f in listdir(folder) if path.isfile(path.join(folder, f))]:
        if f.endswith('.xml') or f.endswith('.musicxml'):
            names.append(f)

    # sort the names naturally
    names = natsorted(names)

    # write the number of found files to global var
    numberOfFiles = len(names)

    if numberOfFiles == 0:
        print('No file in folder \'', folder, '\'.', sep='')
    else:
        if numberOfFiles > 1:
            pl = 's'
        else:
            pl = ''
        print(numberOfFiles, ' File', pl, ' found in \'', folder, '\':', sep='')

    for name in names:
        print('\t', name)

        # get file Ending
        fileEnding = ''
        if name.endswith('.xml'):
            fileEnding = '.xml'
        elif name.endswith('.musicxml'):
            fileEnding = '.musicxml'

        output.append(
            [[name, '', 'melOrg', 'hasGracenotes', 'quarterLength', 'tS', 'cleanMel', 'result', 'melOrgGrace', 'resultGrace', 'realTS', 'upbeatQuarterLength', 'hasRepeatBrackets', fileEnding]])

    # print('='*20, 'end get_filenames()')
    return output


def load_file(folder, filename):
    """
    This function loads the file.
    """
    global debugMode
    # print('='*20, 'load_files()')

    mel = converter.parse(path.join(folder, filename))

    # check if the xml-file has some metadata, if so: remove
    # metadata corrupts the structure of the xml-file
    # aka pedros-feature
    try:
        tmp = mel[1].notes
    except:
        mel.remove(mel[1])
        try:
            tmp = mel[1].notes
        except:
            mel.remove(mel[1])

    # mel.show('text')
    # print('='*20, 'end load_files()')
    return mel


def get_barlines(mel):
    """
    This function returns a list with the special barlines and their offset.
    """
    global debugMode
    # print('='*20, 'get_barlines()')

    barlinesExtract = mel[1].flat.getElementsByClass(bar.Barline)
    # barlinesExtract.show('text')
    # print(barlinesExtract[0].offset)
    # print(mel[1][-1].offset + mel[1][-1].quarterLength)
    barlines = []
    # mel.show('text')

    # TODO:
    # ignore repeat end at the end

    # for m in mel[1]:
    #     print(m.quarterLength)

    # remove final
    # delete = []
    # for i, b in enumerate(barlinesExtract):
    #     if b.style == 'final':
    #         # print('final!')
    #         delete.insert(0, i)
    # # print(delete)
    # for d in delete:
    #     print('d:', d)
    #     barlinesExtract.pop(d)

    # barlinesExtract.show('text')

    # TODO: does this really work as intended?
    ignoreNext = False
    for i, b in enumerate(barlinesExtract):
        style = ''
        # b.show('text')
        if ignoreNext:
            ignoreNext = False
            continue
        # final not relevant
        if b.classes[0] == 'Barline':
            if b.style == 'final' \
                    or b.style == 'regular':
                # print('final or regular!')
                continue

        if b.classes[0] == 'Barline' and b.style == 'double':
            style = 'double'

            # print('b.offset:', b.offset)
            # print('', mel[1][-1].offset + mel[1][-1].quarterLength)
            # check if the double barline is at the end
            # then: no repetition
            if b.offset == mel[1][-1].offset + mel[1][-1].quarterLength:
                continue
        elif b.classes[0] == 'Repeat' and b.direction == 'end':
            # print('end!')
            style = 'end'
            # rep both has rep left and rep right
            try:
                if b.classes[0] == 'Repeat' and b.direction == 'end' and \
                        barlinesExtract[i + 1].classes[0] == 'Repeat' and barlinesExtract[i + 1].direction == 'start':
                    style = 'both'
                    ignoreNext = True
            except:
                pass

        elif b.classes[0] == 'Repeat' and b.direction == 'start':
            style = 'start'
        # barlines.append([style, b.measureNumber])
        barlines.append([style, b.offset])

    # print('barlines:', barlines)
    # print('='*20, 'end get_barlines()')
    return barlines


def get_timeSignatures(mel):
    """
    This function returns all the timeSignatures.
    """
    # print('='*20, 'get_timeSignatures()')
    tS = mel[1].flat.getElementsByClass(meter.TimeSignature).stream()

    # print('='*20,'end get_timeSignatures()')
    return tS


def get_clean_mel(mel, tS=[], isFlat=False):
    """
    This function returns a stream with only the notes of the melody.
    """
    # print('='*20, 'get_clean_mel()')

    # mel.show('text')
    # print('bla')

    if isFlat:
        newMel = copy.deepcopy(mel)
    else:
        newMel = mel[1].flat.notesAndRests.stream()
    # newMel.show('text')

    # print('='*20, 'end get_clean_mel()')
    return newMel


def find_ts_dpm(melody):
    """
    This function finds ts using a dynamic programming matrix.
    -> longest common substring
    """
    # print('='*20, 'find_ts_dpm()')
    global sortResultsBy

    # no need to change, options will be applied later
    tsMinLength = 3

    # create the matrix
    dpm = []
    for i, y in enumerate(melody):
        dpm.append([])
        # print(dpm)
        # print(y)
        # has to be "melody[:]", doesnt work with "melody"
        for j, x in enumerate(melody[:]):
            # dpm is mirrored, dont need (mirrored) doubles and comparison to itself
            if i >= j:
                dpm[i].append('-')
            else:
                dpm[i].append(0)
                # print(' ', x)

                # if note is chord:
                #   list pitches and get name of last one
                #   note.pitches[-1].name
                # if note is rest:
                #   "mark" as rest

                if x.isRest:
                    xName = 'Rest'
                else:
                    xName = x.pitches[-1].name

                if y.isRest:
                    yName = 'Rest'
                else:
                    yName = y.pitches[-1].name

                # notesCompareBy:
                # 0: both length and height
                # 1: length
                # 2: height
                if notesCompareBy == 0 and x == y:
                    dpm[i][j] = 1
                elif notesCompareBy == 1 and x.quarterLength == y.quarterLength:
                    dpm[i][j] = 1
                elif notesCompareBy == 2 and xName == yName:
                    dpm[i][j] = 1

    # reset rests beyond restIgnoreTreshold
    # first dimension reverse
    for i in range(len(dpm)):
        i = len(dpm)-i-1
        # print(dpm[i])

        for j, x in enumerate(dpm[i]):
            # if non-similar or non-rest
            if x != 1 or melody[i].name != 'rest':
                continue
            # print(i, j, '-', melody[i].name, melody[j].name)
            # check upper lefts until no rest or end of dpm
            ii = i
            jj = j

            # get total lenght of rests
            restTotalQuarterLength = melody[i].quarterLength
            while(ii > 0 and jj > 0):
                ii = ii - 1
                jj = jj - 1
                if dpm[ii][jj] == 0 or melody[ii].name != 'rest':
                    break
                restTotalQuarterLength = restTotalQuarterLength + melody[ii].quarterLength
                # print(dpm[ii][jj])
            
            # if total length of rests is too long, then remove those rests from dpm
            if restTotalQuarterLength > restIgnoreTreshold:
                # print("remove!")
                ii = i+1
                jj = j+1
                while(ii > 0 and jj > 0):
                    ii = ii - 1
                    jj = jj - 1
                    if dpm[ii][jj] == 0 or melody[ii].name != 'rest':
                        break
                    dpm[ii][jj] = 0

    # match: [ AfirstID, BfirstID, length ]
    # find all identical subsequences with positions
    matches = []
    for i, x in enumerate(dpm):
        for j, y in enumerate(x):
            # print(dpm[i][j])
            if y == 1:
                length = 1
                maxLength = min(len(melody)-j, len(melody)-i)
                for k in range(1, maxLength):
                    # print(i+k, j+1)
                    if dpm[i+k][j+k] == 1:
                        length += 1
                    else:
                        break

                # reverse order, that they are ascending
                # if long enough, then keep it
                if length >= tsMinLength:
                    matches.append([i, j, length])
                    # length in numberOfNotes

    # print the matches
    # print('Found matches (', len(matches), '):', sep='')
    # for match in matches:
    #     print('melody[', match[0], ' & ', match[1], '] with length ', match[2],
    #           ': ', melody[match[0]: match[0]+match[2]], sep='')

    matchesToDelete = []

    # find the ones, that are compared with a part of itself
    for i, match in enumerate(matches):
        if match[0] + match[-1] > match[1]:
            matchesToDelete.append(i)

    # remove doubles and delete them
    matchesToDelete = list(set(matchesToDelete))
    # print('matchesToDelete:', matchesToDelete)

    matches = [i for j, i in enumerate(matches) if j not in matchesToDelete]

    # sort the matches by length desc
    matches = sorted(matches, key=lambda x: x[-1], reverse=True)

    # # print the matches
    # print('Found matches (', len(matches), '):', sep='')
    # for match in matches:
    #     print('melody[', match[0], ' & ', match[1], '] with length ', match[2],
    #           ': ', melody[match[0]: match[0]+match[2]], sep='')

    # combine same ones
    results = []
    # results: [[ids], lengthInNotes, lengthInQuarters, [ -1 -1 ]]
    for i, match in enumerate(matches):
        # print(match[0], match[1])
        addResult = True
        for result in results:
            # has the same quarterLength
            if match[2] == result[1]:
                for r in result[0]:
                    # print(r)
                    if r == match[0]:
                        result[0].append(match[1])
                        addResult = False
                        break
                    elif r == match[1]:
                        result[0].append(match[0])
                        addResult = False
                        break
        if addResult:
            results.append([[match[0], match[1]], match[2], -1.0, [-1, -1]])

    # remove doublets
    for result in results:
        result[0] = list(set(result[0]))
        # print(result)

    # sort the results
    for result in results:
        result[0] = sorted(result[0])

    # print('\nresults:')
    # for result in results:
    #     print(result)
    # print()

    # remove the ones that are part of an other and do not appear more often
    resultsToDelete = []
    for i, result in enumerate(results):
        # print('i result:', i, result)

        for r in results[0:i]:
            # print('r:', r)
            if len(r[0]) >= len(result[0]) \
                    and r[0][0]+r[1] == result[0][0] + result[1]:
                # print('del!')
                resultsToDelete.append(i)
                break
            # print(r)
    results = [i for j, i in enumerate(results) if j not in resultsToDelete]

    # get quarterLength
    for result in results:
        if notesCompareBy == 0 or notesCompareBy == 1:
            result[2] = sum(
                [x.quarterLength for x in melody[result[0][0]:result[0][0]+result[1]]])

    # print('\nresults:')
    # for result in results:
    #     print(result)
    # print()

    # sort results:
    # 0: quarterLength
    # 1: numberOfNotes
    # print('sortResultsBy:', sortResultsBy)
    # print('sortResultsByReverse:', sortResultsByReverse)

    # if notesCompareBy == 2:
    # we need to sort by numberOfNotes because they have different length
    if notesCompareBy == 2:
        sortResultsBy = 1

    if sortResultsBy == 0:
        results = sorted(
            results, key=lambda results: results[2], reverse=sortResultsByReverse)
    elif sortResultsBy == 1:
        results = sorted(
            results, key=lambda results: results[1], reverse=sortResultsByReverse)

    # print('\nresults:')
    # for result in results:
    #     print(result)
    # print()

    # # print the matrix
    # print("\nDPM:")
    # print("  \t", end="")
    # for y in melody:
    #     print(y, "\t", end="")
    # print()
    # for i, y in enumerate(dpm):
    #     # print(sX)
    #     print(i, '\t', melody[i], "\t", end="")
    #     for j, x in enumerate(y):
    #         print(x, "\t", end="")
    #     print()

    # # print the matrix for print
    # print("\nDPM:")
    # print("      ", end="")
    # for i in range(len(melody)):
    #     print('{:<3}'.format(i), end='')
    # print()
    # print("      ", end="")
    # for y in melody:
    #     print("{:3}".format('R' if y.name == 'rest' else y.name), end='')
    # print()
    # for i, y in enumerate(dpm):
    #     print("{:2} {:<3}".format(i, 'R' if melody[i].name == 'rest' else melody[i].name), end='')
    #     for j, x in enumerate(y):
    #         print(x, " ", end="")
    #     print()
    # print('='*20, 'end find_ts_dpm()')
    return results


def make_colors(mel, bars, timeSignatures, result):
    """
    This function says which color will be used for what ts.
    timeSignatures is deprecated.
    """
    # print('='*20, 'make_colors()\n')

    # rules for the colors
    # Rotnuancen und Grünnuancen werden nach folgendem Regelsystem vergeben:
    # a) Ein Doppelstrich (DB) oder Wiederholungszeichen (RS) markiert Teil I
    #    (P I), wenn DB/RS frühestens nach 25 % der Gesamtlänge des Stücks
    #    erscheint. (In Stücken ohne DB/RS wird P I hypothetisch in den ersten
    #    50% der Gesamtlänge angenommen.) Der Rest des Stückes ist hypothetisch
    #    P II.
    # b) Alle Graphen, deren erste identische Tonfolge (iTS) in P I beginnt,
    #    erhalten eine Rotnuance, gleichgültig ob die wiederholte iTS in P I
    #    oder P II beginnt.
    # c) Alle übrigen Graphen, deren erste iTS nicht in P I beginnen, erhalten
    #    eine Grünnuance.

    # update 04.04.2018
    # iTSen, die nach dem Doppelstrich oder Wiederholungszeichen zum ersten Mal
    #    auftreten, sind grün. Wenn das Stück keinen DS oder WZ hat, werden die
    #    Graphen grün markiert, die nach der Hälfte zum ersten Mal auftreten.

    # rotnuance: basiccolor 0
    # grünnuanca: basiccolor1

    # update 12.02.2019
    # iTS has to be at least 75% in P1 to be red

    # TODO: change to length of notes (qL)
    # gesamtlänge = anzahl der noten

    # steps:
    # - get 'id' of the bar
    # - check which nuance
    # - assign nuance and increment

    # colors will be like this:
    # [ basicColor, increment ]

    # TODO: maybe we have more barlines!

    global dat, thresholdPI

    # incra/b == 0 only for repetitions
    incra = 1
    incrb = 1

    # print('dat[14]:', dat[14])
    # print('dat[16]:', dat[16])

    if not sortResultsByReverse:
        result.reverse()

    for i, ts in enumerate(result):
        # print('\ni: ', i)
        # print('ts:', ts)

        # b) Alle Graphen, deren erste identische Tonfolge (iTS) in P I beginnt,
        #    erhalten eine Rotnuance, gleichgültig ob die wiederholte iTS in P I
        #    oder P II beginnt.
        # check position of first note of ts
        # print('ts:', ts)

        # dat[14]: thresholdPI
        # print('ts[0][0]:', ts[0][0])
        # print(dat[0][ts[0][0]].offset)

        # find the actual offset for this iTS (qL)
        thisOffset = dat[14] - (ts[2] / 100 * 75)

        # determine the color
        # if dat[0][ts[0][0]].offset < dat[14]:
        if dat[0][ts[0][0]].offset < thisOffset:
            # result[i][j].append([0, incra])
            # farbnuance 0
            result[i][-1][0] = 0
            # could be set to 0 by result_add_repetiton() before
            if result[i][-1][1] == -1:
                result[i][-1][1] = incra
                incra += 1
            # result[i][-1] = [0, incra]
            # print('< threshold')
            # print('incra:', incra)
        else:
            # result[i][j].append([1, incrb])
            # farbnuance 1
            result[i][-1][0] = 1
            # could be set to 0 by result_add_repetiton() before
            if result[i][-1][1] == -1:
                result[i][-1][1] = incrb
                incrb += 1
            # result[i][-1] = [1, incrb]
            # result[i].append([1, incrb])
            # print('!< threshold')
            # print('incrb:', incrb)

    if not sortResultsByReverse:
        result.reverse()

    # print('result:')
    # for r in result:
    #     print(r)

    # print('='*20, 'end make_colors()\n')
    return result


def get_position(noteID, position='begin'):
    """"
    TODO: write docstring
    """
    # print('='*20, get_position()')

    result = 13.37

    # TODO: add differrent timeSignatures

    global dat, di
    mel = dat[0]
    # print('\n\n')
    # mel.show('text')

    # print('noteID:', noteID)

    # for note in mel:
    #     print(note.measureNumber)
    numerator = dat[6][0].numerator
    denominator = dat[6][0].denominator
    beatCount = dat[6][0].beatCount
    # print(numerator, denominator, beatCount)

    # mel[x].measureNumber == None ? dafuq?

    if position == 'end':
        result = mel[noteID].measureNumber + \
            ((mel[noteID].beat - 1 + mel[noteID].quarterLength *
              denominator / 4 * beatCount / numerator)) / beatCount
    else:
        result = mel[noteID].measureNumber + \
            ((mel[noteID].beat - 1) / beatCount)

    # print('result:', result)
    # print('='*20, get_position()')
    # return 1
    return result


def make_bounds(mel, deprecatedbarslines, result):
    """
    TODO: write docstring
    """
    # print('='*20, 'make_bounds()')
    global dat
    # global mel2
    # print(bars)
    # print('result:', result)
    # print('len(mel):', len(mel))

    # print('result:', result)
    # print('len(mel):', len(mel))

    # expected input result:
    # [
    #   [[2, 9], 4, 4.0, [0, 0]],
    #   [[1, 6], 3, 3.0, [0, 1]]
    # ]
    # [[Appearances], lengthTs, quarterLength, [basiccolor, colorincrement]], ...

    cols = [  # '#FE2E2E' # this color is too similar to #ff0000
        # red
        ['#DF0101', '#FF0000', '#FA5858', '#F78181',
            '#F5A9A9', '#F6CECE', '#F8E0E0', '#FBEFEF'],
        # green
        ['#298A08', '#31B404', '#3ADF00', '#40FF00', '#64FE2E', '#82FA58',
            '#9FF781', '#BCF5A9', '#D8F6CE', '#E6F8E0', '#F2FBEF']
        # ['#8B0000', '#bf111b', '#C71585', '#FF82AB'],
        # ['#FF82AB', '#228B22', '#32CD32', '#98FB98']
        #        ['green', 'other green', 'nothergreen', 'more green']
    ]

    # add more colors:
    # for i in range(0, 100):
    #     cols[0].append('pink')
    #     cols[1].append('yellowgreen')
    # better:
    cols[0] += ['pink'] * 100
    cols[1] += ['yellowgreen'] * 100

    bounds_result = []

    # print('result:\n', result)

    # this is a placeholder for compact_bounds
    bounds_result.append([[-1], ['black'], -1, -1.0])

    # print('dat[0].show(\'text\'):')
    # dat[0].show('text')

    # dat[0].show()

    for i, res in enumerate(result):
        # print('i res:', i, res)
        bounds = [-1]
        colors = []
        tsLen = res[1]
        # print(tsLen)
        tss = res[0]
        # print('tss:', tss)

        for sequence in tss:
            # sequcene: ID of first note of ts
            # print('sequence: ', sequence)
            # WORKING TODO: offset
            # firstPosition = get_position(sequence)
            firstPosition = dat[0][sequence].offset
            # print('firstPosition:', firstPosition)

            # only insert the new bound if it doesnt exist yet
            if len(bounds) and bounds[-1] != firstPosition:
                bounds.append(firstPosition)
                colors.append('grey')

            # TODO WORKING: offset
            # lastPosition = get_position(sequence + tsLen - 1, 'end')
            if res[2] == -1.0:
                # print('no qL')
                # print('len(dat[0]):', len(dat[0]))
                # print('sequence:', sequence)
                # print('res[1]:', res[1])
                # print('sequence+res[1]:', sequence+res[1])
                lastNote = dat[0][sequence+res[1]-1]
                lastPosition = lastNote.offset + lastNote.quarterLength
            else:
                lastPosition = dat[0][sequence].offset + res[2]
            # print('lastPosition:', lastPosition)
            bounds.append(lastPosition)

            # add the color
            # print(cols[res[3][0]][res[3][1]])
            colors.append(cols[res[3][0]][res[3][1]])

        # remove the dummy elements
        bounds.pop(0)
        colors.pop(0)

        # check if the first bound is the begin of the first note
        # TODO WORKING: offset
        # firstPosition = get_position(0)
        firstPosition = dat[0][0].offset
        if bounds[0] != firstPosition:
            bounds.insert(0, firstPosition)
            colors.insert(0, 'grey')

        # check if the last bound is the end of the last note
        # TODO WORKING: offset
        # lastPosition = get_position(len(mel) - 1, 'end')
        lastPosition = dat[0][-1].offset + dat[0][-1].quarterLength
        if bounds[-1] != lastPosition:
            bounds.append(lastPosition)
            colors.append('grey')

        bounds_result.append([bounds, colors, tsLen, res[2]])

    if debugMode:
        print('bounds_result:\n[')
        for i, bound in enumerate(bounds_result):
            print(i,'\t', bound)
        print(']')

    # expected output:
    # [
    #   [ [ -1 ], [ black ] ],
    #   [ [1, 3, 5], [r, g] , 1, 1.0],
    #   ...
    # ]

    # print('='*20, 'end make_bounds()')
    return bounds_result


def mel_add_repetition(mel, begin, end):
    """
    This function adds a repetition to the given mel.
    begin and end should match the begin/end of a note.
    """
    # WORKING
    # print('='*20, 'mel_add_repetition()')
    # print('begin end:', begin, end)
    melResult = copy.deepcopy(mel)

    notesToAdd = stream.Stream()
    for n in mel:
        if n.offset >= begin and n.offset < end:
            # print(n.offset)
            # print(n.offset-begin)
            notesToAdd.insert(n.offset, n)

    # notesToAdd.show()

    for n in notesToAdd:
        # print('insert:', n.offset, n)
        melResult.insertAndShift(n.offset, n)
    # melResult.show('text')
    # melResult.show()

    # print('='*20, 'end mel_add_repetition()')
    return melResult


def bounds_cleanup():
    """
    TODO
    This function cleans up the bounds.
    """
    # print('='*20, 'bounds_cleanup()')
    global d, di
    # print(d[i])

    # TODO: check and update if necessary

    return d[di][8]
    # TODO: make this work...
    for i, bound in enumerate(bounds):
        for j, b in enumerate(bound):
            # b => [[-1], ['black']]
            # b[0] = bounds
            # b[1] = colors
            # b[2] = quarterLength
            # b[3] = numberOfNotes

            # check al bounds if the next is the same
            prev = -42
            elementsToDelete = []
            for k, bb in enumerate(b[0][:-1]):

                if round(b[0][k], 2) == round(b[0][k + 1], 2):
                    # print('bb:', round(bb, 2))
                    # print('bb:', round(bb, 2))
                    # print(bounds[i][j][0][k])
                    elementsToDelete.append(k)

            # have to reverse the order of deletions
            elementsToDelete = sorted(elementsToDelete, reverse=True)
            # print('elementsToDelete:', elementsToDelete)
            for delID in elementsToDelete:
                # print('del:', bounds[i][j][0][delID])
                # bounds[i][j][0].pop(delID)
                # bounds[i][j][1].pop(delID)
                pass

            # print('\n=========================================\n')

    # print('='*20, 'end bounds_cleanup()')
    return -1


def bounds_compact():
    """
    TODO
    This function compacts up the bounds.
    bounds are now offsets.
    """
    # the result will be written directly to d[i][8][0]
    # print('='*20, 'bounds_compact()')

    global d, di
    bounds = d[di][8]

    boundsLen = len(bounds)
    # print('boundsLen:', boundsLen)
    # print('bounds:')
    # for b in bounds:
    #     print(b[0])
    #     print(' ', b[1])

    if boundsLen == 0:
        return [[0, 1], ['grey']]
    elif boundsLen == 1:
        return bounds[0]

    # print('bounds[0]:')
    # for b in bounds[0]:
    #     print('\t', b)

    # later fix
    bounds[0] = copy.deepcopy(bounds[1])
    bounds_result = copy.deepcopy(bounds[0])

    # print(bounds[0])

    # annahme:
    # bounds[x][0][0] ist erste bound der melodie (= anfang der ersten note)
    # bounds[x][0][-1] ist letzte bounds der melodie (= ende der letzten note)

    # this would reverse sortResultsByReverse
    # for i, thisBounds in reversed(list(enumerate(bounds[1:]))):

    for i, thisBounds in enumerate(bounds[1:]):
        # print('i:', i)
        # print('thisBounds:', thisBounds[0])
        color = thisBounds[1]
        # print('color:', color)

        for j, bound in enumerate(thisBounds[0][0:-1]):
            # print('  j:', j, ' ', bound)
            # print(thisBounds[1][j])
            thisColor = thisBounds[1][j]
            # if its grey its not relevant
            if thisColor != 'grey':
                # print('bound:', bound)

                # blubb = [1, 2, 3, 4]
                # bla = [n for n in blubb if n > 2]
                # print(bla)

                if bound in bounds_result[0]:
                    # wenn existiert:
                    # - keine neue bound einfügen
                    # - color speichern
                    # - color ändern
                    # - ende überprüfen
                    # -- wenn da: keine neue bound einfügen
                    # -- wenn nicht da: neue einfügen
                    #    und alte color wieder einfügen
                    # - überprüfen ob was zwischen anfang und ende ist
                    # -- wenn ja: löschen
                    position = bounds_result[0].index(bound)
                    # print('drin:', position)
                    # print('bounds_result[1][position]: ',
                    #       bounds_result[1][position])
                    oldCol = bounds_result[1][position]
                    bounds_result[1][position] = thisColor

                    # bounds_result[1].insert(position + 1, 'b')
                else:
                    # wenn noch nicht existiert:
                    # - einfügen
                    position = len([n for n in bounds_result[0] if n < bound])
                    # print('nicht drin:', position)
                    oldCol = bounds_result[1][position - 1]
                    bounds_result[0].insert(position, bound)
                    bounds_result[1].insert(position, thisColor)

                endBound = thisBounds[0][j + 1]

                # zwischendrin liegendes rauskicken
                elementsToDelete = [
                    n for n in bounds_result[0][position + 1:] if n < endBound]
                # print('=====')
                # print('elementsToDelete:', elementsToDelete)
                # print('bounds_result[0]: \n', bounds_result[0])
                for element in elementsToDelete:
                    # print('---')
                    # print('element:', element)
                    delID = bounds_result[0].index(element)
                    # print('delID:', delID)
                    # print('bounds_result[0]:\n', bounds_result[0])
                    # print('bounds_result[1]:\n', bounds_result[1])
                    # print('bounds_result[1][delID]:', bounds_result[1][delID])
                    oldCol = bounds_result[1][delID]
                    # print('oldCol:', oldCol)
                    bounds_result[0].pop(delID)
                    bounds_result[1].pop(delID)

                if endBound in bounds_result[0]:
                    pass
                    # print('schon da!')
                    # TODO: hier noch was ändern?
                else:
                    # print('noch nicht da!')
                    bounds_result[0].insert(position + 1, endBound)
                    bounds_result[1].insert(position + 1, oldCol)

    # write the results to the data
    # d[di][8][0] = bounds_result

    # reverse order
    results_reversed = sorted(
        dat[8][1:], key=lambda results: results[2], reverse=not sortResultsByReverse)

    dat[8] = [bounds_result] + results_reversed

    # for b in dat[8]:
    #     print(b)

    # print('bounds_result:')
    # for b in bounds_result:
    #     print(b[0])
    #     print(' ', b[1])

    # print('='*20, 'end bounds_compact()')
    # return -1


def create_graph(bounds, colors, timeSignatures=None, upbeatQuarterLength=0.0, numberOfBars=0, quarterLength=0.0, operation='save', fp='', label='', fileName='', nameAdd=''):
    """
    Create a graph.

    Keyword arguments:
    bounds -- the bounds as list
    colors -- the colors as list (len(colors) == len(bounds)-1)
    timeSignatures -- the timeSignatures of the melody as stream (default None: 4/4 will be used)
    upbeatQuarterLength -- the length of the upbeat in quarterLength (default 0.0)
    numberOfBars -- the number of the bars of the melody (default 1)
    operation -- the operation to perform: save of show (default 'save')
    fp -- path where the file will be saved if operation=save (default '')
    label -- the text of the graphs label
    fileName -- the name of the file (default '')
    nameAdd -- addition to the name (aka label) (default '')
    """
    # print('='*40, ' create_graph()')
    # print('bounds:', bounds)
    # print('colors:', colors)
    # print('numberOfBars:', numberOfBars)
    # print(timeSignatures)
    # print('dat[1]:', dat[1])

    # print('colors:')
    # for i, x in enumerate(colors[:]):
    #     print(' ', i, bounds[i], '\t', x)
    #     # colors.insert(i, 'black')

    # check if the bounds and colors are valid
    if len(bounds) - 1 != len(colors):
        print('"Bahnstandsanzeige": Error with bounds! "', label, '"', sep='')
        return 0

    if len(bounds) <= 2:
        bounds.append(bounds[-1] + 1)

    # label font properties
    font = {'fontname': mplFontName, 'horizontalalignment': 'left', 'x': 0.0}

    # create fileName
    fileName = str(fileName) + str(nameAdd)
    # print('fileName:', fileName)

    if numberOfBars != 0:
        # need timeSignatures for barlines
        tSChanges = []
        if timeSignatures is not None:
            for tS in timeSignatures:
                tSChanges.append([tS.offset, tS.numerator, tS.denominator])
        else:
            # if no timeSignature given set default 4/4
            tSChanges.append([0.0, 4, 4])

        ticks = []

        # check for upbeat
        if upbeatQuarterLength != 0:
            ticks.append(upbeatQuarterLength)
        else:
            ticks.append(0.0)

        tick = ticks[-1] if len(ticks) != 0 else 0.0

        currentTimeSignature = 0

        # for x in range(numberOfBars-1):
        while True:
            # print(tSChanges[currentTimeSignature])
            tick += tSChanges[currentTimeSignature][1] / \
                (tSChanges[currentTimeSignature][2]/4)

            try:
                if tick >= tSChanges[currentTimeSignature+1][0]:
                    currentTimeSignature += 1
            except:
                pass
            if tick >= bounds[-1]:
                break
            ticks.append(tick)

        # print('ticks:', ticks)

        # ticks = [x for x in range(
        #     upbeatQuarterLength, barQuarterLength*numberOfBars, barQuarterLength)]
        # set the names (aka numbers) of the bars
        ticklabels = [x for x in range(1, numberOfBars+1)]
        # print('ticklabels:', ticklabels)

    # note: unit for figsize is inches
    # dat[4]: quarterLength total
    if setGraphLengthByQuarterLength and quarterLength != 0.0:
        # print('dat[4]:', dat[4])
        # print('quarterLength:', quarterLength)
        width = quarterLength/10
        width = quarterLength/10
    else:
        width = 8
    # print('width:', width)
    fig, ax = plt.subplots(figsize=(width, 1))

    # TODO: resize!

    # ax = fig.add_axes([0.05, 0.475, 0.9, 0.15], label='bla')
    # ax.change_geometry(3, 1, 1)
    # n = len(fig.axes)
    # for i in range(n):

    fig.axes[0].change_geometry(4, 1, 2)

    # cmap = mpl.colors.ListedColormap(['red', 'green', 'blue', 'cyan'])
    # cmap.set_over('0.25')
    # cmap.set_under('0.75')
    cmap = mpl.colors.ListedColormap(bound[1])

    # bounds = [1, 2, 4, 7, 8]
    bounds = bound[0]
    # print(bounds)

    norm = mpl.colors.BoundaryNorm(bounds, cmap.N)
    cb = mpl.colorbar.ColorbarBase(ax, cmap=cmap,
                                   norm=norm,
                                   # boundaries=[0] + bounds + [13],
                                   boundaries=bounds,
                                   # extend='both',
                                   ticks=[],  # bounds,
                                   spacing='proportional',
                                   orientation='horizontal')

    if numberOfBars != 0:
        # make floats of ticks, could be fractions
        for i, t in enumerate(ticks):
            ticks[i] = round(float(t), 1)
        # cb2.set_ticks([1, 3, 5])
        cb.set_ticks(ticks)
        # cb2.set_ticklabels(['a', 'b', 'c'])
        cb.set_ticklabels(ticklabels)

    if graphAddLabel:
        cb.set_label(label, **font)

    if operation == 'save':
        # print(fp + 'graphs/' + fileName + '.' + graphsOutputFormat)
        try:
            plt.savefig(fp + 'graphs/' + fileName + '.' + graphsOutputFormat, bbox_inches='tight', pad_inches=0)
        except:
            # print(bounds)
            print('Fehler bei der Graphenherstellung!')
    elif operation == 'show':
        plt.show()

    plt.close(fig)
    # print('='*40, ' end create_graph()')


def criterion_identifier():
    """
    This function returns the identifier of the melody.
    """
    # print('='*40, 'criterion_identifier()')
    # description
    global criteriaCol
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_identifier', []]
    # end description
    # 0 A -- Identifier

    identifier = d[0][1]
    # print('identifier:', identifier)

    # print('='*40, 'criterion_identifier()')
    return identifier


def criterion_identifier_variant():
    """
    This function returns the identifier of the variant.
    """
    # print('='*40, 'criterion_identifier_variant()')
    # description
    global criteriaCol
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_identifier_variant', []]
    # end description
    # 0 A -- Identifier

    identifier = d[0][1] + dat[10]
    # print('identifier:', identifier)

    # print('='*40, 'criterion_identifier_variant()')
    return identifier


def criterion_numberOfBars():
    """
    This function prints the numberOfBars.
    """
    # print('='*40, 'criterion_numberOfBars()')
    # description
    global criteriaCol
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_numberOfBars', []]
    # end description
    # 3 D -- Gesamtanzahl der Takte

    numberOfBars = dat[1]

    # print('='*40, 'criterion_numberOfBars()')
    return numberOfBars


def count_number_of_quarterLength():
    """
    This function prints the quarterLength.
    """
    # print('='*40, 'count_number_of_quarterLength()')
    # description
    global criteriaCol
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'count_number_of_quarterLength', []]
    # end description
    # 4 E -- Gesamtanzahl der Viertel (oder der jeweils für die
    # 	 	 Pythonanalyse gewählten Zähleinheiten)

    quarterLength = dat[4]

    # print('='*40, 'count_number_of_quarterLength()')
    return quarterLength


def criterion_metrum():
    """
    DEPRECATED? 2018-08-21
    TODO: delete?
    This function prints the metrum.
    """
    print('deprecated? please report')
    return -1
    # print('='*40, 'criterion_metrum()')
    # 5 F -- Metrum (Taktwechsel können vermutlich nicht berücksichigt werden)

    metrum = 'DEACTIVATED metrum'

    # print('='*40, 'criterion_metrum()')
    return metrum


def criterion_barlines(barlineType):
    """
    This function returns the offsets of all barlines of a certain type.
    """
    # print('='*40, 'criterion_barlines()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if barlineType == 'both':
        barlineDescription = ':||:'
    elif barlineType == 'left':
        barlineDescription = ':||'
    elif barlineType == 'right':
        barlineDescription = '||:'
    elif barlineType == 'double':
        barlineDescription = '||'
    else:
        barlineDescription = 'invalid!'
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_barlines', [barlineDescription]]
    # end description

    # 6 G -- Es gibt einen Doppelstrich, und zwar vor der x. Viertel
    # 7 H -- Es gibt ein Wiederholungszeichen II:, und zwar vor der x. Viertel
    # 8 I -- Es gibt ein Wiederholungszeichen :II, und zwar vor der x. Viertel
    # 9 J -- Es gibt ein Wiederholungszeichen :II:, und zwar vor der x. Viertel

    if barlineType == 'left':
        barlineType = 'end'
    elif barlineType == 'right':
        barlineType = 'start'
    barlines = ''

    # check all barlines
    # if barline == barlineType, then add offset
    for rep in dat[5]:
        # print(rep)
        if rep[0] == barlineType:
            # if not first barlines, then add separator
            if barlines != '':
                barlines += ', '
            barlines += str(rep[1])

    if barlines == '':
        barlines = '-'

    # print('barlines:', barlines)
    # print('='*40, 'end criterion_barlines()')
    return barlines


def criterion_proportion(proportion=50):
    """
    This function prints the proportion between PI and PII (correct: its the lenght in %
    of PI).
    If a special barline exist its position will be used, otherwise it will
    be param proportion.

    proportion -- in percent
    """
    # print('='*40, 'criterion_proportion()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_proportion', [str(proportion), str(100-proportion)]]

    # 10 K -- Falls kein Doppelstrich oder Wiederholungszeichen angegeben ist,
    #         beträgt das Verhältnis zwischen P I und P II hypothetisch 50 % zu
    #         50 % [Option zum Ändern].
    # dat[4]: quarterLength
    # dat[5]: barlines
    # print('dat[4]:', dat[4])
    # print('dat[5]:', dat[5])

    if len(dat[5]) != 0:
        proportion = round(dat[5][0][1]/dat[4]*100, 2)

    # TODO: set var?

    # print('proportion:', proportion)
    # print('='*40, 'end criterion_proportion()')
    return proportion


def criterion_redOne(minLenPercent=10, rating=[1, 0]):
    """
    This function checks if there are two iTS in PI that have a total length of
    minLenPercent.

    minLenPercent -- minimal length of both iTS in percent

    rating:
    True: rating[0]
    False: rating[1]
    """
    # print('='*40, 'criterion_redOne()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_redOne', [str(minLenPercent)]]

    # 11 L -- Es gibt mind. einen Graphen, deren erste beiden iTS in P I LIEGEN
    #         (–> Rotnuancen) und die jeweils mind. 10 % der Gesamtlänge des
    #         Stücks umfassen [Option zum Ändern].
    # 10%: in quarterLength
    # dat[4]: quarterLength
    # dat[7]: result
    # dat[14]: thresholdPI
    thresholdPI = dat[14]

    # havent found yet
    result = rating[1]

    # get minLen in qL
    minLen = dat[4] / 100 * minLenPercent
    # print('minLen:', minLen)

    # go through all iTS
    for res in dat[7]:
        # print('res:', res)

        # check color
        # only if colorgroup == red
        if res[3][0] != 0:
            # print('  wrong color!')
            continue

        # check length
        # if no qL is set
        if res[2] == -1:
            firstLen = sum([x.quarterLength for x in dat[0]
                            [res[0][0]:res[0][0] + res[1]]])
            # print('firstLen:', firstLen)
            secondLen = sum([x.quarterLength for x in dat[0]
                             [res[0][1]:res[0][1] + res[1]]])

            # print('secondLen:', secondLen)
            # length = firstLen + secondLen

            # check lengths
            # both have to be longer or equal to minLen
            if firstLen < minLen or secondLen < minLen:
                # print('  too short!')
                continue
        else:
            # qL is set:
            length = res[2]
            # print('length:', length)

            if length < minLen:
                # print('  too short!')
                continue

        # check positions
        # if both ends are in PI, the beginnings habe to be, too
        # theoretically it would be enough to only check the second end, because
        # the first has to be before the second, therefore the first end has to
        # be before the second end
        # endFirst = dat[0][res[0][0]+res[1]-1].offset
        secondLastNote = dat[0][res[0][1]+res[1]-1]
        endSecond = secondLastNote.offset + secondLastNote.quarterLength
        # print('endSecond:', endSecond)
        # if endFirst <= dat[14] and endSecond <= dat[14]:
        if endSecond <= dat[14]:
            result = rating[0]
            # print('  found it!')
            break

    # print(result)
    # print('='*40, 'end criterion_redOne()')
    return result


def criterion_cluster(minLenPercent=15, rating=[1, 0]):
    """
    This function checks if there are two redclusters in PI with a length of at
    least minLenPercent each.

    minLenPercent -- min length of each cluster (in percent)

    rating:
    True: rating[0]
    False: rating[1]
    """
    # print('='*40, 'criterion_cluster()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_cluster', [str(minLenPercent)]]

    # 12 M -- Es gibt mind. zwei iTS-Cluster (Rotnuancen) in P I, die jeweils
    # 	 	  eine Mindeslänge von 15 % der Gesamtlänge haben [Option zum Ändern]
    # TODO: how does cluster work?
    # results.append(False)
    # dat[2]: numberOfNotes
    # dat[14]

    # DEPRECATED cluster?

    result = rating[1]

    allRes = [0]*dat[2]

    # mark all red with 1, other with 0
    for res in dat[7]:
        # all results with colorgroup=0 (red)
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allRes[x] = 1
    begin = -1
    # mResults: [begin, numberOfNotes, quarterLength]
    mResults = []
    for i, x in enumerate(allRes):
        # print('i x:', i, x)
        if x == 1:
            if begin == -1:
                begin = i
        elif x == 0:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                mResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        mResults.append([begin, length, qL])

    # check if two wanted clusters exist
    minLen = dat[4] / 100 * minLenPercent
    mFoundFirst = False
    for res in mResults:
        if res[2] > minLen:
            if mFoundFirst:
                result = rating[0]
                break
            else:
                mFoundFirst = True

    # print(result)
    # print('='*40, 'end criterion_cluster()')
    return result


def criterion_redTwo(thresholdEndPercent=66, minLenPercent=6, rating=[1, 0]):
    """
    This function checks if there is an iTS whichs first appearance is in PI and
    its last appearance is after thresholdEndPercent and if its longer than
    minLenPercent.

    thresholdEndPercent -- threshold for the iTSs last appearancees begin
                           (in percent)
    minLenPercent -- minimum lenght of each iTSs apperance (in percent)

    rating:
    True: rating[0]
    False: rating[1]
    """
    # print('='*40, 'criterion_redTwo()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_redTwo', [str(thresholdEndPercent), str(minLenPercent)]]

    # 13 N -- Es gibt mind. einen Graphen, deren erste iTS in P I und deren letzte
    # 	 	  iTS im letzten Drittel des Stücks [Option zum Ändern] beginnt
    #         (Rotnuancen), und deren Länge jeweils mind. 6 % der Gesamtlänge des
    #         Stücks [Option zum Ändern] umfasst.
    # dat[4]: qL
    result = rating[1]

    # print('dat[4]:', dat[4])

    # TODO: changeable option ("letztes Drittel")
    # NThresholdEnd
    # NThresholdEndLength
    NThreshold = dat[4] / 100 * thresholdEndPercent
    # print('NThreshold:', NThreshold)

    # TODO: 6% als Option zum Ändern anpassen
    minLen = dat[4] / 100 * minLenPercent
    # print('minLen:', minLen)

    for res in dat[7]:
        # if tsCompareBy == 2 (compare by toneHeight) we have to adjust the lengts
        lengthRight = False
        if res[2] == -1:
            firstLen = sum([x.quarterLength for x in dat[0]
                            [res[0][0]:res[0][0] + res[1]]])
            secondLen = sum([x.quarterLength for x in dat[0]
                             [res[0][-1]:res[0][-1] + res[1]]])
            if firstLen >= minLen and secondLen >= minLen:
                lengthRight = True
        else:
            length = res[2]
            if length >= minLen:
                lengthRight = True

        # if iTS is red and long enough
        if res[3][0] == 0 and lengthRight:
            # first begins in PI, last begins after thresholdN
            if dat[0][res[0][0]].offset < dat[14] and \
                    dat[0][res[0][-1]].offset > NThreshold:
                # print('found a fitting iTS!')
                # print('res:', res)
                result = rating[0]

    # print(result)
    # print('='*40, 'end criterion_redTwo()')
    return result


def criterion_greenGrey(minLenPercent=10, rating=[1, 0]):
    """
    This function checks if there is an section in PII which is not red and has
    a lenght of at least minLenPercent. After this section there is another
    section which is red.

    minLenPercent -- minimum length of the non-red section (in percent)

    rating:
    True: rating[0]
    False: rating[1]
    """
    # print('='*40, 'criterion_greenGrey()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_greenGrey', [str(minLenPercent)]]

    # 14 O -- Es gibt in P II einen Abschnitt, der nicht rot, sondern grün
    #         und/oder grau ist. Der Abschnitt umfasst mind. 10 % der Gesamtlänge
    #         [Option zum Ändern]. Nach diesem Abschnitt folgt noch einmal ein
    #         Abschnitt mit Rotnuance.
    # dat[2]: numberOfNotes
    # dat[14]: thresholdPI
    # print('dat[2]:', dat[2])
    thresholdPI = dat[14]

    # TODO: check if this is right!
    # TODO: adapt PI end for repetitions
    # OPartIILen
    result = rating[1]

    # print('dat[4] (quarterLength):', dat[4])
    # print('dat[14] (thresholdPI):', dat[14])

    allRes = [0]*dat[2]

    # Mark all red with 1, other with 0
    for res in dat[7]:
        # all results with colorgroup=0 (red)
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allRes[x] = 1
    # print('allRes:', allRes)

    begin = -1
    # mResults: [begin(id), numberOfNotes, quarterLength]
    oResults = []
    for i, x in enumerate(allRes):
        # print('i x:', i, x)
        # only non-reds (aka colorgroup != 1)
        if x == 0:
            if begin == -1:
                begin = i
        elif x == 1:
            if begin != -1:
                length = i-begin+1
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                oResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        oResults.append([begin, length, qL])
    # print('oResults:', oResults)

    # problem: if a non-red part begins before and ends after thresholdPI, and
    # is valid, then it won't be recognized as valid.
    # solution: pop the first and check again until its too short

    minLen = dat[4] / 100 * minLenPercent
    # print('minLen:', minLen)

    done = False

    # check if the wanted non-red part exists
    for res in oResults:
        # print('\nres:', res)

        # check if end is after thresholdPI
        # if its not, its not in PII at all
        lastNote = dat[0][res[0]+res[1]-1]
        # print('lastNote:', lastNote)
        end = lastNote.offset + lastNote.quarterLength
        # print('end:', end)
        if end < thresholdPI:
            # print('  end not in PII')
            continue

        # check if there is any red after it:
        # doesnt matter if the red ones are one part or multiple
        # relevant is, that single red is there.
        numberOfRedFollowing = sum(
            [1 for x in allRes[res[0]+res[1]-1:] if x == 1])
        # print('  numberOfRedFollowing:', numberOfRedFollowing)

        if numberOfRedFollowing == 0:
            # print('  no red following')
            continue

        # check the beginning of the non-red part and check the length
        while True:
            # print('   id:', res[0])
            begin = dat[0][res[0]].offset
            # print('   begin:', begin)
            if begin >= thresholdPI:
                # print('   here we are right!')

                # check the length
                length = sum(
                    [x.quarterLength for x in dat[0][res[0]:res[0]+res[1]]])
                # print('   length:', length)

                # if its long enough we found a solution
                # if its too short, we're done!
                if length >= minLen:
                    # print('   found it!')
                    done = True
                    result = rating[0]
                else:
                    # print('   its wrong!')
                    pass

                # dont need to check it shorter
                break

            # if begin is too early: pop the first
            res[0] += 1
            res[1] -= 1

        # if we found one, we can go on
        if done:
            break

    # print('result:', result)
    # print('='*40, 'end criterion_greenGrey()')
    return result


def criterion_criteria_check_bool(criteriaKeyList=[]):
    """
    Seems to be DEPRECATED!
    TODO: delete?
    This function checks if a some of the criteria are true (correct: 1).

    criteriaKeyList -- list of the keys of the criteria to check

    return: bool
    """
    print('deprecated? please report')
    # print('='*40, 'criterion_criteria_check_bool()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_criteria_check', criteriaKeyList]

    result = True

    for key in criteriaKeyList:
        # print(key, dat[17][key])
        if not dat[17][key]:
            result = False
            break

    # print(result)
    # print('='*40, 'end criterion_criteria_check_bool()')
    return result


def criterion_criteria_check(criteriaKeyList=[]):
    """
    This function checks if a some of the criteria are true (correct: 1).

    criteriaKeyList -- list of the keys of the criteria to check

    return: int
    """
    # print('='*40, 'criterion_criteria_check()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_criteria_check', criteriaKeyList]

    result = 0

    # add criteria results
    for key in criteriaKeyList:
        # print(key, dat[17][key])

        result += dat[17][key]

    # print(result)
    # print('='*40, 'end criterion_criteria_check()')
    return result


def criterion_longest_iTS_PI(rating=[1, 0]):
    """
    This function

    rating:
    True: rating[0]
    False: rating[1]
    """
    # print('='*40, 'criterion_longest_iTS_PI()')
    # description
    global criteriaCol
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_longest_iTS_PI', []]
    # end description
    # d) "Die längste iTS innerhalb von P1 ist länger als die längste iTS, die
    #    in P1 und P2 vorkommt."
    #    > Zum Verständnis: innerhalb von PI heisst, dass die iTS nur in PI
    #    > vorkommt, oder?
    #    Nein, es heißt, dass es in PI zweimal vorkommt (d.h. eine A A'-Struktur
    #    erzeugt wird); ob es auch in PII vorkommt, ist für die Erzeugung der
    #    A A'-Struktur nicht relevant. Relevant scheint aber zu sein, dass die
    #    A A'-Struktur ausgeprägter ist als die A A''-Struktur (Rundung) - und zwar
    #    deshalb, weil eine ausgeprägte A A''-Struktur eine A B A-Form erzeugt.
    #    D.h. das Kriterium hat zum Ziel, eine Verwechselung zwischen A B A-Form
    #    und A A' B A''-Form auszuschließen.
    #    Bin mir nicht sicher, ob das nachvollziehbar ist. ;-)
    # longest -> qL
    # dat[7]: result
    # dat[14]: thresholdPI (offset)
    # print('dat[14]:', dat[14])
    # print('qL:', dat[4])

    thresholdPI = dat[14]
    # print('thresholdPI:', thresholdPI)

    result = rating[1]

    # dat[7] is sorted by [2] (quarterLength)

    # get length of longest iTS that is twice in PI
    # -> end of second appearance offset is < thresholdPI
    longestPI = -1
    for res in dat[7]:
        # print('res:', res)
        # print('len(dat[0]):', len(dat[0]))
        # print('res[0][1]+res[1]-1:', res[0][1]+res[1]-1)
        secondLastNote = dat[0][res[0][1]+res[1]-1]
        secondEnd = secondLastNote.offset+secondLastNote.quarterLength
        # print('secondEnd:', secondEnd)
        if secondEnd < thresholdPI:
            # print('right!')
            longestPI = res[2]
            break
    # print('longestPI:', longestPI)

    # get length of longest iTS that is in PI and in PII
    # -> end of first appearance offset is < thresholdPI
    # -> and begin of another appearance offset is > thresholdPI
    longestPII = -1
    for res in dat[7]:
        # print('res:', res)
        firstLastNote = dat[0][res[0][0]+res[1]-1]
        firstEnd = firstLastNote.offset+firstLastNote.quarterLength
        # check if first is in PI
        if firstEnd < thresholdPI:
            for ress in res[0][1:]:
                thisBegin = dat[0][ress].offset
                # print('thisBegin:', thisBegin)
                if thisBegin > thresholdPI:
                    longestPII = res[2]
                    # print('done!')
                    break
        if longestPII != -1:
            break
    # print('longestPII:', longestPII)

    # compare both
    if longestPI > longestPII:
        result = rating[0]

    # print('result:', result)
    # print('='*40, 'end criterion_longest_iTS_PI()')
    return result


def criterion_greenGreyLong(rating=[0, 1]):
    """
    This function checks if the longest green/grey section of pII is longer than
    the longest green/grey section of pI.

    False: rating[0]
    True: rating[1]
    """
    # print('='*40, 'criterion_greenGreyLong()')
    # description
    global criteriaCol
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_greenGreyLong', []]
    # end description
    # e "Der längste grün/graue Abschnitt in P2 ist länger als der längste graue
    #   Abschnitte in P1."
    # dat[2]: numberOfNotes
    # dat[14]: threshold PI (offset)

    result = rating[0]

    pINumberOfNotes = sum([1 for x in dat[0] if x.offset < dat[14]])
    # print('pINumberOfNotes', pINumberOfNotes)

    # --------------------
    # get pI with 1 as grey
    # --------------------
    allResGrey = [1]*dat[2]
    # mark all grey with 1, other with 0
    # get grey (-> 1)
    for res in dat[7]:
        # all results (non-results are grey)
        if True:  # res[-1][0] == 1:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allResGrey[x] = 0

    # get only the notes of pI
    pI = allResGrey[: pINumberOfNotes]
    # print('pI:', pI)

    # get results of pI
    begin = -1
    # mResults: [begin, numberOfNotes, quarterLength]
    pIResults = []
    for i, x in enumerate(pI):
        # print('i x:', i, x)
        if x == 1:
            if begin == -1:
                begin = i
        else:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                pIResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        pIResults.append([begin, length, qL])
    # print('pIResults:', pIResults)

    # --------------------
    # get pII with 1 as green/grey
    # --------------------
    allResGreenGrey = [1]*dat[2]
    # mark all red with 0, other with 1
    # get green/grey (-> 1)
    for res in dat[7]:
        # remove all results with colorgroup=0 (red)
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allResGreenGrey[x] = 0

    # get only the notes of pII
    pII = allResGreenGrey[pINumberOfNotes:]
    # print('pII:', pII)

    # get results of pII
    begin = -1
    # mResults: [begin, numberOfNotes, quarterLength]
    pIIResults = []
    for i, x in enumerate(pII):
        # print('i x:', i, x)
        if x == 1:
            if begin == -1:
                begin = i
        else:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                pIIResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        pIIResults.append([begin, length, qL])
    # print('pIIResults:', pIIResults)

    # --------------------
    # compare the results (by quarterLength)
    # --------------------
    pILongest = 0
    pIILongest = 0
    for seq in pIResults:
        # seq[2]: quarterLength
        if seq[2] > pILongest:
            pILongest = seq[2]
    for seq in pIIResults:
        if seq[2] > pIILongest:
            pIILongest = seq[2]

    # print('pILongest:', pILongest)
    # print('pIILongest:', pIILongest)

    if pIILongest > pILongest:
        result = rating[1]

    # print(result)
    # print('='*40, 'end criterion_greenGreyLong()')
    return result


def criterion_ending(maxLenQL=-1, maxLenPercent=-1, rating=[-4, 1]):
    """
    This function checks if the ending is not red and longer than minLenPercent.

    minLenPercent -- maximal length of non-red-part at the end in percent
    maxLenQL -- maximal length of non-red-part at the end in quarterLength

    rating:
    True: rating[0]   // returns -4
    False: rating[1]  // returns 1

    return: int
    """
    # print('='*40, 'criterion_ending()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    # f "Falls die letzten Takte in P2 grau/grün sind (d.h. nicht rot, wie es
    #   häufig der Fall ist) dann ist dieser Abschnitt nicht länger als xy
    #   Prozent."
    # dat[0]: mel
    # dat[4]: qL

    # 1 = False
    result = rating[1]

    criterionValue = ''
    if maxLenQL >= 0:
        maxLen = maxLenQL
        criterionValue = str(maxLenQL) + ' qL'
    elif maxLenPercent >= 0:
        maxLen = dat[4] / 100 * maxLenPercent
        criterionValue = str(maxLenPercent) + ' %'
    else:
        print('  Warning: criterion_ending(): invalid parameter!')
        return 'Invalid parameter!'
    # print('maxLen:', maxLen)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_ending', [criterionValue]]

    # get non-red-notes
    allNonRed = [1]*dat[2]
    # mark all non-red with 1, other with 0
    # get non-red (-> 1)
    for res in dat[7]:
        # remove red ones from list
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allNonRed[x] = 0
    # print('allNonRed:', allNonRed)

    threshold = dat[4]-maxLen

    for i in reversed(range(0, len(allNonRed))):
        # print(dat[0][i].offset)
        # check if its red
        if allNonRed[i] == 0:
            # print('its red')
            result = 1
            break

        # check if its in the relevant part
        if dat[0][i].offset < threshold:
            # print('threshold reached')
            result = rating[0]
            break

    # print('result:', result)
    # print('='*40, 'end criterion_ending()')
    return result


def criterion_copy_from_zfgTable(col='A', identifierCol='T',
                                 sourceFile='England Zsfg-Tabelle - BK.xlsx', table='Tabelle1'):
    """
    This function copies a cell from the Zusammenfassungstabelle with the same
    identifier.

    WARNING: depending on the number of columns this can be very slow!

    col -- the column from where to copy
    """
    # print('='*40, 'criterion_copy_from_zfgTable()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_copy_from_zfgTable', [col]]
    # end description

    # b Eine Option, die es erlaubt, die Daten aus einer beliebigen Anzahl von
    #   ausgewählten Spalten aus der Gesamttabelle (Dateinamen im Script
    #   eingeben) in beliebige Spalten zu übertragen.
    # dat[1]: name w/o ending
    # identifier in xlsx: "Begg3_0-1729-95-3"
    result = -1

    identifier = d[0][1]
    # TODO: remove end
    removeIt = True
    while removeIt:
        removeIt = False
        for rem in toRemove:
            if identifier[-len(rem):] == rem:
                # print('rem:', rem)
                # print('remove "' + rem + '"')
                identifier = identifier[: -len(rem)]
                # print('identifier:', identifier)
                removeIt = True
    # print(identifier)

    # load workbook
    wb = load_workbook(filename=sourceFile)
    # select the sheet
    sheet_ranges = wb[table]

    # number of the first line with content
    i = 1
    while True:
        cell = identifierCol+str(i)
        # print(i, sheet_ranges[cell].value)
        if sheet_ranges[cell].value == None:
            break

        if sheet_ranges[cell].value == identifier:
            # print('have it!')
            result = sheet_ranges[col+str(i)].value
            break

        i += 1

    # print('result:', result)
    # print('='*40, 'end criterion_copy_from_zfgTabl()')
    return result


def criterion_greenRed(thresholdRed=66, thresholdRedLenHigh=6, thresholdRedLenLow=3, minLenPercent=6, rating=[1, 0.5, 0]):
    """
    This function checks if there is a red iTS after a non-red iTS with
    minLenPercent after thresholdRed.
    If it is, its length is checked with thresholdRedLenHigh/Low for return
    values. If it doesnt match 0 is returned.

    thresholdRed: in Prozent, iTS kommt danach vor
    thresholdRedLenHigh: threshold für 1
    thresholdRedLenLow: threshold für 0.5
    minLenPercent: min Länge der nicht-roten iTS

    rating:
    exists and between thresholdRedLenHigh and thresholdRedLenLow: rating[0]
    exists and smaller then thresholdRedLenLow: rating[1]
    does not exist: rating[2]

    """
    # print('='*40, 'criterion_greenRed()')
    # "Es gibt eine rote iTS mit den Parametern (66, >=3 und <6) [komplementär
    # zu 66, 6), die NACH einer grün-grauen iTS mit dem Parameter (6) liegt."
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_greenRed', [str('TODO'), thresholdRed, thresholdRedLenHigh, thresholdRedLenLow, minLenPercent]]
    # end description

    result = rating[2]

    # get non-red-notes
    allRed = [0]*dat[2]
    # mark all red with 1, other with 0
    # get red (-> colorgroup == 0)
    for res in dat[7]:
        # remove non-red ones from list
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allRed[x] = 1
    # print('allRed:', allRed)

    # add thresholdRed

    # get results of non-red
    begin = -1
    # nonredResults: [begin, numberOfNotes, quarterLength]
    nonredResults = []
    for i, x in enumerate(allRed):
        # print('i x:', i, x, dat[0][i].offset)
        if x == 0:
            if begin == -1:
                begin = i
        else:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                nonredResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        nonredResults.append([begin, length, qL])
    # print('nonredResults:', nonredResults)

    # check if there is a relevant non-red iTS
    nonredMinLen = dat[4] / 100 * minLenPercent
    nonredEnd = -1
    # print('nonredMinLen:', nonredMinLen)
    for res in nonredResults:
        # print('res:', res)
        if res[2] >= nonredMinLen:
            # print('got it!')
            lastNote = dat[0][res[0]+res[1]-1]
            nonredEnd = lastNote.offset + lastNote.quarterLength
            break
    # print('nonredEnd:', nonredEnd)

    # if there is no fitting iTS (non-red and minLenPercent) then there is no
    # need to go on -> return 0
    if nonredEnd > 0:
        # get red results after nonredEnd
        # get results of red
        begin = -1
        # redResults: [begin, numberOfNotes, quarterLength]
        redResults = []
        for i, x in enumerate(allRed):
            # print('i x:', i, x, dat[0][i].offset)
            if x == 1 and dat[0][i].offset >= nonredEnd:
                if begin == -1:
                    begin = i
            else:
                if begin != -1:
                    length = i-begin
                    qL = sum(
                        [x.quarterLength for x in dat[0][begin:begin+length]])
                    redResults.append([begin, length, qL])
                    begin = -1

        if begin != -1:
            length = i-begin+1
            qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
            redResults.append([begin, length, qL])
        # print('redResults:', redResults)

        # check for lengths
        redMinLenHigh = dat[4] / 100 * thresholdRedLenHigh
        # print('redMinLenHigh:', redMinLenHigh)
        redMinLenLow = dat[4] / 100 * thresholdRedLenLow
        # print('redMinLenLow:', redMinLenLow)
        redLowFound = False

        for res in redResults:
            # print('res:', res)
            if res[2] >= redMinLenHigh:
                # print('found the long one')
                result = rating[0]
                break
            elif not redLowFound and res[2] >= redMinLenLow:
                # print('found the short one')
                redLowFound = True

        if result == 0 and redLowFound:
            result = rating[1]

    # print('='*40, 'end criterion_greenRed()')
    return result


def criterion_greenPII(minLenPercent, rating=[-1, 0]):
    """
    This function checks if there are two non-red parts in PII longer then
    minLenPercent.

    minLenPercent -- min length of non-red parts in percent

    rating:
    If True: rating[0]   //return -1
    If False: rating[1]  // reuturn 0
    """
    # print('='*40, 'criterion_greenPII()')
    # > zwei längere grün-graue Abschnitte (Mindestlänge xy Prozent) in P2
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_greenPII', [str(minLenPercent)]]
    # end description

    # dat[14]: offset, end of PI, begin of PII

    result = rating[1]

    # get non-red-notes
    allRed = [0]*dat[2]
    # mark all red with 1, other with 0
    # get red (-> colorgroup == 0)
    for res in dat[7]:
        # remove non-red ones from list
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allRed[x] = 1
    # print('allRed:', allRed)

    # get results of non-red
    begin = -1
    # nonredResults: [begin, numberOfNotes, quarterLength]
    nonredResults = []
    for i, x in enumerate(allRed):
        # print('i x:', i, x, dat[0][i].offset)
        if x == 0:
            if begin == -1:
                begin = i
        else:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                nonredResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        nonredResults.append([begin, length, qL])
    # print('nonredResults:', nonredResults)

    # check if the searched non-red parts exist
    minLenQL = dat[4] / 100 * minLenPercent
    # print('minLenQL:', minLenQL)
    # print('dat[14]:', dat[14])
    numberFound = 0
    for res in nonredResults:
        # print('res:', res)
        # check position
        begin = dat[0][res[0]].offset
        # print('  begin:', begin)
        if begin >= dat[14]:
            # print('  right position!')
            # check length
            if res[2] >= minLenQL:
                # print('  right length')
                numberFound += 1

        if numberFound == 2:
            # print('  got 2!')
            result = rating[0]
            break

    # print('result:', result)
    # print('='*40, 'end criterion_greenPII()')
    return result


def criterion_redInHalfs(rating=[1, 0]):
    """
    This function checks if there is a pair of iTS in PI with one in the first
    half of PI and one in the second half of PI

    rating:
    True: rating[0]
    False: rating[1]

    return:
    if pair exists: 1
    if pair doesnt exist: 0
    """
    # print('='*40, 'criterion_redInHalfs()')
    # description
    global criteriaCol
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_redInHalfs', []]
    # end description

    # „Es gibt ein iTS-Paar in P1, das so verteilt ist, dass die erste iTS in
    # der ersten und die zweite iTS in der zweiten Hälfte von P1 liegen.“
    # Der genaue Ort der beiden iTS soll dabei relativ unbestimmt bleiben,
    # damit nicht Fälle ausgeschlossen werden, bei denen es sich um srttpfs
    # handelt. Es genügt, wenn der Großteil der iTSs jeweils in der ersten und
    # der zweiten Hälfte von P1 liegen. Lässt sich das programmieren?

    # new:
    # 2xRed jeweils in einer Hälfte von P1 --> A A. Es gibt ein iTS-Paar in P1,
    # das so verteilt ist, dass die erste iTS in der ersten und die zweite iTS
    # in der zweiten Hälfte von P1 liegen.

    # dat[7]: result
    # dat[14]: threshold PI

    thresholdFirstHalf = dat[14]/2
    thresholdSecondHalf = dat[14]
    # print('thresholdFirstHalf thresholdSecondHalf',
    #       thresholdFirstHalf, thresholdSecondHalf)

    result = rating[1]

    for res in dat[7]:
        # print('res:', res)

        # check first
        # has to be in the first half of PI
        # -> end <= thresholdFirstHalf
        firstBegin = dat[0][res[0][0]].offset
        firstLastNote = dat[0][res[0][0]+res[1]-1]
        firstEnd = firstLastNote.offset + firstLastNote.quarterLength
        if firstEnd <= thresholdFirstHalf:
            # print('  first is right!')

            # check second
            # has to be in the second half of PI
            # -> begin >= thresholdFirstHalf
            # -> end <= thresholdSecondHalf
            secondBegin = dat[0][res[0][1]].offset
            secondLastNote = dat[0][res[0][1]+res[1]-1]
            secondEnd = secondLastNote.offset + secondLastNote.quarterLength
            if secondBegin >= thresholdFirstHalf \
                    and secondEnd <= thresholdSecondHalf:
                # print('  second is right!')
                result = rating[0]
                break

    # print('result:', result)
    # print('='*40, 'end criterion_redInHalfs()')
    return result


def criterion_green_grey_PII(minLenPercent, rating=[-1, 0]):
    """
    This function checks if there are two non-red parts in PII with
    minLenPercent.

    rating:
    True: rating[0]
    False: rating[1]

    return:
    if they exist: -1
    if they dont exist: 0

    minLenPercent -- min lenght of the non-red parts in percent
    """
    # print('='*40, 'criterion_green_grey_PII()')
    global criteriaCol
    # print('criteriaCol', criteriaCol)

    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_green_grey_PII', [str(minLenPercent)]]
    # end description
    # Neues Negativkriterien (hatte ich noch nicht erwähnt):
    # zwei längere grün-graue Abschnitte (Mindestlänge xy Prozent) in P2
    # dat[14]: threshold PI
    thresholdPI = dat[14]

    result = rating[1]

    minLenQL = dat[4] / 100 * minLenPercent

    # get non-red-notes
    allRed = [0]*dat[2]
    # mark all red with 1, other with 0
    # get red (-> colorgroup == 0)
    for res in dat[7]:
        # remove non-red ones from list
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allRed[x] = 1
    # print('allRed:', allRed)

    # get results of non-red
    begin = -1
    # nonredResults: [begin, numberOfNotes, quarterLength]
    nonredResults = []
    for i, x in enumerate(allRed):
        # print('i x:', i, x, dat[0][i].offset)
        if x == 0:
            if begin == -1:
                begin = i
        else:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                nonredResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        nonredResults.append([begin, length, qL])
    # print('nonredResults:', nonredResults)

    # find ts
    first = False
    for res in nonredResults:
        # print('res:', res)

        begin = dat[0][res[0]].offset
        lastNote = dat[0][res[0]+res[1]-1]
        end = lastNote.offset + lastNote.quarterLength

        if begin >= thresholdPI and res[2] >= minLenQL:
            if not first:
                # print('  first found!')
                first = True
            else:
                # print('  second found!')
                result = rating[0]
                break

    # print('result:', result)
    # print('='*40, 'end criterion_green_grey_PII()')
    return result


def criterion_last_red(minLenPercent=5, redThresholdPercent=13, rating=[1, 0]):
    """
    This function
    """
    # print('='*40, 'criterion_last_red()')
    # das letzte Rot in P2 ist nicht kürzer als 5 % (Option zum Ändern)) und liegt nicht
    # weiter vom Ende fort als 13 % (Option zum Ändern) –> 1 (sonst 0)
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_last_red', [minLenPercent, redThresholdPercent]]
    # end description
    print(dat[7])
    # if there is no iTS at all
    if len(dat[7]) == 0:
        return rating[1]

    # get red
    allRed = [0]*dat[2]
    # mark all red with 1, other with 0
    # get red (-> colorgroup == 0)
    for res in dat[7]:
        # print(res)
        # fill reds with 1
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allRed[x] = 1
    # print('allRed:', allRed)

    # get results of red
    begin = -1
    # redResults: [begin, numberOfNotes, quarterLength]
    redResults = []
    for i, x in enumerate(allRed):
        # print('i x:', i, x, dat[0][i].offset)
        if x == 1:
            if begin == -1:
                begin = i
        else:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                redResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        redResults.append([begin, length, qL])
    # print('redResults:', redResults)

    # if there is no iTS at all
    if len(redResults) == 0:
        return rating[1]

    # get length and position (begin) of last red
    lastRedLengthQL = redResults[-1][2]
    minLen = dat[4] / 100 * minLenPercent
    lastRedBeginQL = dat[0][redResults[-1][0]].offset
    redThreshold = dat[4] / 100 * (100-redThresholdPercent)
    # print('lastRedLengthQL:', lastRedLengthQL)
    # print('minLen:', minLen)
    # print('lastRedBeginQL:', lastRedBeginQL)
    # print('redThreshold:', redThreshold)

    # check length and position
    if lastRedLengthQL >= minLen \
            and lastRedBeginQL >= redThreshold:
        result = rating[0]
    else:
        result = rating[1]

    # result = -1

    # print('result:', result)
    # print('='*40, 'end criterion_last_red()')
    return result


def criterion_short_red(minLenPercent=3, redThresholdEndPercent=17, redThresholdBeginPercent=33, rating=[0.5, 0]):
    """
    This function

    TODO: lot copynpaste from criterion_last_red. make this better!
    redThresholdBeginPercent is a nonsaying name
    'längerer Rotabschnitt' == länger als der letzte?
    """
    # print('='*40, 'criterion_short_red()')
    # es gibt ein kürzeres Rot (nicht kürzer als 3% (Option zum Ändern)), das nicht weiter vom Ende entfernt liegt
    # als 17 % (Option zum Ändern)
    # und durch einen längeren Rotabschnitt an anderer Stelle in P2, jedoch nicht früher
    # beginnend als nach dem ersten Drittel von P2 (Option zum Ändern) ergänzt wird --> 0,5 (sonst 0)
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_short_red', [minLenPercent, redThresholdEndPercent, redThresholdBeginPercent]]
    # end description

    # if there is no iTS at all
    if len(dat[7]) == 0:
        return rating[1]

    result = -1

    # get red
    allRed = [0]*dat[2]
    # mark all red with 1, other with 0
    # get red (-> colorgroup == 0)
    for res in dat[7]:
        # print(res)
        # fill reds with 1
        if res[-1][0] == 0:
            # merge all to one
            for r in res[0]:
                for x in range(r, r+res[1]):
                    allRed[x] = 1
    # print('allRed:', allRed)

    # get results of red
    begin = -1
    # redResults: [begin, numberOfNotes, quarterLength]
    redResults = []
    for i, x in enumerate(allRed):
        # print('i x:', i, x, dat[0][i].offset)
        if x == 1:
            if begin == -1:
                begin = i
        else:
            if begin != -1:
                length = i-begin
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                redResults.append([begin, length, qL])
                begin = -1

    if begin != -1:
        length = i-begin+1
        qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
        redResults.append([begin, length, qL])
    # print('redResults:', redResults)

    if len(redResults) == 0:
        return rating[1]

    # get length and position (begin) of last red
    lastRedLengthQL = redResults[-1][2]
    minLen = dat[4] / 100 * minLenPercent
    lastRedBeginQL = dat[0][redResults[-1][0]].offset
    redThreshold = dat[4] / 100 * (100-redThresholdEndPercent)
    # print('lastRedLengthQL:', lastRedLengthQL)
    # print('minLen:', minLen)
    # print('lastRedBeginQL:', lastRedBeginQL)
    # print('redThreshold:', redThreshold)

    # check length and position
    if lastRedLengthQL >= minLen \
            and lastRedBeginQL >= redThreshold:
        # last red is correct, now check the remaining
        # und durch einen längeren Rotabschnitt an anderer Stelle in P2, jedoch nicht früher
        # beginnend als nach dem ersten Drittel von P2 (Option zum Ändern) ergänzt wird --> 0,5 (sonst 0)
        thresholdPI = dat[14]
        # TODO: change name, this is nonsaying
        thresholdPII = (dat[4]-thresholdPI) / 100 * redThresholdBeginPercent
        beginThreshold = thresholdPI + thresholdPII
        # print('beginThreshold:', beginThreshold)

        for res in redResults[:-1]:
            # print(res)
            thisQL = res[2]
            thisBeginQL = dat[0][res[0]].offset
            # print('thisQL:', thisQL)
            # print('beginQL:', thisBeginQL)

            if thisQL > lastRedLengthQL \
                    and thisBeginQL >= beginThreshold:
                result = rating[0]
            else:
                result = rating[1]

        # result = rating[0]
    else:
        result = rating[1]

    # print('result:', result)
    # print('='*40, 'end criterion_short_red()')
    return result


def criterion_copy(copyFrom):
    """
    This function copies from another column.

    copyFrom -- the column to copy
    """
    # print('='*40, 'criterion_copy()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_copy', [copyFrom]]
    # end description

    result = outputWorksheet[copyFrom+str(baseID)].value

    # print('result:', result)
    # print('='*40, 'end criterion_copy()')
    return result


def criterion_print(text=''):
    """
    This function prints text to the cell.
    """
    # print('='*40, 'criterion_print()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_print', []]
    # end description

    result = str(text)

    # print('result:', result)
    # print('='*40, 'end criterion_print()')
    return result


def rename_cellContent(source='AC', target='AD', sep=';', action='append'):
    """
    TODO: rename criteria_summarize_helper()?

    This function summarizes the criteria.
    e.g. 'a1;b2;c3' becomes 'tsrttpf strong'

    source -- source column
    criteria -- criteria to be true
    rating -- text to print to xlsx if criteria are true
    sep -- separator if cell is not empty
    action -- tbd
    """
    # print('='*40, 'rename_cellContent()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'rename_cellContent', [source]]
    # end description

    oldValue = outputWorksheet[target+str(baseID)].value
    # print('oldValue:', oldValue)
    if oldValue == None:
        result = ''
    else:
        result = oldValue

    sourceValue = dat[17][source]
    # print('sourceValue:', sourceValue)

    if sourceValue == None:
        result = 'no input'
        return result

    for p in criteriaPool:
        # print('p:', p)
        criteriaResult = criteria_summarize_helper(sourceValue, p[0], p[1])
        # print(criteriaResult)
        if criteriaResult != '':
            if result != '':
                result += sep
            result += criteriaResult

    if result == '':
        result += 'no valid found'
    # print('result:', result)

    # sourceValue = outputWorksheet[source+str(baseID)].value
    # print(source, str(baseID), ': ', sourceValue, sep='')

    # del?
    # sourceValue = dat[17][source]
    # print('sourceValue:', sourceValue)
    # sourceCriteria = sourceValue.split(';')
    # print(sourceCriteria)

    # print('sourceCriteria:', sourceCriteria)
    # print('result:', result)
    # print('='*40, 'end rename_cellContent()')
    return result


def criteria_summarize(source='AC', target='AD', sep=';', action='append'):
    """
    DEPRECATED?
    predecessor of rename_cellContent

    This function summarizes the criteria.

    source -- source column
    criteria -- criteria to be true
    ratine -- text to print to xlsx if criteria are true
    sep -- separator if cell is not empty
    action -- tbd
    """
    # print('='*40, 'criteria_summarize()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criteria_summarize', []]
    # end description

    oldValue = outputWorksheet[target+str(baseID)].value
    # print('oldValue:', oldValue)
    if oldValue == None:
        result = ''
    else:
        result = oldValue

    sourceValue = dat[17][source]
    # print('sourceValue:', sourceValue)

    if sourceValue == None:
        result = 'no input'
        return result

    for p in criteriaPool:
        # print('p:', p)
        criteriaResult = criteria_summarize_helper(sourceValue, p[0], p[1])
        # print(criteriaResult)
        if criteriaResult != '':
            if result != '':
                result += sep
            result += criteriaResult

    if result == '':
        result += 'no valid found'
    # print('result:', result)

    # sourceValue = outputWorksheet[source+str(baseID)].value
    # print(source, str(baseID), ': ', sourceValue, sep='')

    # del?
    # sourceValue = dat[17][source]
    # print('sourceValue:', sourceValue)
    # sourceCriteria = sourceValue.split(';')
    # print(sourceCriteria)

    # print('sourceCriteria:', sourceCriteria)
    # print('result:', result)
    # print('='*40, 'end criteria_summarize()')
    return result


def criteria_summarize_helper(sourceCriteria='a1;b2;c1', criteria='a1;b*;c3', rating='srttpf strong', sep=';'):
    """
    This function summarizes the criteria.

    source -- source column
    criteria -- criteria to be true
    rating -- text to print to xlsx if criteria are true
    """
    # print('='*40, 'criteria_summarize_helper()')
    # description

    # oldValue = outputWorksheet[target+str(baseID)].value
    # if oldValue == None:
    #     result = ''
    # else:
    #     result = oldValue

    # sourceValue = outputWorksheet[source+str(baseID)].value
    # print(source, str(baseID), ': ', sourceValue, sep='')
    # sourceValue = dat[17][source]
    # print('sourceValue:', sourceValue)
    sourceCriteria = sourceCriteria.split(';')
    # print('sourceCriteria:', sourceCriteria)

    criteria = criteria.split(';')
    # criteria[1] = 'b*2'
    # criteria.append('d4')
    # print('criteria:', criteria)

    # possibilities:
    # a1
    # a*
    # a*2
    # aa10

    result = ''
    found = True

    for criterion in criteria:
        # print('criterion:', criterion)

        if '*' in criterion:
            # print('*')
            thisCriterion = criterion.split('*')
            # print(thisCriterion)
            criterionBase = thisCriterion[0]
            if thisCriterion[1] == '':
                criterionNumber = 1
            else:
                criterionNumber = int(thisCriterion[1])
            # print('criterionBase criterionNumber:',
            #       criterionBase, criterionNumber)

            criterionCount = 0

            # find all criteria
            for sC in sourceCriteria[:]:
                # print('sC:', sC)
                if criterionBase in sC:
                    criterionCount += 1
                    sourceCriteria.remove(sC)
                    # print('drinne')
                if criterionCount == criterionNumber:
                    # print('halt stop!')
                    break

            # print('criterionCount:', criterionCount)
            if criterionCount < criterionNumber:
                # print('not enough found')
                found = False
                break

        else:
            # remove if exists. if not exists: not valid, break
            try:
                sourceCriteria.remove(criterion)
            except:
                found = False
                break

    if found:
        # recheck sourceCriteria
        if len(sourceCriteria) == 0:
            if result != '':
                result += sep
            result += rating
            # print('passt, nech?')
        # else:
        #     print('nope!')

    # print('sourceCriteria:', sourceCriteria)
    # print('result:', result)
    # print('='*40, 'end criteria_summarize_helper()')
    return result


def criteria_rename(source='AC'):
    """
    This function renames the results of summarize.
    """
    # print('='*40, 'criteria_rename()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criteria_rename', []]
    # end description

    try:
        sourceValue = dat[17][source]
        result = criteriaRenamePool[sourceValue]
    except:
        result = ''

    # print('result:', result)
    # print('='*40, 'end criteria_rename()')
    return result


def criterion_suffix():
    """
    This function returns the (renamed) repetition-suffix.
    """
    # print('='*40, 'criterion_suffix()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_suffix', []]
    # end description

    # print(dat[10])

    substitute = {
        # double bars
        '_d0':  'or',
        '_d0g': 'or',
        '_d1':  'le',
        '_d1g': 'le',
        '_d2':  're',
        '_d2g': 're',
        '_d3':  'bo',
        '_d3g': 'bo',

        # rep-both
        '_b0':  'or',
        '_b0g': 'or',
        '_b1':  'le',
        '_b1g': 'le',
        '_b2':  're',
        '_b2g': 're',
        '_b3':  'bo',
        '_b3g': 'bo',

        # rep-left
        '_l0':  'or',
        '_l0g': 'or',
        '_l1':  'le',
        '_l1g': 'le',
        '_l2':  're',
        '_l2g': 're',
        '_l3':  'bo',
        '_l3g': 'bo',

        # rep-right
        '_r0':  'or',
        '_r0g': 'or',
        '_r1':  'le',
        '_r1g': 'le',
        '_r2':  're',
        '_r2g': 're',
        '_r3':  'bo',
        '_r3g': 'bo',

        # rep at the end
        '_e0':  'or',
        '_e0g': 'or',
        '_e1':  'to',
        '_e1g': 'to',

        # rep-arti
        '_a0':  'or',
        '_a0g': 'or',
        '_a1':  'le',
        '_a1g': 'le',
        '_a2':  're',
        '_a2g': 're',
        '_a3':  'bo',
        '_a3g': 'bo',
    }

    try:
        result = substitute[dat[10]]
    except:
        result = 'invalid value'

    # print('result:', result)
    # print('='*40, 'end criterion_suffix()')
    return result


def criterion_boundary(rating=['B0', 'B1', 'B2']):
    """
    This function checks if there are boundaries in the middle of the piece.
    rating[0]: no boundary
    rating[1]: 1 boundary
    rating[2]: more than 1 boundary
    """
    # print('='*40, 'criterion_boundary()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_boundary', []]
    # end description

    # print('dat[5]:', dat[5])

    boundaries = len(dat[5])
    try:
        # if its at the begin we dont need it
        if dat[5][0][1] < 4:
            boundaries -= 1
        # if its end and not the only one, we dont need it
        if dat[5][-1][0] == 'end':  # and len(dat[5]) > 1:
            boundaries -= 1
        # if its artificial, we dont need it
        if len(dat[5]) == 1 and dat[5][0][0] == 'artificial':
            boundaries -= 1

    except:
        pass

    # print('boundaries:', boundaries)

    # for i, datt in enumerate(dat):
    #     print(i, datt)

    if boundaries == 0:
        result = rating[0]
    elif boundaries == 1:
        result = rating[1]
    elif boundaries > 1:
        result = rating[2]

    # print('result:', result)
    # print('='*40, 'end criterion_boundary()')
    return result


def criterion_dummy(ret='-1'):
    """
    This function
    """
    # print('='*40, 'criterion_dummy()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'criterion_dummy', []]
    # end description

    result = -1

    print('result:', result)
    # print('='*40, 'end criterion_dummy()')
    return result


def summarize_cellsContent(criteriaKeyList=[], removeZeros=True, removeList=[0], title='', sep=';'):
    """
    This function concatenates the contents of cells separated by sep.

    criteriaKeyList -- list of the keys of the criteria to check
    sep -- separator for criteria
    """
    # print('='*40, 'summarize_cellsContent()')
    # description
    global criteriaCol
    # print('===== criteriaCol', criteriaCol)
    if criteriaCol != -1:
        if title == '':
            out = ''
            for x in criteriaKeyList:
                if out != '':
                    out += sep
                out += x
        else:
            out = title
        criteriaValues[criteriaCol] = [
            'summarize_cellsContent', [out]]
    # end description

    result = ''

    # concat criteria results
    for key in criteriaKeyList:
        # print(key, dat[17][key])
        # if not (dat[17][key] == 0 and removeZeros):
        if not (removeZeros and dat[17][key] in removeList):
            # print('added')
            if result != '':
                result += sep
            result += str(dat[17][key])

    # print('result:', result)
    # print('='*40, 'end summarize_cellsContent()')
    return result


def check_add_criteria(criteriaKeyList=[], removeZeros=True, sep=';'):
    """
    DEPRECATED?
    predecessor of summarize_cellsContent

    This function concatenates the results of previous checks.

    criteriaKeyList -- list of the keys of the criteria to check
    sep -- separator for criteria
    """
    # print('='*40, 'check_add_criteria()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        out = ''
        for x in criteriaKeyList:
            if out != '':
                out += sep
            out += x
        criteriaValues[criteriaCol] = [
            'check_add_criteria', [out]]
    # end description

    result = ''

    # concat criteria results
    for key in criteriaKeyList:
        # print(key, dat[17][key])
        if not (dat[17][key] == 0 and removeZeros):
            if result != '':
                result += sep
            result += str(dat[17][key])

    # print('result:', result)
    # print('='*40, 'end check_add_criteria()')
    return result


def count_number_of_notes():
    """
    This function
    """
    # print('='*40, 'count_number_of_notes()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        criteriaValues[criteriaCol] = [
            'count_number_of_notes', []]
    # end description

    result = dat[2]

    # print('result:', result)
    # print('='*40, 'end count_number_of_notes()')
    return result


def check_proportion(hProp=-1):
    """
    hPropP1P2-after50-6%-y

    This function prints the proportion between PI and PII (correct: its the lenght in %
    of PI).

    rating -- list of two, first: true, second: false

    see also: criterion_proportion()
    """
    # print('='*40, 'check_proportion()')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        if hProp == -1:
            param = str(50)
            hProp = 50
        else:
            param = hProp
        criteriaValues[criteriaCol] = [
            'check_proportion', [hProp]]
    # end description

    # check param
    if hProp != -1:
        if hProp < 0 or hProp > 100:
            print('Invalid value for hProp:', str(hProp), '; aborting!')
            return "Problem with param!"
        else:
            # set the proportion if no special barlines exist
            # dat[5]: barlines
            # dat[14]: thresholdPI
            if len(dat[5]) == 0:
                dat[14] = round(dat[4]/100*hProp, 2)
                # print('dat[14]:', dat[14])

    proportion = round(dat[14]/dat[4]*100, 2)
    # print('proportion:', proportion)

    # print('='*40, 'end check_proportion()')
    return proportion


def check_iTS(
        part='P1',
        quantity=1,
        quantityExact=False,
        color='red',
        graph='E',
        positionBegin=0,
        positionPivot=50,
        positionEnd=0,
        positionBegin1=0, # 0
        positionEnd1=0, # 25
        positionBegin2=75, # 75
        positionEnd2=100, # 100
        positionTolerance=5,
        lengthMin=0,
        lengthMax=100,
        lengthRelation='total',
        atEnd=False,
        rating=['positive', 'negative'],
        cluster=0):
    """
    TODO:
    * simplify

    if its true: rating[0]
    else: rating[1]


    part -- in which part the iTS should be
        P1, P2
    quantity -- how often the iTS should appear
        1, 2
    quantityExact -- toggle quantity between exact and minimun
        True: quantity must be exactly met
        False: quantity is the minimum of found iTS
    color -- the color of the iTS to find
        possible options: red, green, grey, non-red
    graph -- which graph to use
        'E': Einzelgraph
        'Z': Zfg-graph
    positionBegin -- relative to part: where the iTS should begin
        0-100 (%)
        0: ignore
    positionPivot -- relative to part: where the first iTS should end / second
                     iTS should begin; only relevant with quantity == 2
        0-100 (%)
    positionEnd -- relative to part: where the iTS should end
        0-100 (%)
        100: ignore

    positionBegin1=0
    positionEnd1=25
    positionBegin2=75
    positionEnd=100


    lenghtMin -- min length of the iTS
        0-100 (%)
        0: ignore
    lengthMax -- max length of the iTS
        0-100 (%)
        100: ignore
    positionTolerance -- tolerating "wrong" positions (relative to length of iTS)
        0-100 (%)
        0: "ignore"
    atEnd -- (bool) if the iTS should be at the end
        -> positionBegin and positionEnd not necessary
        True: iTS should be at the End
        False: iTS does not have to be at the end
    rating -- list of two, first: true, second: false
    cluster -- (bool) use cluster to check the iTS
        True: use cluster
        False: don't use cluster
        addition: if cluster==0 (default) then cluster will be True for graph==Z
        and False for graph==E.
    lengthRelation -- to what should the iTS' length relate?
        part: relates to the parts length
        total: relates to the total length
    """
    # print('='*40, 'check_iTS()')
    # print('part quantity color positionBegin positionEnd lengthMin lengthMax rating')
    # print(part, quantity, color, positionBegin,
    #       positionEnd, lengthMin, lengthMax, rating)
    # print('---')
    # description
    global criteriaCol
    # print('criteriaCol', criteriaCol)
    if criteriaCol != -1:
        # criteriaValues[criteriaCol] = [
        #     'check_iTS', [part, quantity, color, positionBegin, positionEnd, positionTolerance,
        #                   atEnd, lengthMin, lengthMax, lengthRelation, rating, cluster]]
        criteriaValues[criteriaCol] = [
            'check_iTS', [rating[0]]]
    # end description

    # check param values =======================================================
    # part:
    valids = ['P1', 'P2']
    if part not in valids:
        print('Invalid value for part:', str(part), '; aborting!')
        return -1
    # quantity:
    valids = [1, 2]
    if quantity not in valids:
        print('Invalid value for quantity:', str(quantity), '; aborting!')
        return -1
    # quantityExact:
    valids = [True, False]
    if quantityExact not in valids:
        print('Invalid value for quantityExact:', str(quantityExact), '; aborting!')
        return -1
    # color:
    valids = ["red", "green", "grey", "non-red"]
    if color not in valids:
        print('Invalid value for color:', str(color), '; aborting!')
        return -1
    color = valids.index(color)
    # graph:
    valids = ['E', 'Z']
    if graph not in valids:
        print('Invalid value for graph:', str(graph), '; aborting!')
        return -1
    # positionBegin:
    if positionBegin < 0 or positionBegin > 100:
        print('Invalid value for positionBegin:',
              str(positionBegin), '; aborting!')
        return -1
    # positionEnd:
    if positionEnd < 0 or positionEnd > 100:
        print('Invalid value for positionEnd:',
              str(positionEnd), '; aborting!')
        return -1
    # positionPivot:
    if positionPivot < 0 or positionPivot > 100:
        print('Invalid value for positionPivot:',
              str(positionPivot), '; aborting!')
        return -1

    # positionBegin1:
    if positionBegin1 < 0 or positionBegin1 > 100:
        print('Invalid value for positionBegin1:',
              str(positionBegin1), '; aborting!')
        return -1
    # positionEnd1:
    if positionEnd1 < 0 or positionEnd1 > 100:
        print('Invalid value for positionEnd1:',
              str(positionEnd1), '; aborting!')
        return -1
    # positionBegin2
    if positionBegin2 < 0 or positionBegin2 > 100:
        print('Invalid value for positionBegin2:',
              str(positionBegin2), '; aborting!')
        return -1
    # positionEnd
    if positionEnd2 < 0 or positionEnd2 > 100:
        print('Invalid value for positionEnd2:',
              str(positionEnd2), '; aborting!')
        return -1

    # positionTolerance:
    if positionTolerance < 0 or positionTolerance > 100:
        print('Invalid value for positionTolerance:',
              str(positionTolerance), '; aborting!')
        return -1
    # lengthMin:
    if lengthMin < 0 or lengthMin > 100:
        print('Invalid value for lengthMin:', str(lengthMin), '; aborting!')
        return -1
    # lengthMax:
    if lengthMax < 0 or lengthMax > 100:
        print('Invalid value for lengthMax:', str(lengthMax), '; aborting!')
        return -1
    # lenghtRelation:
    valids = ['part', 'total']
    if lengthRelation not in valids:
        print('Invalid value for lengthRelation:',
              str(lengthRelation), '; aborting!')
        return -1
    # atEnd:
    if atEnd != True and atEnd != False:
        print('Invalid value for atEnd:', str(atEnd), '; aborting!')
        return -1
    # rating:
    if len(rating) != 2:
        print('Invalid value for rating:', str(rating), '; aborting!')
        return -1
    # cluster:
    if cluster != True and cluster != False and cluster != 0:
        print('Invalid value for cluster:', str(cluster), '; aborting!')
        return -1
    # for i, x in enumerate(rating):
    #     if not isinstance(x, int):
    #         print('Invalid value for rating:', str(rating[i]), '; aborting!')
    #         return -1
    # ==========================================================================

    # if quantity is 2 and positionEnd is 0 (default value), then we use positionBegin1, ...
    # otherwise we ignore positionBegin1, and use positionBegin, positionPivot and positionEnd
    if quantity == 2 and positionEnd !=0:
        # transform positionBegin, positionPivot & positionEnd
        positionBegin1 = positionBegin
        positionEnd1 = positionPivot
        positionBegin2 = positionPivot
        positionEnd2 = positionEnd

    # determine cluster:
    # print('cluster:\t', cluster)
    if not type(cluster) == bool and cluster == 0:
        if graph == 'E':
            cluster = False
        else:
            cluster = True
    # print('graph cluster:', graph, cluster)
    if graph == 'Z' and cluster == False:
        print('check_iTS(): Warning: graph == Z and cluster == False not yet supported!')
        print('             Fallback to graph == Z and cluster == True!')
        cluster = True
    # print('cluster:\t', cluster)
    result = rating[1]
    # print('-'*10)

    # print('dat[14]:', dat[14])  # thresholdPI
    # print('dat[4]:', dat[4])  # quarterLength
    # print('dat[2]:', dat[2])  # numberOfNotes

    # DEPRECATED: comparison here only by qL
    # # sortResultsBy
    # # 0: quarterLength
    # # 1: numberOfNotes
    # if sortResultsBy == 0:
    #     totalLength = dat[4]  # qL
    #     thresholdPI = dat[14]
    # else:
    #     # aka sortResultsBy == 1
    #     totalLength = dat[2]  # numberOfNotes
    #     thresholdPI = dat[14] / dat[4] * dat[2]

    totalLength = round(dat[4], 1)  # qL
    thresholdPI = round(dat[14], 1)

    # print('dat[14] (thresholdPI):', dat[14])
    # print('dat[14]/dat[4] * dat[2]:', dat[14]/dat[4] * dat[2])

    if lengthRelation == 'part':
        if part == 'P1':
            lengthToCompare = thresholdPI
        else:
            # part == 'P2'
            lengthToCompare = totalLength - thresholdPI
    else:
        # lengthRelation=='total'
        lengthToCompare = totalLength

    thresholdLengthMin = round(lengthToCompare / 100 * lengthMin, 1)
    thresholdLengthMax = round(lengthToCompare / 100 * lengthMax, 1)
    if part == "P1":
        thresholdPartBegin = 0
        thresholdPartEnd = thresholdPI
        partOffset = 0
        partLength = thresholdPI
    else:
        thresholdPartBegin = thresholdPI
        thresholdPartEnd = totalLength
        partOffset = thresholdPI
        partLength = totalLength-thresholdPI

    # thresholdPositionBegin = round(
    #     partOffset + partLength / 100 * positionBegin, 1)
    # thresholdPositionPivot = round(
    #     partOffset + partLength / 100 * positionPivot, 1)
    # thresholdPositionEnd = round(
    #     partOffset + partLength / 100 * positionEnd, 1)

    if positionEnd != 0:
        thresholdPositionBegin1 = round(partOffset + partLength / 100 * positionBegin, 1)
        # thresholdPositionPivot = round(partOffset + partLength / 100 * positionPivot, 1)
        thresholdPositionEnd1   = round(partOffset + partLength / 100 * positionPivot, 1)
        thresholdPositionBegin2 = thresholdPositionEnd1
        thresholdPositionEnd2   = round(partOffset + partLength / 100 * positionEnd,   1)

    else:
        thresholdPositionBegin1 = round(partOffset + partLength / 100 * positionBegin1, 1)
        thresholdPositionEnd1   = round(partOffset + partLength / 100 * positionEnd1,   1)
        thresholdPositionBegin2 = round(partOffset + partLength / 100 * positionBegin2, 1)
        thresholdPositionEnd2   = round(partOffset + partLength / 100 * positionEnd2,   1)

    if False:
        print('---')
        print('sortResultsBy:', sortResultsBy)
        print('lengthRelation:', lengthRelation)
        print('graph:', graph)
        print('part:', part)
        print('cluster:', cluster)
        print('quantity:', quantity)
        print('color:', color)
        print('totalLength:', totalLength)
        print('thresholdPI:', thresholdPI)
        print('thresholdLengthMin:', thresholdLengthMin)
        print('thresholdLengthMax:', thresholdLengthMax)
        print('thresholdPartBegin:', thresholdPartBegin)
        print('thresholdPartEnd:', thresholdPartEnd)
        # print('thresholdPositionBegin:', thresholdPositionBegin)
        # print('thresholdPositionPivot:', thresholdPositionPivot)
        # print('thresholdPositionEnd:', thresholdPositionEnd)

        print('thresholdPositionBegin1:', thresholdPositionBegin1)
        print('thresholdPositionEnd1:',   thresholdPositionEnd1)
        print('thresholdPositionBegin2:', thresholdPositionBegin2)
        print('thresholdPositionEnd2:',   thresholdPositionEnd2)

        print('positionTolerance %:', positionTolerance)
        print('---')

    revert = False

    # print('dat[7]:')
    # for d in dat[7]:
    #     print(d)

    # print("dat[7]:", dat[7])
    # print('part:', part)
    if graph == 'E':
        results = dat[7]
        if color in [0, 1]:
            results = []
            for res in dat[7]:
                if res[3][0] == color:
                    results.append(res)
        else:
            # nothing happens here, this happens later
            # if color == 2:  # grey
            #     print('grey')

            # elif color == 3:  # non-red
            #     print('non-red')
            pass
    else:
        # -> graph == 'Z'
        # note: revert works here counterintuitive
        # fill list with 0 if note "taken" by iTS
        allOfColor = [1] * dat[2]
        # print('allOfColor:', allOfColor)
        # remove unused iTS
        allowedColors = []
        if color == 0:  # red
            allowedColors.append(0)
            revert = True
        elif color == 1:  # green
            allowedColors.append(1)
            revert = True
        elif color == 2:  # grey
            allowedColors.append(0)
            allowedColors.append(1)
            # revert = True
        elif color == 3:  # non-red
            allowedColors.append(0)
            # revert = True

        # print('allowedColors:', allowedColors)

        # print('dat[7]:', dat[7])
        for res in dat[7]:
            # print('\nres:', res)
            resColor = res[3][0]
            # print('resColor:', resColor)
            for r in res[0]:
                for x in range(r, r+res[1]):
                    if resColor not in allowedColors:
                        allOfColor[x] = 1
                    else:
                        allOfColor[x] = 0
        results = ['graph=Z']
        # print('allOfColor:', allOfColor)

    for res in results:
        # print('---\nres:', res)

        # get color ============================================================
        if graph == 'E' and cluster == True:
            revert = False
            allOfColor = [0]*dat[2]
            # mark all red with 1, other with 0
            # get red (-> colorgroup == 0)

            resColor = res[-1][0]
            # print('color resColor:', color, resColor)
            if color == resColor:  # red and green
                # merge all to one
                for r in res[0]:
                    for x in range(r, r+res[1]):
                        allOfColor[x] = 1
            elif color == 2:  # grey
                for r in res[0]:
                    for x in range(r, r+res[1]):
                        allOfColor[x] = 1
                revert = True
                pass
            elif color == 3:  # non-red
                for r in res[0]:
                    for x in range(r, r+res[1]):
                        allOfColor[x] = 1
                revert = True
                pass
        
        elif graph == 'E':
            # if non-cluster
            if color in [0, 1]:
                colorResults = []
                for cR in res[0]:
                    colorResults.append([cR, res[1], res[2]])
            else:
                allOfColor = [1]*dat[2]
                for r in res[0]:
                    if color == 2:  # grey
                        # print('grey')

                        for x in range(r, r+res[1]):
                            allOfColor[x] = 0

                    elif color == 3:  # non-red
                        # print('non-red, abort')

                        if res[3][0] == 0:
                            for x in range(r, r+res[1]):
                                allOfColor[x] = 0
                # print('allOfColor:', allOfColor)

                # remove unused areas
                for i, _ in enumerate(allOfColor):
                    # print(i, aC)
                    thisNoteOffset = dat[0][i].offset
                    if quantity == 1 and \
                        (thisNoteOffset >= thresholdPositionBegin1 and thisNoteOffset < thresholdPositionEnd2):
                        continue
                    if quantity == 2 and (\
                        (thisNoteOffset >= thresholdPositionBegin1 and thisNoteOffset < thresholdPositionEnd1) or \
                        (thisNoteOffset >= thresholdPositionBegin2 and thisNoteOffset < thresholdPositionEnd2)):
                        continue
                    allOfColor[i] = 0
                # print('allOfColor:', allOfColor)

        if revert:
            # print('revert!')
            for i, col in enumerate(allOfColor):
                if col == 1:
                    allOfColor[i] = 0
                else:
                    allOfColor[i] = 1
            # print('allOfColor:', allOfColor)

        # "remove" notes of unused part
        if graph == 'Z':
            # use positionBegin instead of thresholdPI
            # print('thresholdPI:', thresholdPI)
            # "remove" unwanted part
            # print('dat[2]:', dat[2])
            for x in range(0, dat[2]):
                # print(x)
                thisNoteOffset = dat[0][x].offset
                # if part == 'P1' and thisNoteOffset < thresholdPositionEnd and thisNoteOffset >= thresholdPositionBegin:
                #     continue
                # if part == 'P2' and thisNoteOffset >= thresholdPositionBegin and thisNoteOffset < thresholdPositionEnd:
                #     continue
                # TODO: validate this one
                if quantity == 1 and \
                    (thisNoteOffset >= thresholdPositionBegin1 and thisNoteOffset < thresholdPositionEnd2):
                    continue
                if quantity == 2 and (\
                    (thisNoteOffset >= thresholdPositionBegin1 and thisNoteOffset < thresholdPositionEnd1) or \
                    (thisNoteOffset >= thresholdPositionBegin2 and thisNoteOffset < thresholdPositionEnd2)):
                    continue
                # print('thisNoteOffset:', thisNoteOffset)
                allOfColor[x] = 0
            # print('allOfColor:', allOfColor)

        # ======================================================================

        if cluster == True \
                or (graph == 'E' and color in [2, 3]):
            # get results of color =============================================
            begin = -1
            # redResults: [begin, numberOfNotes, quarterLength]
            colorResults = []
            for i, x in enumerate(allOfColor):
                # print('i: {:3} x: {} offset: {:4}'.format(i, x, dat[0][i].offset))
                if x == 1:
                    if begin == -1:
                        begin = i
                else:
                    if begin != -1:
                        length = i-begin
                        qL = sum(
                            [x.quarterLength for x in dat[0][begin:begin+length]])
                        colorResults.append([begin, length, qL])
                        begin = -1
            if begin != -1:
                length = i-begin+1
                qL = sum([x.quarterLength for x in dat[0][begin:begin+length]])
                colorResults.append([begin, length, qL])
            # print('colorResults:', colorResults)
            # ==================================================================

        # check if valid =======================================================
        rCount = 0
        for r in colorResults:
            # print(' r:', r)

            # check position, length
            rFirstNote = dat[0][r[0]]
            rBegin = rFirstNote.offset
            rLength = r[2]
            rEnd = rBegin + rLength
            # print('  rBegin rEnd rLength:', rBegin, rEnd, rLength)
            # print('  rCount:', rCount)


            # TODO: this doesnt work, do we need another solution for this - is it even possible?
            # # if sorted by numberOfNotes, then rLength should be the iTS' numberOfNotes
            # if sortResultsBy == 1:
            #     rLength = r[1]

            if quantity == 1:
                # positionBegin = thresholdPositionBegin
                # positionEnd = thresholdPositionEnd
                thisPositionBegin = thresholdPositionBegin1
                thisPositionEnd = thresholdPositionEnd2
            else:
                if rCount == 0:
                    # positionBegin = thresholdPositionBegin
                    # positionEnd = thresholdPositionPivot
                    thisPositionBegin = thresholdPositionBegin1
                    thisPositionEnd = thresholdPositionEnd1
                else:
                    # positionBegin = thresholdPositionPivot
                    # positionEnd = thresholdPositionEnd
                    thisPositionBegin = thresholdPositionBegin2
                    thisPositionEnd = thresholdPositionEnd2

            # print('  thisPositionBegin:', thisPositionBegin)
            # print('  thisPositionEnd:', thisPositionEnd)

            positionRight = False

            positionToleranceQL = round(rLength / 100 * positionTolerance, 1)
            # print('  positionToleranceQL:', positionToleranceQL)

            # for non-red we need a different approach
            if color == 3:
                # check if the iTS is valid

                # get length of colored area between positions
                thisLength = 0
                for ri in range(r[0], r[0]+r[1]):
                    # print('ri:', ri)
                    thisNoteOffset = dat[0][ri].offset
                    # print('thisNoteOffset:', thisNoteOffset)
                    # if thisNoteOffset >= positionBegin-positionToleranceQL and thisNoteOffset < positionEnd+positionToleranceQL:
                    # print('asdf:', thisNoteOffset >= positionBegin1-positionToleranceQL)
                    # print('asdf:', thisNoteOffset < positionEnd1+positionToleranceQL)
                    # print('csdf:', (quantity == 2 and (thisNoteOffset >= positionBegin1-positionToleranceQL and thisNoteOffset < positionEnd1+positionToleranceQL) and (thisNoteOffset >= positionBegin2-positionToleranceQL and thisNoteOffset < positionEnd2+positionToleranceQL)))
                    if (quantity == 1 and \
                       (thisNoteOffset >= thisPositionBegin-positionToleranceQL and thisNoteOffset < thisPositionEnd+positionToleranceQL)) \
                       or (quantity == 2 and \
                        #   (thisNoteOffset >= positionBegin1-positionToleranceQL and thisNoteOffset < positionEnd1+positionToleranceQL) and \
                        #   (thisNoteOffset >= positionBegin2-positionToleranceQL and thisNoteOffset < positionEnd2+positionToleranceQL)):
                          thisNoteOffset >= thisPositionBegin-positionToleranceQL and thisNoteOffset < thisPositionEnd+positionToleranceQL):
                        thisNoteLength = dat[0][ri].quarterLength
                        thisLength += thisNoteLength
                        # print('thisLength:', thisLength)

                        if thisLength >= thresholdLengthMin:
                            positionRight = True

            else:
                # print('rLength thresholdLengthMax:',rLength, thresholdLengthMax )
                # check if the iTS is valid
                if rLength >= thresholdLengthMin \
                   and rLength <= thresholdLengthMax \
                   and rBegin >= thisPositionBegin-positionToleranceQL and rEnd <= thisPositionEnd+positionToleranceQL:
                #    and ((quantity == 1 and rBegin >= positionBegin1-positionToleranceQL and rEnd < positionEnd2+positionToleranceQL) \
                #       or (quantity == 2 and \
                #         #  (rCount == 0 and rBegin >= positionBegin1-positionToleranceQL and rEnd <= positionEnd1+positionToleranceQL) or \
                #         #  (rCount != 0 and rBegin >= positionBegin2-positionToleranceQL and rEnd <= positionEnd2+positionToleranceQL))):
                #         rBegin >= positionBegin-positionToleranceQL and rEnd <= positionEnd+positionToleranceQL)):
                    # print(' got it!')
                    positionRight = True

            if positionRight:
                # print('  valid!')
                if atEnd:
                    # iTS should be at the End of the piece.
                    # -> last note of iTS must be last note of the piece
                    # -> same index
                    iTSLastNoteIndex = r[0]+r[1]-1
                    lastNoteIndex = len(dat[0])-1
                    # print('iTSLastNoteIndex:', iTSLastNoteIndex)
                    # print('lastNoteIndex:', lastNoteIndex)
                    # print(dat[0][lastNoteIndex])
                    if lastNoteIndex == iTSLastNoteIndex:
                        rCount += 1
                        # print('last!')

                else:
                    rCount += 1

        # check count
        if not quantityExact and rCount >= quantity:
            # print(' success!')
            result = rating[0]
            break
        # ======================================================================

    # check count (cont.)
    if quantityExact and rCount == quantity:
        # print(' success!')
        result = rating[0]

    # print('result:', result)
    # print('='*40, 'end check_iTS()')
    return result


def prepare_output():
    """
    This function prepares the output for the xlsx-file.
    All criteria in criteriaToCheck are checked.
    """
    # print('='*40, 'prepare_output()')
    # dat[17] -- the functions and order of the criteria
    global criteriaCol
    global xlsxReadPreviousResults

    keysToExecute = []
    for key in dat[17]:
        keysToExecute.append(key)
    # print(keysToExecute)

    if xlsxReadPreviousResults and baseID != -1:
        # TODO: read lines
        # global baseID
        # print('baseID:', baseID)
        # print(get_column_letter(outputWorksheet.max_column))
        for x in range(1, outputWorksheet.max_column+1):
            letter = get_column_letter(x)
            if letter not in keysToExecute:
                # print(letter)
                thisValue = outputWorksheet[letter+str(baseID)].value
                dat[17][letter] = thisValue

        # print(outputWorksheet['A118'].value)

    # print(dat[17])

    # for key in dat[17]:
    for key in keysToExecute:
        # print(key, '-', dat[17][key])
        criteriaCol = key
        try:
            # print('checking {}...'.format(key))
            exec('dat[17][\'' + key + '\'] = ' + dat[17][key])
            # print(' ', dat[17][key])
            pass
        except:
            print('Problem with criterion \'' + dat[17][key] + '\'.')
            dat[17][key] = 'PROBLEM!'

    # print()
    # # print the results
    # for i, key in enumerate(dat[17]):
    #     print(key, dat[17][key])

    # print('='*40, 'end prepare_output()')
    return 0


def export_xlsx_description():
    """
    TODO: update!
    This function exports the descriptions (column 1) to the xlsx-file.
    """
    # print('='*40, 'export_xlsx_description()')

    for key, _ in criteriaToCheck.items():
        # print(key, value)
        cellValue = ''
        for descriptionKey in criteriaDescriptions:
            if descriptionKey + '(' == criteriaToCheck[key][: len(descriptionKey)+1]:
                cellValue = criteriaDescriptions[descriptionKey]
                break

        # print('cellValue:', cellValue)
        if cellValue != '':
            # print(cellValue)
            cell = key + str(1)
            # print('cell:', cell)
            # print('cellValue:', cellValue)
            outputWorksheet[cell] = cellValue
        else:
            print('  I have a problem with criterion description for \'' + key + '\'.')

    # print('='*40, 'end export_xlsx_description()')


def export_xlsx_description_with_values():
    """
    TODO: update fully to load_worksheet()

    This function exports the descriptions (column 1) to the xlsx-file.
    """
    # print('='*40, 'export_xlsx_description_with_values()')

    for key in criteriaDescriptionsWithValues:
        # print('key:', key)
        cell = key + str(1)
        cellValue = criteriaDescriptionsWithValues[key]
        outputWorksheet[cell] = cellValue

    # print('='*40, 'end export_xlsx_description_with_values()')


def result_add_repetition(begin, end, mel=-1, resultPar=-1):
    """
    begin, end: offset; output: IDs.
    """
    global debugMode
    # debugMode = True
    # print('='*20, 'result_add_repetition()')
    global d, dat

    # print('begin end:', begin, end)

    if mel == -1:
        mel = dat[0]
    if resultPar == -1:
        result = copy.deepcopy(d[1][7])
    else:
        result = copy.deepcopy(resultPar)

    # print('len(mel):', len(mel))

    # print('result:')
    # for res in result:
    #     print(' ', res)
    # print(result)

    # result expected:
    # [[[2, 9], 4, 4.0, [0, 0]], [[1, 6], 3, 3.0, [0, 1]]]
    # [[tsFirstIDs, qL, nL, colorgr oupAndID], ...]
    # print('begin end:', begin, end)
    # print('result: ')
    # for res in result:
    #     print(' ', res)

    # NOTE: begin & end are measureNumbers

    # get the positions of the notes
    # positions = []
    # for note in mel:
    #     ## get_note_position(note, timeSignatures)
    #     positions.append(get_note_position(note, dat[6]))
    # print('positions:', positions)

    # copyDurationQL = 0
    copyNotes = 0
    copyIDs = []

    # for i, dabber in enumerate(dat[0]):
    #     print(i, dabber.offset, dabber)

    for i, n in enumerate(mel):
        # if note.measureNumber >= begin and note.measureNumber <= end:
        if n.offset >= begin and n.offset < end:
            # print('copy me!', note.name)
            # print(note.offset)
            # copyDurationQL += note.quarterLength
            copyNotes += 1
            copyIDs.append(i)

    copyFirst = copyIDs[0]
    copyLast = copyIDs[-1]
    # print('copyFirst copyLast:', copyFirst, copyLast)

    # print('copyDurationQL:', copyDurationQL)
    # print('copyNotes:', copyNotes)
    # print('copyIDS:', copyIDs)

    # copyBegin = positions[begin]
    # copyEnd = positions[end]
    # copyDuration = end - begin
    # print('copyBegin copyEnd copyDuration:', copyBegin, copyEnd, copyDuration)
    # dat[0][88:90].show('text')

    # print()
    # dat[0][70:90].show('text')

    # print('len(dat[0]):', len(dat[0]))
    # print('dat[0].index(dat[0][-1]):', dat[0].index(dat[0][-1]))

    # dat[0][108:].show('text')
    # try:
    #     dat[0][108].show('text')
    # except:
    #     pass

    for res in result:
        # print('res:', res)
        # print('res[0][0]:', res[0][0])
        # print('res[0][0]+res[1]:', res[0][0]+res[1])
        # mel[res[0][0]:res[0][0]+res[1]].show('text')

        add = []
        for i, r in enumerate(res[0]):
            # print(' ', r)
            if r > copyLast:
                res[0][i] += copyNotes
            elif r >= copyFirst and r <= copyLast:
                # print('r + copyNotes:', r + copyNotes)
                add.append(r + copyNotes)
        # print('add:', add)
        res[0] += add
        res[0] = sorted(res[0])
        # res[3] = [-1, -1]
        # print('res:', res)

    # print('result:')
    # for res in result:
    #     print(' ', res)

    # for i, n in enumerate(mel):
    #     print(i, n.offset, n.name)

    # add repetiton as ts
    repAddNumberOfNotes = sum(
        [1 for x in mel if x.offset >= begin and x.offset < end])
    # print('repAddNumberOfNotes:', repAddNumberOfNotes)
    repAddBeginFirstID = sum([1 for x in mel if x.offset <= begin])-1
    # print('repAddBeginFirstID:', repAddBeginFirstID)
    repAddBeginSecondID = repAddBeginFirstID + repAddNumberOfNotes
    # print('repAddBeginSecondID:', repAddBeginSecondID)
    repAddQuarterLength = end-begin
    # print('repAddQuarterLength:', repAddQuarterLength)
    repAdd = [[repAddBeginFirstID, repAddBeginSecondID],
              repAddNumberOfNotes, repAddQuarterLength, [-1, 0]]

    # print('repAdd:', repAdd)
    if sortResultsByReverse:
        result.insert(0, repAdd)
    else:
        result.append(repAdd)

    # print('len(mel):', len(mel))
    output = result
    # print('output:')
    # for o in output:
    #     print(' ', o)

    # print('='*20, 'end result_add_repetition()')
    return output


def gracenotes_expand(mel):
    """
    This function expands gracenotes.
    """
    # print('='*20, 'gracenotes_expand()')
    mel = copy.deepcopy(mel)

    for i, n in enumerate(mel):
        if n.quarterLength == 0.0:
            newLength = mel[i+1].quarterLength / graceNoteFactor

            mel[i+1].quarterLength -= newLength
            mel[i+1].offset = mel[i+1].offset + newLength

            # this does not work as intended
            # mel[i].quarterLength = newLength

            # print(n.duration, newLength)
            # print(n.offset)
            # print(n.octave)
            newNote = note.Note(n.name, octave=n.octave,
                                quarterLength=newLength)
            # newNote.show('text')
            # print(newNote.quarterLength)
            # newNote.show('text')
            # mel.show()
            mel.insert(n.offset, newNote)
            mel.remove(n)
            # print(n.offset)
            # mel.show('text')

            # mel[i].duration = mel[i+1].duration

            # print(mel[i].duration)
    # mel[4].show('text')
    # print(mel[4].quarterLength)
    # # mel.show('text')
    # mel.show()

    # print('='*20, 'end gracenotes_expand()')
    return mel


def gracenotes_remove(mel):
    """
    This function removes gracenotes.
    """
    # print('='*20, 'gracenotes_remove()')

    for n in mel:
        if n.quarterLength == 0.0:
            # print('removed gracenote!')
            mel.remove(n)

    # print('='*20, 'end gracenotes_remove()')
    return mel


def drawSpecialBarlinesInGraphs():
    """
    This function draws the end of PI in the graphs.
    """
    # print('='*20, 'drawSpecialBarlinesInGraphs()')
    # print('di:', di)

    # if we do not have barlines, then we dont need to do this
    # if dat[5] == 'barlines' or len(dat[5]) == 0:
    #     return -1
    # correction:
    # dat[14] is relevant for this
    if dat[14] <= 0:
        # print('='*20, 'end drawSpecialBarlinesInGraphs()')
        return -1

    # only for first "zusammenfassungsgraph" or for all?

    # specialBarlineColor
    # TODO: combine with iTS separator
    specialBarlineThickness = 0.25

    # print('dat[8][0]:')
    # for datt in dat[8][0]:
    #     print(datt)

    # barlines:
    # print('dat[5] (barlines):', dat[5])
    # position of first barline
    # print('position of the barline:', dat[5][0][1])

    allBoundsAndColors = dat[8]
    # print('allBoundsAndColors:', allBoundsAndColors)

    # TODO:
    # is this the special barline or is this the thresholdPI?
    # dat[14]: thresholdPI
    # dat[16]: repetitionPoint
    barlinePosition = dat[14]

    for bounds in allBoundsAndColors:
        # print(bounds)
        for i, bound in enumerate(bounds[0]):
            # print(i, bound)

            # bound exists already
            if bound == barlinePosition:
                # print('same')
                # insert new bound
                bounds[0].insert(i+1, barlinePosition+specialBarlineThickness)
                # insert color
                bounds[1].insert(i, specialBarlineColor)
                break

            # bound does not yet exist
            if bound > barlinePosition:
                # print('greater', bound)
                # insert new bound
                bounds[0].insert(i, barlinePosition+specialBarlineThickness)
                bounds[0].insert(i, barlinePosition)
                # insert color
                bounds[1].insert(i, specialBarlineColor)
                bounds[1].insert(i+1, bounds[1][i-1])

                break

    # print('------------------')
    # for i, bound in enumerate(bounds):
    #     try:
    #         print(i, bound, '\t', dat[8][0][1][i])
    #     except:
    #         print(i, 'none')

    # print('='*20, 'end drawSpecialBarlinesInGraphs()')
    return -1


def drawBlackLineBetweenTSInGraphs():
    """
    This function draws black lines between TS.
    """
    # print('='*20, 'drawBlackLineBetweenTSInGraphs()')

    blackLineBetweenTSInGraphWeight = 0.15

    for j, boundsAndColors in enumerate(dat[8]):
        # print('-'*60)
        # print(j, boundsAndColors)
        bounds = boundsAndColors[0]
        colors = boundsAndColors[1]

        # print(len(bounds))
        # print('len(colors):', len(colors))

        for i in range(1, len(colors))[::-1]:
            color = colors[i]
            # print(i, color)

            # if its the special barline, then we dont need it
            if color == specialBarlineColor or colors[i-1] == specialBarlineColor:
                continue

            bounds.insert(i+1, bounds[i]+blackLineBetweenTSInGraphWeight)
            colors.insert(i, 'black')

    # print('------------------')
    # for i, bound in enumerate(bounds):
    #     try:
    #         print(i, bound, '\t', colors[i])
    #     except:
    #         print(i, 'none')

    # print('='*20, 'end drawBlackLineBetweenTSInGraphs()')
    return -1


def handleRepeatBrackets():
    """
    This function handles the repeat brackets.
    So far only klammer1s are deleted and only klammer2s are used.
    TODO: make it as it should be
    TODO: when ts-change in both klammer1 and klammer2 it breaks
    """
    # print('='*20, 'begin handleRepearBrackets()')

    brackets = d[0][2].flat.getElementsByClass(spanner.RepeatBracket)
    # print('brackets (', len(brackets), '): ', sep='')
    # brackets.show('text')
    # d[0][2].show('text')
    # safety first!
    # if there is no even number of brackets, something is wrong
    if len(brackets) % 2 != 0:
        print('Wrong number of repeatbrackets!')
        print('An error with repeatBrackets for "',
              d[0][0], '" forces me to skip to the next one!', sep='')
        problemFiles.append(d[0][0] + "\t\t\trepeatBrackets (wrong number)")
        weGotAnError = True
        return 1

    if len(brackets) != 0:
        bracketPairs = int(len(brackets) / 2)
        # print('bracketPairs:', bracketPairs)

        # hasRepeatBrackets
        d[0][11] = True

        # show brackets
        # for br in brackets:
        #     print('bracket')
        #     print('elements:', br.getSpannedElements())
        #     elements = br.getSpannedElements()
        #     for element in elements:
        #         print('element:')
        #         element.show('text')
        #     # br.getSpannedElements()[0].show('text')

        for i in range(0, bracketPairs):
            # print('i:', i)

            # if klammer1 has a timeSignaturechange, we have to copy it (the last) to klammer2
            for j in reversed(range(0, len(brackets[i*2]))):
                # print('  j:', j)
                ts = brackets[i*2][j].getElementsByClass(meter.TimeSignature)
                if len(ts) != 0:
                    break
            if len(ts) != 0:
                brackets[i*2+1].getSpannedElements()[0].insert(ts[0])

            # add repleft to second bracket
            brackets[i*2+1].getSpannedElements()[-1].rightBarline = brackets[i *
                                                                             2].getSpannedElements()[-1].rightBarline

            # remove the measure(s) (klammer1)
            for measure in brackets[i*2].getSpannedElements():
                d[0][2][1].remove(measure, shiftOffsets=True)

        # remove the brackets
        for bracket in brackets:
            d[0][2][1].remove(bracket)

        # save repetition marks from makeMeasures
        repmarks = d[0][2][1].flat.getElementsByClass(bar.Repeat)

        # repmarks.show('text')
        # for repm in repmarks:
        #     print(repm.measureNumber)
        #     if repm.measureNumber == d[0][2][1][-1].measureNumber:
        #         print('remove!')
        #         repmarks.remove(repm)
        # if repmarks[-1].measureNumber == d[0][2][1][-1].measureNumber:
        #     print('be gone!')
        #     print(repmarks[-1])
        #     repmarks.remove(-1)
        # # print(d[0][2][1][-1].measureNumber)
        # repmarks.show('text')

        # for repm in repmarks:
        #     print(repm.offset)
        # print('---')

        # last measure: set final barline right
        lastBarline = d[0][2][1][-1].rightBarline
        # d[0][2][1].show()

        # TODO: do we need makeMeasures here?
        # TODO: upbeat and makeMeasures
        # d[0][2][1].makeMeasures(inPlace=True, finalBarline=lastBarline)
        # d[0][2][1].show('text')

        # reinsert the repetitionmarks
        # repmID = 0
        # for measure in d[0][2][1].getElementsByClass(stream.Measure):
        #     print(measure.offset)
        #     if measure.offset == repmarks[repmID].offset:
        #         print('insert plz!')
        #         measure.leftBarline = repmarks[repmID]
        #     elif measure.offset + measure.quarterLength == repmarks[repmID].offset:
        #         measure.rightBarline = repmarks[repmID]
        #         print('insert end plz!')
        #     else:
        #         continue
        #     repmID += 1

    # print('---')
    # d[0][2].show('text')

    # print('='*20, 'end handleRepearBrackets()')
    return 0


def worksheet_create_hash_map():
    """
    This function creates a hash map with identifiers and their colNumber.
    """
    # print('='*40, 'worksheet_create_hash_map()')
    global outputWorksheet, worksheetIdentifierHashMap
    ws = outputWorksheet

    end = ws.max_row
    # print('end:', end)

    for i in range(2, end+1):
        # identifierVariant
        identifier = ws[xlsxIdentifierVariantCol+str(i)].value
        if identifier == None:
            identifier = ws[xlsxIdentifierCol+str(i)].value

        # print(' ', identifier, i)

        if identifier != None:
            # print('identifier:', identifier)
            try:
                # already exists, ignore
                tmp = worksheetIdentifierHashMap[identifier]
                if notifyIfIdentifierExists:
                    print('  Identifier already exists: "' +
                          identifier + '". Double entry?')
                tmp = None
            except:
                # does not exist: insert
                worksheetIdentifierHashMap[identifier] = i
                # print('insert')

    # print('worksheetIdentifierHashMap:')
    # for k, v in worksheetIdentifierHashMap.items():
    #     print(k, v)

    # print('='*40, 'end worksheet_create_hash_map()')
    return 0


def worksheet_insert_new_rows():
    """
    This function inserts the new cols in the worksheet.

    New rows will be sorted reversed by identifierCol and then inserted.
    -> start with the highest identifierCol to the lowest.
    So we have not problem with shifting identifier Cols.

    It also will remove "empty" lines that are not used anymore (non-variants
    of analyzed pieces)
    """
    # print('='*40, 'worksheet_insert_new_rows()')
    global outputWorksheet
    ws = outputWorksheet

    print('Writing new rows to Worksheet.')

    # sort
    tempSort = []
    for k, v in worksheetInsertHashMap.items():
        # print(k, v[0])
        tempSort.append([k, v[0]])

    worksheetInsertHashMapSorted = {}
    for x in sorted(tempSort, key=lambda y: y[1]):
        # print('x:', x)
        if x[1] == -1:
            baseIdentifier = x[0][0:x[0].rfind('_')]
            worksheetInsertHashMap[x[0]][1][xlsxIdentifierCol] = baseIdentifier
        worksheetInsertHashMapSorted[x[0]] = x[1]

    # print('worksheetInsertHashMapSorted:')
    # for k, v in worksheetInsertHashMapSorted.items():
    #     print('{:22} {:3} {}'.format(k, v, worksheetInsertHashMap[k]))

    # insert the rows
    # print('reversed(list(worksheetInsertHashMapSorted)):')
    for k in reversed(list(worksheetInsertHashMapSorted)):
        v = worksheetInsertHashMap[k]
        # print('k:', k)
        # print('v:', v)
        # print('k v:', k, v)
        insertLine = v[2]
        copy = True
        # insert new row
        oldRowID = v[0]
        if oldRowID == -1:
            print('Warning: Could not find base-identifier for "' +
                  k + '" in xlsx-file. Added at the end.')
            oldRowID = ws.max_row
            copy = False
        # print('oldRowID:', oldRowID)

        if insertLine:
            newRowID = oldRowID+1
            outputWorksheet.insert_rows(newRowID, 1)
        else:
            newRowID = oldRowID

        # copy existing data
        if copy:
            for i in range(1, ws.max_column):
                # print('i:', i)
                # print(get_column_letter(i))
                oldValue = ws[get_column_letter(i)+str(oldRowID)].value
                # print(oldValue)
                if oldValue != None:
                    ws[get_column_letter(i)+str(newRowID)] = oldValue

        # insert new data
        for kk, vv in v[1].items():
            # print(kk, vv)
            ws[kk+str(newRowID)] = vv

        # insert new identifier
        # ws[xlsxIdentifierCol+str(newRowID)] = k
        ws[xlsxIdentifierVariantCol+str(newRowID)] = k

    # print('xlsxIdentifierCol ID:', column_index_from_string(xlsxIdentifierCol)-1)

    # remove unused lines
    # TODO?: make option
    rowsToDelete = []
    try:
        for i, row in enumerate(ws.iter_rows()):
            if i == 0:
                continue
            # print(row[column_index_from_string(xlsxIdentifierCol)].value)
            # for i, r in enumerate(row):
            #     print(i, r.value)
            identifier = row[column_index_from_string(xlsxIdentifierCol)-1].value
            # print('identifier:', identifier)
            # note: i = rowindex - 1
            index = i+1

            if identifier == 'Identifier':
                continue
            # print(' ', row[column_index_from_string(xlsxIdentifierVariantCol)-1].value)
            # print(' ', column_index_from_string(xlsxIdentifierVariantCol))
            if identifier in worksheetLinesToRemove \
              and row[column_index_from_string(xlsxIdentifierVariantCol)-1].value == None:
                rowsToDelete.append(index)
                # print('  -', identifier)
            # print(' ', row[column_index_from_string(xlsxIdentifierCol)].value)
            # print(' ', row[0].value)

        for r in reversed(rowsToDelete):
            ws.delete_rows(r, 1)
    except:
        print('xlsx: Problem with removing unused Lines.')

    # print('='*40, 'end worksheet_insert_new_rows()')
    return 0


def dummy():
    """This function is a dummy to copy."""
    print('='*20, 'dummy()')

    print('='*20, 'end dummy()')
    return -1


print('Loading config:', configNumber)

# load xlsx-output file
if exportToZfgTable:
    # worksheet will be loaded and accessed global
    if load_worksheet(exportToZfgTableSourceFileName) == 0:
        # create the hashmap for the identifiers
        worksheetIdentifierHashMap = {}
        worksheetInsertHashMap = {}
        worksheet_create_hash_map()
        worksheetLinesToRemove = []
    else:
        # problems with loading worksheet:
        # there will be no export
        exportToZfgTable = False

    # print worksheetIdentifierHashMap
    # print('worksheetIdentifierHashMap:')
    # for k, v in worksheetIdentifierHashMap.items():
    #     print(k, v)


if not doNotExportHTML:
    # prepare HTML-output
    with open(HTMLfile, 'w') as f:
        f.write('<html><head><title>TSRTTPF Results</title></head><body>')
        f.write('<table cellpadding="4" cellspacing="1" border="0" style="border: 0px black solid; border-collapse: collapse;">\n')

# the total number of analyzed files
numberOfFiles = 0

# options for the xlsx export
xlsxOutputLineDefault = 2
xlsxOutputLine = xlsxOutputLineDefault
xlsxOutputLine_new = copy.deepcopy(xlsxOutputLineDefault)

# export the descriptions (column 1) to the xlsx-file.
if exportToZfgTable:
    export_xlsx_description()
else:
    # if no export, then disable reading from table
    xlsxReadPreviousResults = False


# write actual values in
criteriaValues = {}
criteriaDescriptionsWithValues = {}
criteriaCol = ''


# save names of files with problems
problemFiles = []

# get all filenames
data = get_filenames(folder)

# sort data
if sortDataByXlsx and exportToZfgTable:
    # for k, v in worksheetIdentifierHashMap.items():
    #     print(k, v)
    nonFoundCount = 100000

    for d in data:
        identifier = d[0][0][:-len(d[0][13])]
        # remove creators postfixes
        removeIt = True
        while removeIt:
            removeIt = False
            for rem in toRemove:
                # print(rem)
                if identifier[-len(rem):] == rem:
                    # print('rem:', rem)
                    # print('remove "' + rem + '"')
                    identifier = identifier[: -len(rem)]
                    # print('d[0][1]:', d[0][1])
                    removeIt = True
        # print('identifier:', identifier)
        try:
            d.append(worksheetIdentifierHashMap[identifier])
        except:
            nonFoundCount += 1
            d.append(nonFoundCount)

    # sort
    data = sorted(data, key=lambda d: d[1])

    # remove id
    for d in data:
        d.pop()

    print('Sorted Files by xlsx-order.')
    pass

# print('data:')
# for d in data:
#     print(d)

# set defaultvalue in case of no files
x = 0

# now go through all the melodies and analyze them
for x, d in enumerate(data):
    # GOTO MAIN LOOP
    print('='*80)

    if weHaveAProblem:
        break

    # print('d:', d)
    analyseStartTime = time.time()
    print('Analyzing: "', d[0][0],
          '" (', x + 1, '/', numberOfFiles, ')', sep='')

    # get name
    d[0][1] = d[0][0][:-len(d[0][13])]

    # print('---')
    # for ddd, dd in enumerate(d[0]):
    #     print(ddd, dd)

    # remove creators postfixes
    removeIt = True
    while removeIt:
        removeIt = False
        for rem in toRemove:
            if d[0][1][-len(rem):] == rem:
                # print('rem:', rem)
                # print('remove "' + rem + '"')
                d[0][1] = d[0][1][: -len(rem)]
                # print('d[0][1]:', d[0][1])
                removeIt = True

    # ==========================================================================
    # load data
    # ==========================================================================
    # GOTO LOAD
    loadResultsHTML = False

    if loadSavedResults:
        # check if HTML-file with results already exists
        if writeOptionsInFilenames:
            HTMLFileNameBegin = d[0][1] + '_' + saveOptions + '_'
        else:
            HTMLFileNameBegin = d[0][1] + '_'

        savedFiles = []
        # for f in [f for f in listdir(savedResultsFolder) if path.isfile(path.join(savedResultsFolder, f))]:
        for f in [f for f in listdir(savedResultsFolder)
                  if path.isfile(path.join(savedResultsFolder, f))
                  and f.startswith(HTMLFileNameBegin)
                  and f.endswith('.html')]:
            savedFiles.append(f)

        savedFiles = sorted(savedFiles)
        if len(savedFiles) != 0:
            HTMLFileLoad = savedResultsFolder + savedFiles[0]
            loadedDate = savedFiles[0][-24:-5]
            loadResultsHTML = True

        print('='*10, 'load data')
        # also load files from d[0][1]....txt and write to .xlsx
        loadResultsTXT = False
        savedFiles = []
        for f in [f for f in listdir(savedResultsFolder) if path.isfile(path.join(savedResultsFolder, f))
                  and f.startswith(d[0][1] + '_') and f.endswith('.txt')]:
            savedFiles.append(f)
        savedFiles = sorted(savedFiles)

        # print('savedFiles:')
        # for l in savedFiles:
        #     print(l)

        if len(savedFiles) != 0:
            loadResultsTXT = True
            for loadedResultFile in savedFiles:

                with open(savedResultsFolder + loadedResultFile, 'r') as f:
                    loadedData = json.loads(f.read())

                # print('loadadData:')
                # for l in loadedData:
                #     print(l)
                # print()

                dat = ['-1']
                dat.append(loadedData[0])
                dat.append(loadedData[1])
                dat.append(loadedData[2])
                dat.append(loadedData[3])
                dat.append(loadedData[4])
                dat.append('-1')
                dat.append(loadedData[5])
                dat.append(loadedData[6])
                dat.append(loadedData[7])
                dat.append(loadedData[8])
                d.append(dat)
            # print('d:')
            # for dd in d:
            #     print(dd[-1])

        if loadResultsHTML and loadResultsTXT:
            # read from HTML-file, saved results
            with open(HTMLFileLoad, 'r') as f:
                htmlOutput = f.read()
            print('  Loaded results from ', HTMLFileLoad, sep='')

            # write to HTML-file
            with open(HTMLfile, 'a') as f:
                f.write(htmlOutput)

            # export xlsx
            # export_xlsx()
            print('  Wrote results to ', xlsxFileName, sep='')

            # cleanup: delete data that is not used anymore
            del d[:]

            continue
        else:
            # if we do not load, we have to restore the original data
            d = [d[0]]

    # ==========================================================================
    # if no results exist, then we need some!
    # ==========================================================================

    currentTime = time.strftime('%Y-%m-%d-%H-%M-%S')
    inputTime = ''
    weGotAnError = False

    # get melOrg
    d[0][2] = load_file(folder, d[0][0])

    # TODO:
    # - remove barline regular
    # - remove systemLayout

    # handle the repeatbrackets
    try:
        brackets = handleRepeatBrackets()

        if brackets == 1:
            print('An error with repeatBrackets for "',
                  d[0][0], '" forces me to skip to the next one!', sep='')
            problemFiles.append(d[0][0] + "\t\t\trepeatBrackets")
            weGotAnError = True
            continue

    except:
        print('An error with repeatBrackets for "',
              d[0][0], '" forces me to skip to the next one!', sep='')
        problemFiles.append(d[0][0] + "\t\t\trepeatBrackets")
        weGotAnError = True
        continue

    # get the timeSignatures
    # not used anymore?
    d[0][5] = get_timeSignatures(d[0][2])

    # get 'real' timeSignatures
    d[0][9] = get_timeSignatures(d[0][2])
    # d[0][9].show('text')
    # TODO: adapt rest to new tS

    # check for gracenotes
    for n in d[0][2].flat.notesAndRests:
        if n.quarterLength == 0.0:
            print('  Melody has gracenotes.')
            d[0][3] = True
            break
    if d[0][3] == 'hasGracenotes':
        d[0][3] = False

    # get clean mel
    d[0][6] = get_clean_mel(d[0][2], d[0][9])

    # set quarterLength
    # need round because some anomalies
    d[0][4] = round(sum([n.quarterLength for n in d[0][6]]), 1)
    # print('d[0][4]:', d[0][4])

    # get length of upbeat
    d[0][10] = sum([n.quarterLength for n in d[0][6] if n.measureNumber == 0])

    # d[0][3]: hasGracenotes
    if d[0][3]:
        # really [6]?
        # print('d[0][6]:', d[0][6])
        # print('d[0][8]:', d[0][8])
        d[0][8] = gracenotes_expand(d[0][6])

        if doNotAnalyze:
            d[0][9] = []
        else:
            d[0][9] = find_ts_dpm(d[0][8])

        d[0][6] = gracenotes_remove(d[0][6])

    if doNotAnalyze:
        d[0][7] = []
    else:
        d[0][7] = find_ts_dpm(d[0][6])

    # print('d[0][7]:')
    # for ts in d[0][7]:
    #     print(ts)

    # # GOTO DATA STRUCTURE
    # d[0] =
    # [                 -- general info
    #   0 fileName,          -- name of the file (with file-ending)
    #   1 name,              -- name (without file-ending)
    #   2 melOrg             -- original melody as parsed by music21 (stream)
    #   3 hasGracenotes      -- (bool) the melody has gracenotes
    #   4 quarterLength      -- quarterLength of the melody
    #   5 tS                 -- timeSignatures
    #   6 cleanMel           -- mel only with notesAndRests and clean
    #                           measureNumbers, etc.
    #   7 result             -- result of analysis
    #   8 melCleanGrace      -- melCleanOrg if it has gracenotes
    #   9 resultGrace        -- result if it has gracenotes
    #  10 upbeatQL           -- length of upbeat in quarterLength
    #  11 hasRepeatBrackets  -- there are repeat brackets
    #  ],

    # d[1] = [
    #  0 mel,                 -- the melody as music21-stream (only notes)
    #  1 numberOfBars         -- the number of bars (musically)
    #  2 numberOfNotes,       -- the number of the notes (int)
    #  3 upbeat,              -- if there is no upbeat: 0; else: qL of upbeat
    #  4 quarterLength,       -- total duration in quarters of mel
    #  5 barlines,            -- all special barlines
    #  6 timeSignatures,      -- all time signatures
    #  7 result,              -- result of analysis
    #  8 boundsAndColors      -- bounds and colors
    #  9 criteria             -- the results of the criteria for determination
    #                            of the form
    # 10 variationName        -- the abbreviation of the variation
    # 11 repetition           -- part(s) that are repeated in this variation
    # 12 isNotated            -- (bool) this variation is the notated one
    # 13 gracenotesVariation  -- (bool)
    # 14 thresholdPI          -- offset, qL, end of PI, begin of PII
    # 15 repetitionType       -- type of the repetition
    # 16 repetitionPoint      -- point where the reptitionsign was
    # 17 criteriaToCheck      -- the functions and order of the criteria
    # ]

    # ==========================================================================
    # repetitions
    # ==========================================================================

    # get the repetitions
    # this should be the ids of the notes
    # repetitions =
    # [
    #   [ beginOfRepetitionOffset, endOfRepetitonOffset ],
    #   ...
    # ]
    repetitions = []
    repetitionNotated = -1

    # so far we only look at the first special barline
    try:
        barlines = get_barlines(d[0][2])
    except:
        print('An error with get_barlines() for "',
              d[0][0], '" forces me to skip to the next one!', sep='')
        problemFiles.append(d[0][0] + "\t\t\tget_barlines()")
        weGotAnError = True
        continue

    # print('len(barlines):', len(barlines))

    # repetitionPoint (offset):
    # the point which determines where the repetitions will be:
    # 0.0 - rP - end
    repetitionPoint = -1

    # d[0][2].show()

    # print("d[0][4] endPI:", d[0][4], endPI)

    # if no barline exists, create an artificial
    # endPI determines where
    if len(barlines) == 0:
        artificialBarlineOffset = round(d[0][4] / 100 * endPI, 2)

        # set barline to front/end of note
        for i, n in enumerate(d[0][6]):
            # print(n.offset, n)
            if n.offset == artificialBarlineOffset:
                # print('on point!')
                break
            elif n.offset > artificialBarlineOffset:
                distanceBegin = artificialBarlineOffset - d[0][6][i-1].offset
                distanceEnd = n.offset - artificialBarlineOffset
                # print('distanceBegin distanceEnd:', distanceBegin, distanceEnd)
                if distanceEnd < distanceBegin:
                    artificialBarlineOffset += distanceEnd
                else:
                    artificialBarlineOffset -= distanceBegin
                break

        barlines.append(['artificial', artificialBarlineOffset])
        # print('barlines:', barlines)

    if len(barlines) != 0:
        try:
            # barlines:
            # [[type, offset], ...]
            # print('barlines:', barlines)

            # get the length of the first full measure
            measureQL = d[0][2][1][2].quarterLength

            # TODO: check if this is really the repetitionPoint
            # (second barline could be at the end...)

            # prevent repetition after upbeat to be used
            if barlines[0][1] > measureQL:
                repetitionPoint = barlines[0][1]
                repetitionNotated = barlines[0][0]
            else:
                repetitionPoint = barlines[1][1]
                repetitionNotated = barlines[1][0]
        except:
            print('An error with determing the repetition point  for "',
                  d[0][0], '" forces me to skip to the next one!', sep='')
            problemFiles.append(d[0][0] + "\t\t\tdetermine repetition point")
            weGotAnError = True
            continue

        # print('d[0][4] (qL):', d[0][4])
        # print('repetitionPoint:', repetitionPoint)

        # print('repetitionNotated:', repetitionNotated)

        # add repetitions
        # safety: should never be False (except previous try throws an error)
        # TODO: think about a clean solution
        if repetitionPoint != -1:
            # print('repetitionPoint:', repetitionPoint)
            # print('d[0][4]:', d[0][4])

            # d[0][2].show()

            # if the repetitions sign is at the end of the melody
            if repetitionPoint == d[0][4]:
                # TODO!
                # print('TODO: rep-left is at the end')

                # repeat left
                if expandRepetitionsAll \
                        or expandRepetitionsAsNoted and repetitionNotated == 'end' \
                        or expandOnlyNonRepAndRepLeft:
                    repetitions.append(
                        [[0.0, repetitionPoint],
                         True if repetitionNotated == 'end'
                         else False, 'end'])

            else:
                lastNote = d[0][2].flat.notes[-1]
                end = lastNote.offset + lastNote.quarterLength

                # from options:
                # # create a variation as it is written in the melody
                # # (according to our todays understanding of repetition signs)
                # expandRepetitionsAsNoted = True
                # # create a variaion for every possible repetition
                # expandRepetitionsAll = True

                # repetition:
                # [
                #    reptition,
                #    originalRepetition,
                #    repetitionType
                # ]

                # repeat left
                if expandRepetitionsAll \
                        or expandRepetitionsAsNoted and repetitionNotated == 'left' \
                        or expandOnlyNonRepAndRepLeft:
                    repetitions.append(
                        [[0.0, repetitionPoint],
                         True if repetitionNotated == 'left'
                         else False, 'left'])

                # repeat right
                if (expandRepetitionsAll
                        or expandRepetitionsAsNoted and repetitionNotated == 'right') \
                        and not expandOnlyNonRepAndRepLeft:
                    repetitions.append(
                        [[repetitionPoint, end],
                         True if repetitionNotated == 'right'
                         else False, 'right'])

                # repeat both
                if (expandRepetitionsAll or
                        expandRepetitionsAsNoted and repetitionNotated == 'both') \
                        and not expandOnlyNonRepAndRepLeft:
                    repetitions.append(
                        [[0.0, repetitionPoint], [repetitionPoint, end],
                         True if repetitionNotated == 'both'
                         else False, 'both'])

    # print('repetitions:')
    # for rep in repetitions:
    #     print(' ', rep)

    # ==========================================================================
    # create variations

    # from options
    # # create a variation without repetition (aka ignore repetitions)
    # expandMelodyWithoutRepetitions = True
    # # create a variation as it is written in the melody
    # # (according to our todays understanding of repetition signs)
    # expandRepetitionsAsNoted = True
    # # create a variaion for every possible repetition
    # expandRepetitionsAll = True

    dummies = ['numberOfBars',        # 1
               'numberOfNotes',       # 2
               'upbeat',              # 3
               'qL',                  # 4
               'barlines',            # 5
               'tS',                  # 6
               'result',              # 7 # IDs
               'bAC',                 # 8 # offset
               'criteria',            # 9
               '_',                   # 10 variation
               'none',                # 11 repetition
               False,                 # 12 isNotated
               False,                 # 13 gracenoteVariation
               'thresholdPI',         # 14
               'repetitionType',      # 15
               'repetitionPoint',     # 16
               'criteriaToCheck']     # 17

    # TODO: if none not wanted, dont make it! (only with repetitions)
    # -> expandMelodyWithoutRepetitions = False

    # print('repetitions:', repetitions)

    if expandMelodyWithoutRepetitions:
        # add d[1]
        d.append(['mel']+dummies)
        # print(d[-1])
        # TODO: add tS?
        # d[1][0] = get_clean_mel(d[0][2])
        d[1][6] = copy.deepcopy(d[0][5])  # tS

        d[1][16] = repetitionPoint

    # create a new variation of the original melody for the gracenotes
    if d[0][3]:
        d.append([d[0][8]]+dummies)
        d[-1][10] += 'g'
        d[-1][13] = True
        d[-1][16] = repetitionPoint

    # for note in d[1][0]:
    #     print(note.measureNumber)

    # print('d:', d)

    # # check if its a repeat or double barline
    # if len(repetitions) == 1:
    #     variation = 'r'
    # else:
    #     variation = 'd'
    # # variation = d[-1][10][-1]

    # print('repetitionNotated:', repetitionNotated)
    # print('repetitions:', repetitions)
    # print('d[0][4]:', d[0][4])

    if repetitionNotated != -1:
        variation = repetitionNotated[0]
        # fix name "problem"
        if variation == 'e':
            if d[0][4] == repetitions[0][0][1]:
                variation = 'e'
            else:
                variation = 'l'
        elif variation == 's':
            variation = 'r'
    else:
        variation = ''
    # if True:
    try:
        # add repetitions to variations
        for i, repetition in enumerate(repetitions):
            # print(i, repetition, '(i repetition)')

            # TODO: here only dummies...
            # d.append([get_clean_mel(d[1][0], d[0][5], True)]+dummies)
            d.append(['mel']+dummies)
            d[-1][6] = copy.deepcopy(d[0][5])  # tS
            d[-1][11] = repetition[:-2]
            d[-1][12] = repetition[-2]  # notatedRepetition
            d[-1][15] = repetition[-1]  # repetitionType

            # print('repetitionPoint:', repetitionPoint)
            # print('repetition[0][1]:', repetition[0][1])
            # print(repetition)

            # print('repetitionPoint:', repetitionPoint)
            if repetition[2] == 'end':
                # d[-1][10] += 'e'
                d[-1][16] = repetitionPoint
            else:
                if repetition[0][1] == repetitionPoint:
                    d[-1][16] = repetitionPoint*2
                    # should be the same as:
                    # repetitionPoint + repetition[0][1] - repetition[0][0]
                else:
                    d[-1][16] = repetitionPoint  # change this later
                # if variation == 'd':
                #     d[-1][10] += str(i+1)
            d[-1][10] += variation + str(i+1)

            # if there are gracenotes create a gracenote variation
            # print('gracenotes:', d[0][3])
            if d[0][3]:
                d.append(['mel']+dummies)
                d[-1][6] = copy.deepcopy(d[0][5])  # tS
                d[-1][10] = d[-2][10] + 'g'        # variation
                d[-1][11] = repetition[:-2]        # repetiton
                d[-1][12] = repetition[-1]         # notatedRepetition
                d[-1][13] = True                   # gracenoteVariation
                d[-1][14] = d[-2][14]              # thresholdPI
                d[-1][15] = repetition[-1]         # repetitionType
                d[-1][16] = d[-2][16]              # repetitionPoint
                # d[-1][16] = repetitionPoint
    except:
        print('Error with Repetitions!')
        weGotAnError = True

    # ==========================================================================
    # end repetitions
    # ==========================================================================

    # remove gracenotes from the original
    if d[0][3]:
        d[1][0] = gracenotes_remove(d[0][6])
        # d[1][0].show()

    nope = False

    # if something does not work: abandon current and go to the next one
    if weGotAnError:
        print('An error in "',
              d[0][0], '" forces me to skip to the next one!', sep='')
        weGotAnError = True
        problemFiles.append(d[0][0] + "\t\t\tsomewhere at the beginning...")
        continue

    # print()
    # for da in d:
    #     for i, dat in enumerate(da):
    #         print(i, dat)
    #     print()
    # print()

    # for dd in d:
    #     print(dd)
    #     print(dd[10])
    #     for ddd in dd:
    #         print(' ',ddd)
    # ==========================================================================
    # this loop iterates over all variants of the melody
    # dat: this variant
    # di: its id (di == 0: as read from XML-file)
    # ==========================================================================
    for di, dat in enumerate(d):
        # GOTO INNER LOOP
        # dont want to have d[0] here
        if di == 0:# or di != 2:
            continue
        # print('\ndi:', di)
        # print('\ndat:', dat)
        # dat == d[di]
        # print('dat[10], variation:', dat[10], variation)
        # if original variation, then add 'o'
        if dat[10] == '_' or dat[10] == '_g':
            # dat[10] = dat[10][0] + 'o' + dat[10][1:]
            dat[10] = dat[10][0] + variation + '0' + dat[10][1:]
        # print('dat[10]:', dat[10])
        # print('==')
        # for i, datt in enumerate(dat):
        #     print(i, datt)

        # ======================================================================
        # load data
        # ======================================================================

        loadedResults = False

        thisOutputFileName = savedResultsFolder + d[0][1]
        if writeOptionsInFilenames:
            thisOutputFileName += '_' + saveOptions
        thisOutputFileName += '_' + currentTime + dat[10]
        # thisOutputFileNameOptions = savedResultsFolder + \
        #     d[0][1] + '_' + saveOptions + '_' + currentTime + dat[10]
        # print('thisOutputFileName:', thisOutputFileName)

        # check if saved results exist and load them
        if loadSavedResults:
            try:
                savedFiles = []
                for f in [f for f in listdir(savedResultsFolder) if path.isfile(path.join(savedResultsFolder, f))]:
                    if f.startswith(d[0][1] + '_') and f.endswith(dat[10] + '.txt'):
                        savedFiles.append(f[:-len(dat[10] + '.txt')])

                savedFiles = sorted(savedFiles)
                # for s in savedFiles:
                #     print('\t\t', s)

                if len(savedFiles) != 0:
                    inputFileName = savedResultsFolder + \
                        savedFiles[-1] + dat[10] + '.txt'
                    # print('Load from:', inputFileName)
                    inputTime = inputFileName[len(
                        savedResultsFolder)+len(d[0][1])+1:-(4+len(dat[10]))]
                    # print(inputTime)
                    with open(inputFileName, 'r') as f:
                        loadedData = json.loads(f.read())
                    # print(loadedData)

                     # load data from xml-file
                    loadedMusic = converter.parse(
                        path.join(savedResultsFolder, savedFiles[-1] + dat[10] + '.xml'))
                    # dat[0] = loadedMusic[1].flat.notes   ## dont need this, its already there...
                    dat[6] = loadedMusic[1].flat.getElementsByClass(
                        meter.TimeSignature)

                    dat[1] = loadedData[0]
                    dat[2] = loadedData[1]
                    dat[3] = loadedData[2]
                    dat[4] = loadedData[3]
                    dat[5] = loadedData[4]
                    dat[7] = loadedData[5]
                    dat[8] = loadedData[6]
                    dat[9] = loadedData[7]
                    # dat[10] = loadedData[8] # already have this data

                    # print('\n', dat, '\n')

                    loadedResults = True

                    print('  Loaded results from',
                          inputFileName[:-4] + '.(txt|xml)')
            except:
                print('Could not load files, have to analyze again.')

        # ======================================================================
        # get data if not loaded
        # ======================================================================
        if not loadedResults:

            # deprecated?
            thresholdPI = -1

            # ==================================================================
            # get melody (with repetitions)
            # ==================================================================
            # d[0][3]: hasGracenotes
            # print('d[0][3]:', d[0][3])
            # if d[0][3]:
            if dat[13]:
                # print('grace!')
                dat[0] = get_clean_mel(d[0][8], dat[6], True)
                dat[7] = copy.deepcopy(d[0][9])
                # print('d[0][8]:')
                # d[0][8].show('text')
            else:
                # print('no grace!')
                dat[0] = get_clean_mel(d[0][6], dat[6], True)
                dat[7] = copy.deepcopy(d[0][7])

            if dat[11] != 'none':
                for rep in sorted(dat[11], key=lambda rep: rep[0], reverse=True):
                    # print('rep:', rep)
                    repetitionBegin = rep[0]
                    repetitionEnd = rep[1]
                    # print('repetitionBegin repetitionEnd:',
                    #       repetitionBegin, repetitionEnd)
                    # dat[0] = mel_add_repetition(dat[0], d[0][5],
                    #                             repetitionBegin, repetitionEnd)
                    # dat[0] = mel_add_repetition(dat[0], d[0][9],
                    #                             repetitionBegin, repetitionEnd)
                    dat[0] = mel_add_repetition(
                        dat[0], repetitionBegin, repetitionEnd)

                    # TODO: rep-left at the ends
                    try:
                        dat[7] = result_add_repetition(
                            repetitionBegin, repetitionEnd, resultPar=dat[7])
                    except:
                        print('problem, skip!')
                        nope = True
                        break
                    # dat[0].show()

                if nope:
                    break

            # ==================================================================

            # print(dat[1])
            # print(dat[0][-1].measureNumber)
            # print('dat[15]:', dat[15])
            # we only know the measureNumber of the 'original'.
            # print('dat[15]:', dat[15])
            if dat[15] == 'repetitionType':
                dat[1] = d[0][2].flat.notesAndRests[-1].measureNumber
                # print('dat[1]:', dat[1])
            else:
                dat[1] = 0

            # numberOfNotes
            dat[2] = len(dat[0])

            # upbeat (aka quarterLength of upbeat)
            # print("d[1][3]:", d[1][3])

            # get upbeatlength from original
            dat[3] = d[0][10]
            # qL
            dat[4] = sum([n.quarterLength for n in dat[0]])
            # barlines
            dat[5] = barlines
            # timeSignatures
            # TODO: dat[6] ?= d[0][3]
            if dat[6] == 'tS':
                dat[6] = get_timeSignatures(d[0][2])

            # thresholdPI
            # apply options from the beginning
            # dat[5]: barlines
            # if specialBarlineAsEndPI and len(dat[5]) > 0:
            # print('dat[5]:', dat[5])
            if specialBarlineAsEndPI and (dat[5] != 'barlines' and dat[5] != []):
                # # dat[11]: repetition
                # # dat[15]: repetitionType
                # print('dat[11]:', dat[11])
                # print('dat[15]:', dat[15])
                # print('dat[5]:', dat[5])
                # if rep-end and not the repetition
                if dat[11] == 'none' and dat[5][0][0] == 'end' and dat[5][0][1] == dat[4]:
                    # dat[4]: quarterLength
                    dat[14] = dat[4] / 100 * endPI
                else:
                    dat[14] = dat[16]
            else:
                dat[14] = dat[4] / 100 * endPI

            # print(dat)
            # print("dat[14]:", dat[14])
            # print(dat[0])  ## is melody
            # print(dat[7])  # is 'result'
            # print(dat[10])
            # print('repetitions:', repetitions)
            # only analyse if necessary, otherwise 'manipulate' existing results

            if 'g' in dat[10]:
                baseID = 2
            else:
                baseID = 1
            # print('baseID:', baseID)

            dat[17] = copy.deepcopy(criteriaToCheck)

            # print('len(dat[0]):', len(dat[0]))
            # print('dat[0][-1].offset:', dat[0][-1].offset)
            # print('dat[7]:', dat[7])

            # print('\ndat[7]:')
            # for i, datt in enumerate(dat[7]):
            #     print(i, datt)

            # appy options (aka remove all ts that are too short):
            # in numberOfNotes
            # oLimit = math.floor(dat[2] * tsMinLen / 100)
            # in quarterLength
            # oLimit = math.floor(dat[4] * tsMinLen / 100.0)
            # TODO: floor it or not?
            oLimit = dat[4] * tsMinLen / 100.0
            # print('oLimit:', oLimit)

            dRemove = []
            for datat in dat[7]:
                # in numberOfNotes
                # if datat[1] < oLimit:
                # in quarterLength

                # if we compare only by note height, we cant rely on iTS-length
                # so we check all lengths and if one is longer than the min, it can be used
                if notesCompareBy == 2:
                    # print('datat:', datat)
                    removeTS = True

                    for ts in datat[0]:
                        length = sum(
                            [n.quarterLength for n in dat[0][ts:ts+datat[1]]])
                        # print('length:', length)

                        if length > oLimit:
                            removeTS = False

                    if removeTS:
                        dRemove.insert(0, datat)

                    continue

                if datat[2] < oLimit:
                    dRemove.insert(0, datat)

            for rem in dRemove:
                dat[7].remove(rem)

            # for datat in dat[7]:
            #     print(datat)

        # print('\ndat[7]:')
        # for i, datt in enumerate(dat[7]):
        #     print(i, datt)

        # if we dont want to interpret the results
        if onlyAnalyze:
            continue

        # find the right colors for the tss
        try:
            dat[7] = make_colors(dat[0], dat[5], dat[6], dat[7])
        except:
            print('An error with make_colors() for "',
                  d[0][0], '" forces me to skip to the next one!', sep='')
            weGotAnError = True
            problemFiles.append(d[0][0] + "\t\t\tmake_colors()")
            break

        # print('\ndat[7]:')
        # for i, datt in enumerate(dat[7]):
        #     print(i, datt)

        # remove ts that begin before the end of the previous
        # fix 18.09.2020
        for i, datt in enumerate(dat[7]):
            # print(i, datt)
            ts_numberOfNotes = datt[1]
            ids_to_remove = []
            last_ts = -1000
            for ts in datt[0]:
                # print(ts)
                if ts - ts_numberOfNotes < last_ts:
                    # remove ts
                    # print('  remove', ts)
                    ids_to_remove.append(datt[0].index(ts))
                else:
                    last_ts = ts
            ids_to_remove.reverse()
            # print(ids_to_remove)
            # for ts in datt[0]:
            #     if ts in ids_to_remove:
            #         datt[0].remove(ts)
            for id in ids_to_remove:
                del datt[0][id]
            # print('datt[0]:', datt[0])
            # print(i, datt)



        # make bounds
        try:
            dat[8] = make_bounds(dat[0], dat[5], dat[7])
            pass
        except:
            print('An error with make_bounds() for "',
                  d[0][0], '" forces me to skip to the next one!', sep='')
            weGotAnError = True
            problemFiles.append(d[0][0] + "\t\t\tmake_bounds()")
            break

        # print('dat[8]:')
        # for i, datt in enumerate(dat[8]):
        #     print(i, datt)

        # print('dat[8] aka boundsAndColor:')
        # for col in dat[8]:
        #     print('--')
        #     for c in col:
        #         print(' ', c)

        # print('dat:')
        # print('----------')
        # for n, datum in enumerate(dat):
        #     if n == 17:
        #         continue
        #     print(' ', n, '\t', datum)
        # print('----------')
        # dat[0].show()

        # TODO: bounds cleanup
        # print('dat[8]:', dat[8])
        try:
            dat[8] = bounds_cleanup()
        except:
            print('An error with bounds_cleanup() for "',
                  d[0][0], '" forces me to skip to the next one!', sep='')
            problemFiles.append(d[0][0] + "\t\t\tbounds_cleanup()")
            weGotAnError = True
            break

        # print('dat[8]:')
        # for datt in dat[8]:
        #     print(datt)
        # # print('dat[8]:', dat[8])
        # print('---')

        try:
            bounds_compact()
            pass
        except:
            print('An error with bounds_compact() for "',
                  d[0][0], '" forces me to skip to the next one!', sep='')
            weGotAnError = True
            problemFiles.append(d[0][0] + "\t\t\tbounds_compact()")
            break

        # check if there are no results
        if dat[8] == [[[-1], ['black'], -1, -1.0]]:
            dat[8] = [[[0.0, dat[0][-1].offset + dat[0]
                        [-1].quarterLength], ['grey'], 0, 0.0]]

        # draw special barlines
        if drawSpecialBarlinesInGraphs:
            drawSpecialBarlinesInGraphs()

        # draw black lines separating ts
        if drawBlackLineBetweenTSInGraphs:
            drawBlackLineBetweenTSInGraphs()

        # print('dat[8]:')
        # for datt in dat[8]:
        #     print(datt)

        # TODO: check bounds aka remove doubles

        # TODO: also check for double greys and remove them

        # TODO: make option read from xlsx
        # check if entry exists in xlsx
        insertLine = True
        # print('d[0][1]:', d[0][1])
        try:
            variantIdentifier = d[0][1] + dat[10]
            # print('variantIdentifier:', variantIdentifier)
            try:
                baseID = worksheetIdentifierHashMap[variantIdentifier]
                insertLine = False
                print('  Found "' + variantIdentifier +
                      '" in .xlsx, update.')
                # print('found ' + variantIdentifier)
            except:
                baseID = worksheetIdentifierHashMap[d[0][1]]
                # print('didnt find ' + variantIdentifier)
        except:
            print('  Identifier not found in xlsx.')
            baseID = -1
        # print('baseID:', baseID)

        # print its and values
        if False:
            print('ql:', dat[4])
            print('numberOfNotes:', dat[2])
            for this in dat[7]:
                print(this)
                print('%ql:', this[2] / dat[4] * 100)
                print('%numberOfNotes:', this[1] / dat[2] * 100)

        # TODO: check criteria
        try:
            prepare_output()
            pass
        except:
            print('An error with prepare_output() for "',
                  d[0][0], '" forces me to skip to the next one!', sep='')
            weGotAnError = True
            problemFiles.append(d[0][0] + "\t\t\tprepare_output()")
            break

        # determine form
        # not here, this happens in the xlsx-file, userwork!
        # determine_form()

        if exportToZfgTable:
            # save results to dict, later to xlsx
            # hashTableInsert:
            # key -- identifier
            # 0 -- baseID
            # 1 -- dict with col:content for xlsx
            # print(d[0])

            # print('\nd:')
            # for asdf in dat:
            #     print(asdf)
            # print('\n')

            # # insertLine = True
            # # try:
            # #     variantIdentifier = d[0][1] + dat[10]
            # #     # print('variantIdentifier:', variantIdentifier)
            # #     try:
            # #         baseID = worksheetIdentifierHashMap[variantIdentifier]
            # #         insertLine = False
            # #         print('  Found "' + variantIdentifier +
            # #               '" in .xlsx, update.')
            # #         # print('found ' + variantIdentifier)
            # #     except:
            # #         baseID = worksheetIdentifierHashMap[d[0][1]]
            # #         # print('didnt find ' + variantIdentifier)
            # # except:
            # #     baseID = -1
            # # # print("baseID:", baseID)
            worksheetInsertHashMap[d[0][1]+dat[10]
                                   ] = [baseID, dat[17], insertLine]

            if d[0][1] not in worksheetLinesToRemove:
                worksheetLinesToRemove.append(d[0][1])

        # print the criteria
        # print('\ndat[17]:')
        # for k, v in dat[17].items():
        #     print(k, v)

        # print(dat[10])
        # print("dat[17]['G']:", dat[17]['G'])
        # print("dat[17]['AC']:", dat[17]['AC'])
        
        # dont extract the criteria params again
        criteriaCol = -1
        # TODO: add 'barlines' to bounds

        # save results of variation to file
        # if saveResults:
        #     # t = time.strftime('%Y-%m-%d-%H-%M-%S')
        #     outputFileName = savedResultsFolder + d[0][1] + \
        #         '_' + currentTime + dat[10] + '.txt'

        #     print(dat[1:])
        #     with open(outputFileName, 'w') as f:
        #         f.write(json.dumps(dat[1:]))
        #         print('  Wrote result to file:', outputFileName)

        # print('\ndat:')
        # for datt in dat:
        #     print(datt)

        # save result to file:
        if not loadedResults and saveResults:
            # save melody and timesignatures to xml-file
            # output = dat[0] + dat[6]
            # output.write('musicxml', fp=thisOutputFileName+'.xml')

            # TODO: outputof musicxml-file doesnt work with upbeats so far...

            # save all non-music21 data to txt-file:
            dataToSave = dat[1:6] + dat[7:11]
            # for dts in dataToSave:
            #     print(dts)
            with open(thisOutputFileName + '.txt', 'w') as f:
                f.write(json.dumps(dataToSave))

            print('  Wrote results to files:',
                  thisOutputFileName + '.(txt|xml)')

    # --- end loop variant

    if nope:
        continue

    # if something does not work: abandon current and go to the next one
    if weGotAnError or onlyAnalyze:
        # cleanup: delete data that is not used anymore
        del d[:]
        continue

    # TODO: export xslx
    # export_xlsx()
    # export_xlsx_new()

    # for e in dat[0]:
    #    print(e)

    numberOfBounds = 0
    boundsOutput = ''

    print('  Creating graphs...')
    # iterate over all bounds
    for e, bounds in enumerate(d[1:]):
        # print(bounds)
        timeSignatures = d[1+e][6]
        upbeatQuarterLength = d[1+e][3]
        numberOfBars = d[1+e][1]
        quarterLength = d[1+e][4]

        # print()
        # for dat in d[1+e]:
        #     print(dat)
        # print()

        for f, bound in enumerate(bounds[8]):
            # print(bound)
            if loadedResults:
                fileTime = inputTime
            else:
                fileTime = currentTime

            if writeOptionsInFilenames:
                fileName = d[0][1] + '_' + saveOptions + '_' + fileTime + \
                    bounds[10] + '_' + str(e) + '-' + str(f)
            else:
                fileName = d[0][1] + '_' + bounds[10] + \
                    '_' + str(e) + '-' + str(f)
            fileName = fileName.replace(' ', '_')
            # print(fileName)

            if not loadSavedResults \
                    or (loadSavedResults and not path.isfile('graphs/' + fileName + '-' + configNumber + '.' + graphsOutputFormat)):
                # def create_graph(bounds, colors, timeSignatures=None, upbeatQuarterLength=0.0, operation='save', fp='', label='', nameAdd=''):
                # TODO: add barnumbers to arguments
                # print(fileName + '---' + configNumber)
                # print('fileName', fileName)
                # print('e', e)
                label = fileName[-3:] + '-' + configNumber
                gracenotes = d[0][3]
                if gracenotes:
                    labels = {
                        0: 'No Repetition',
                        1: 'No Repetition (with Gracenotes)',
                        2: 'Repetition of part I',
                        3: 'Repetition of part I (with Gracenotes)',
                        4: 'Repetition of part II',
                        5: 'Repetition of part II (with Gracenotes)',
                        6: 'Repetition of part I and II',
                        7: 'Repetition of part I and II (with Gracenotes)',
                    }
                else:
                    labels = {
                        0: 'No Repetition',
                        1: 'Repetition of part I',
                        2: 'Repetition of part II',
                        3: 'Repetition of part I and II'
                    }
                # print(labels[e])
                label = labels[e] + ': ' + str(f)
                if f == 0:
                    label += ' (Summary Graph)'
                # print(label)
                try:
                    create_graph(bound[0], bound[1], timeSignatures=timeSignatures,
                                 upbeatQuarterLength=upbeatQuarterLength,
                                 numberOfBars=numberOfBars,
                                 quarterLength=quarterLength,
                                 operation='save', fp='', label=label, fileName=fileName + '-' + configNumber)
                except:
                    print("problem with create graph")
                    problemFiles.append(d[0][0] + "\t\t\tcreate_graph()")
                    weGotAnError = True
                # create_graph(bound[0], bound[1], timeSignatures=timeSignatures,
                #              upbeatQuarterLength=upbeatQuarterLength,
                #              numberOfBars=numberOfBars,
                #              quarterLength=quarterLength,
                #              operation='save', fp='', label=fileName + '-' + configNumber)

            boundsOutput += '<tr>'
            if f == 0:
                boundsOutput += '<td width="1" min-height="10" align="left" valign="top">S</td>'
            else:
                boundsOutput += '<td></td>'

            boundsOutput += '<td align="left"><img src="graphs/' + \
                fileName + '-' + configNumber + '.' + graphsOutputFormat + '" />'
            boundsOutput += '</td></tr>\n'
            numberOfBounds += 1
            if printOnlyFirstBound:
                break

    if loadSavedResults:
        # get all saved results with options
        savedResults = sorted([f for f in listdir(savedResultsFolder)
                               if path.isfile(path.join(savedResultsFolder, f))
                               and f.startswith(d[0][1] + '_' + saveOptions)])

        HTMLFileSave = savedResultsFolder + \
            savedResults[0] if len(savedResults) > 0 else -1
        # HTMLFileSave = savedResultsFolder + \
        #     d[0][1] + '_' + saveOptions + '_' + inputTime + '.html'
        # print(HTMLFileSave)

    # this isnt correct yet
    # htmlfiles can have a different date than xml|txt-files
    # last one with matching options should be loaded
    if loadSavedResults and path.isfile(HTMLFileSave):
        print('  Loaded HTML from', HTMLFileSave)
        # load file
        with open(HTMLFileSave, 'r') as f:
            htmlOutput = f.read()
    else:
        # create output for html-file
        htmlOutput = '<tr><td rowspan="' \
            + str(numberOfBounds + 1) + '" valign="top" width="300" align="left" ' \
            + 'style="border-top: 0px black solid;">'
        htmlOutput += '<span style="font-size: 16px; font-weight: bold;">' + d[0][1] + '</span>'
        htmlOutput += '<br><br><small>measures: ' + str(d[1][1])
        htmlOutput += '<br>numberOfNotes: ' + str(d[1][2])
        htmlOutput += '<br>upbeat: ' + str(d[1][3])
        htmlOutput += '<br>quarterLength: ' + str(d[1][4])
        htmlOutput += '</small></td>'
        htmlOutput += '<td colspan="2" align="left" ' + \
            'style="border-top: 0px black solid;"><a href="notes/' + \
            d[0][1] + '-1.png"><img src="notes/' + \
            d[0][1] + '-1.png" /></a></td></tr>\n'
            # width="60%"
        htmlOutput += boundsOutput

        # add a little space between the melodies
        htmlOutput += '<tr><td colspan="2" height="15"></td></tr>'

        # write htmlOutput to HTML-File
        if saveResults:
            # print('saved results html')
            HTMLFileSaveCurrent = savedResultsFolder + \
                d[0][1] + '_' + saveOptions + '_' + currentTime + '.html'
            # print('HTMLFileSaveCurrent:', HTMLFileSaveCurrent)

            with open(HTMLFileSaveCurrent, 'w') as f:
                f.write(htmlOutput)
            print('  Wrote HTML to', HTMLFileSaveCurrent)

    if not doNotExportHTML:
        # write to HTML-file
        with open(HTMLfile, 'a') as f:
            f.write(htmlOutput)

    # cleanup: delete data that is not used anymore
    del data[x][:]

    ###
    # log stuff
    analyseEndTime = time.time()
    print('  Analyzed in', math.floor(
        analyseEndTime - analyseStartTime), 'seconds.')

# print('criteriaValues:')
# write the criterion descriptons actual values to var
for key in criteriaValues:
    functionName = criteriaValues[key][0]
    # print('functionName:', functionName)
    functionDescription = criteriaDescriptions[functionName]
    # print('functionDescription:', functionDescription)
    # print(key, criteriaValues[key])
    for i, value in enumerate(criteriaValues[key][1]):
        # print(i, value)
        # description = criteriaDescriptions[]
        # description = description.replace('$' + str(i) + '$', value, 1)
        functionDescription = functionDescription.replace(
            '$' + str(i) + '$', str(value), 1)
    criteriaDescriptionsWithValues[key] = functionDescription

# print('criteriaDescriptionsWithValues:')
# for key in criteriaDescriptionsWithValues:
#     print(key, criteriaDescriptionsWithValues[key])

# print('worksheetInsertHashMap:')
# for k, v in worksheetInsertHashMap.items():
#     print('\n\n'+k+'\n', v)

if exportToZfgTable:
    print('=====================')
    # export the descriptions (column 1) to the xlsx-file.
    # TODO: update to load_worksheet()
    export_xlsx_description_with_values()

    # worksheetInsertHashMapCopy = copy.deepcopy(worksheetInsertHashMap)
    # for identifier, v in worksheetInsertHashMapCopy.items():
    #     worksheetInsertHashMap[identifier+'___before'] = v
    #     del worksheetInsertHashMap[identifier]
    # print(identifier)
    # # for identifier in worksheetInsertHashMap:
    # #     print(identifier)

    # insert new cols into worksheet
    worksheet_insert_new_rows()

    # save workbook:
    save_workbook()


criteriaResult = []

# print_data(depth=4)

if len(problemFiles) != 0:
    print('=====================')
    print('Had problems with the following files:')
    probs = ''
    for pF in problemFiles:
        print(' ', pF)
        probs += pF + "\n"
    with open('problems.txt', 'a') as f:
        f.write(time.strftime('%Y-%m-%d-%H-%M-%S') + '\n')
        f.write('configNumber: ' + configNumber + '\n')
        f.write(probs + '\n')

# ==============================================================================
# this is for the LOG
endTime = time.time()
duration = round(endTime - startTime)
durationS = duration % 60
durationM = math.floor(duration / 60) % 60
durationH = math.floor(duration / 3600)

if not doNotExportHTML:
    with open(HTMLfile, 'a') as f:
        f.write('</table><hr>LOG: Analyzed files: ' + str(x + 1) + ', Time needed: ' +
                str(durationH) + 'h ' + str(durationM) + 'm ' + str(durationS) + 's' +
                '<br>' + time.strftime('%Y-%m-%d-%H-%M-%S') + ' configNumber: ' + configNumber + '</body></html>')

print('=====================')
print('LOG:')
# print('Analyzed files: ', x + 1, sep='')
print('Time needed: ', durationH, 'h ',
      durationM, 'm ', durationS, 's', sep='')
# print('duration: ', durationH, ':', durationM, ':', durationS, '', sep='')
