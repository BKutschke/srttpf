.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.index_humansorted`
==================================

.. autofunction:: index_humansorted

