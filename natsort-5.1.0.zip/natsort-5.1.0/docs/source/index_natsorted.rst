.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.index_natsorted`
================================

.. autofunction:: index_natsorted

