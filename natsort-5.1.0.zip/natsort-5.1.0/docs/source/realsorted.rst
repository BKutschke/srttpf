.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.realsorted`
===========================

.. autofunction:: realsorted

