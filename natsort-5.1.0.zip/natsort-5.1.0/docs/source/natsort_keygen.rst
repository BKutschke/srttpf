.. default-domain:: py
.. currentmodule:: natsort

:func:`~natsort.natsort_keygen`
===============================

.. autofunction:: natsort_keygen

